package com.datalogic.aladdin.aladdinusbscannersdk.utils.constants


object USBConstants {

    const val ACTION_USB_PERMISSION = "com.datalogic.aladdin.aladdinusbscannersdk.USB_PERMISSION"
    const val ACTION_BT_PERMISSION = "com.datalogic.aladdin.aladdinusbscannersdk.ACTION_BT_PERMISSION"
    const val ACTION_LOCATION_PERMISSION = "com.example.ACTION_LOCATION_PERMISSION"
    const val EXTRA_BT_PERMISSION_GRANTED = "extra_bt_permission_granted"
    const val EXTRA_BT_PERMISSION_MISSING = "extra_bt_permission_missing"
    const val REQUEST_CODE_BT = 1001
    const val VENDOR_ID = "1529"

    val enableCmdForOem = byteArrayOf(0x11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    val disableCmdForOem = byteArrayOf(0x12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    val enableCmdForCom = byteArrayOf(69, 13)
    val disableCmdForCom = byteArrayOf(68, 13)
    const val NUMERIC_DATA_LENGTH_64 = 64
    const val NUMERIC_4 = 4
    const val NUMERIC_3 = 3
    const val NUMERIC_2 = 2
    const val NUMERIC_1 = 1
    const val NUMERIC_0: Byte = 0
    const val USB_COM_MAX_BUF = 8192
    const val NUMERIC_500 = 500
    const val NUMERIC_200 = 200
    const val NUMERIC_100 = 100
    const val NUMERIC_93 = 93
    const val NUMERIC_10 = 10

    const val BYTE_DATA_00 = 0
    const val BYTE_DATA_10 = 0x10
    const val BYTE_DATA_0B = 0x0B
    const val DL_NRESP = 0xFF // no response
    const val HEX_FORMAT = "%02X"
    const val HEX_VALUE_ZERO = "0x"
    const val REQUEST_CODE = 0x09
    const val REQUEST_VALUE_OUT = 0x200
    const val REQUEST_VALUE_FEATURE = 0x300

    const val JSON_FILE = "productDetails.json"
    const val DIO_JSON_FILE = "dio_field.json"
    const val RESP_DIO_DATA = 0x00000040
    const val RESP_DIO_SUCCESS = 0x00080000
    const val RESP_CMD_REJECT = 0x00008000
    const val RESP_DIO_NOT_ALLOWED = 0x00100000
    const val RESP_DIO_UNDEFINED = 0x00200000
    const val RESP_CONFIG_DATA = 0x00000002
    const val DEFAULT_TIMEOUT: Long = 5000
}
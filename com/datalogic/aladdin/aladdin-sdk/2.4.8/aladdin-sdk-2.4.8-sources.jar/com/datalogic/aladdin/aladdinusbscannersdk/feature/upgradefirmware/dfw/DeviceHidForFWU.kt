package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.UpgradeDFW.Companion.ECHO
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.ACTION_USB_PERMISSION
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.REQUEST_CODE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.REQUEST_VALUE_FEATURE
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.UpgradeDFW.Companion.FIRST_PRODUCT_ID
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.UpgradeDFW.Companion.FIRST_VENDOR_ID
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.UpgradeDFW.Companion.SECOND_PRODUCT_ID
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.UpgradeDFW.Companion.SECOND_PRODUCT_ID_FOR_OEM
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.UpgradeDFW.Companion.SECOND_VENDOR_ID

object DeviceHidForFWU {
    private var TAG: String = DeviceHidForFWU::class.java.simpleName

    var usbConnection: UsbDeviceConnection? = null
    var usbInterface: UsbInterface? = null
    var usbEndpointIn: UsbEndpoint? = null
    var usbEndpointOut: UsbEndpoint? = null


    /**
     * Start scanning for HID device PID
     */
    fun startScanPidHID(timeoutMs: Int, attempts: Int): Boolean {
        try {
            Log.d(TAG, "Scanning for HID device PID...")

            repeat(attempts) { attempt ->
                /*if (isStopped.get()) {
                    Log.d(FirmwareUpgradeDFW.TAG, "Scan stopped by user")
                    return false
                }*/

                Log.d(TAG, "Scan attempt  [${attempt + 1}/$attempts]")

                // Send echo command to detect device
                val echoResponse = sendEchoCommand(timeoutMs)
                Log.d(TAG, "Echo response: ${echoResponse?.joinToString(", ")}")
                if (echoResponse != null) {
                    // Extract PID from response
                    val pid = String.format("0x%02x%02x", echoResponse[2], echoResponse[3])
                    if (pid != null) {
                        Log.d(TAG, "Found HID device with PID: $pid")
                        UpgradeDFW.pidHID = pid
                        return true // Stop scanning immediately when echoResponse is not null
                    }
                }

                Thread.sleep(timeoutMs.toLong())
            }

            Log.d(TAG, "Failed to find HID device after $attempts attempts")
            return false

        } catch (e: Exception) {
            Log.e(TAG, "Error scanning for HID PID", e)
            return false
        }
    }

    /**
     * Send echo command to device
     */
    private fun sendEchoCommand(timeoutMs: Int): ByteArray? {
        try {
            // 1. Send the echo command (OUT)
            val requestTypeOut = UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
            val bytesWritten = usbConnection!!.controlTransfer(
                requestTypeOut, REQUEST_CODE, REQUEST_VALUE_FEATURE,
                usbInterface!!.id, ECHO, ECHO.size, timeoutMs
            )
            Log.d(TAG, "sendEchoCommand Bytes written: $bytesWritten")
            if (bytesWritten <= 0) return null

            // 2. Read the response (IN) using the interrupt IN endpoint
            Thread.sleep(10) // Optional: give device time to respond
            val responseBuffer = ByteArray(64)
            val bytesRead = usbConnection!!.bulkTransfer(
                usbEndpointIn, responseBuffer, responseBuffer.size, timeoutMs
            )
            Log.d(TAG, "sendEchoCommand Bytes read: $bytesRead")

            // 3. Return the response
            return if (bytesRead > 0) responseBuffer.copyOf(bytesRead) else null

        } catch (e: Exception) {
            Log.e(TAG, "Error sending echo command", e)
            return null
        }
    }

    /**
     * Extract PID from device response
     */
    private fun extractPidFromResponse(response: ByteArray): String? {
        try {
            if (response.size >= 4) {
                val pidBytes = response.sliceArray(1..2)
                return String.format("0x%02X%02X", pidBytes[0], pidBytes[1])
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting PID from response", e)
        }
        return null
    }

    /**
     * Detect connection of USB HID device with retry and timeout
     */
    fun detectHIDDeviceWithTimeout(context: Context, retry: Int, timeout: Long): Boolean {
        Log.d(TAG, "detectHIDDeviceWithTimeout")
        usbConnection = null
        usbInterface = null
        usbEndpointIn = null
        usbEndpointOut = null

        repeat(retry) {
            Thread.sleep(timeout)
            val tempResult = detectHIDDevice(context)
            if (tempResult) {
                Log.d(TAG, "Handheld Scanner device reset HID command sent successfully")
                return true
            }
        }
        return false
    }

    /**
     * Detect connection of USB HID device
     */
    fun detectHIDDevice(context: Context): Boolean {
        Thread.sleep(1000)
        Log.d(TAG, "detectHIDDevice")
        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        var usbDevice: UsbDevice? = null

        if (usbManager.deviceList.isNotEmpty()) {
            for (device in usbManager.deviceList.values) {
                // Find compatible HID device
                val deviceList = usbManager?.deviceList
                deviceList?.values?.forEach { device ->
                    if (isCompatibleDevice(device)) {
                        usbDevice = device
                        Log.d(TAG, "HID device found device: $device")
                        return@forEach
                    }
                }

                if (usbDevice == null) {
                    Log.d(TAG, "No compatible HID device found")
                }

                // Open connection
                if (usbDevice != null) {
                    if (usbManager.hasPermission(usbDevice)) {
                        usbConnection = usbManager.openDevice(usbDevice)
                        Log.d(TAG, "USB device: $usbDevice")
                        // Proceed with claiming interface, etc.
                        for (i in 0 until usbDevice!!.interfaceCount) {
                            val intf = usbDevice!!.getInterface(i)
                            Log.d(TAG, "Found interface: ${intf.interfaceClass}")
                            if (intf.interfaceClass == UsbConstants.USB_CLASS_HID) {
                                usbInterface = intf

                                // Find input and output endpoints
                                for (j in 0 until intf.endpointCount) {
                                    val endpoint = intf.getEndpoint(j)
                                    when (endpoint.direction) {
                                        UsbConstants.USB_DIR_IN -> usbEndpointIn = endpoint
                                        UsbConstants.USB_DIR_OUT -> usbEndpointOut = endpoint
                                    }
                                }
                                break
                            }
                        }
                        Log.d(TAG, "Found HID interface: $usbInterface, $usbEndpointIn, $usbEndpointOut")
                        if (usbInterface == null || usbEndpointIn == null || usbEndpointOut == null) {
                            Log.d(TAG, "Failed to find HID interface or endpoints")
                        }
                        // Claim interface
                        if (!usbConnection!!.claimInterface(usbInterface, true)) {
                            Log.d(TAG, "Failed to claim HID interface")
                        }
                        Log.d(TAG, "HID device initialized successfully")
                        return true

                    } else {
                        Log.d(TAG, "Usb manager does not have permission")
                        // Use a PendingIntent to handle the permission result
                        val permissionIntent = PendingIntent.getBroadcast(
                            context, 0, Intent(ACTION_USB_PERMISSION), PendingIntent.FLAG_IMMUTABLE
                        )
                        usbManager.requestPermission(usbDevice, permissionIntent)
                        // Return here; wait for the broadcast receiver to handle the rest
                        return false
                    }
                }

            }
        }
        return false
    }

    /**
     * Check if device is compatible for firmware upgrade
     */
    private fun isCompatibleDevice(device: UsbDevice): Boolean {
        val vendorId = device.vendorId
        val productId = device.productId

        return (vendorId == FIRST_VENDOR_ID || vendorId == SECOND_VENDOR_ID) &&
                (productId == FIRST_PRODUCT_ID || productId == SECOND_PRODUCT_ID ||
                        productId == SECOND_PRODUCT_ID_FOR_OEM)
    }

}
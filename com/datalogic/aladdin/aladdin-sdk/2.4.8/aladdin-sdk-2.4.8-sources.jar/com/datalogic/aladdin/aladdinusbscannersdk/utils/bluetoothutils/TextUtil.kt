package com.datalogic.aladdin.aladdinusbscannersdk.utils.bluetoothutils

import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.HEX_FORMAT

object TextUtil {
    const val NEWLINE_CRLF = "\r\n"
    const val NEWLINE_LF = "\n"

    fun fromHexString(s: CharSequence): ByteArray {
        val buf = mutableListOf<Byte>()
        var b: Byte = 0
        var nibble = 0
        for (pos in s.indices) {
            if (nibble == 2) {
                buf.add(b)
                nibble = 0
                b = 0
            }
            val c = s[pos].code
            when (c) {
                in '0'.code..'9'.code -> {
                    nibble++
                    b = (b * 16 + (c - '0'.code)).toByte()
                }
                in 'A'.code..'F'.code -> {
                    nibble++
                    b = (b * 16 + (c - 'A'.code + 10)).toByte()
                }
                in 'a'.code..'f'.code -> {
                    nibble++
                    b = (b * 16 + (c - 'a'.code + 10)).toByte()
                }
            }
        }
        if (nibble > 0) buf.add(b)
        return buf.toByteArray()
    }

    fun toHexString(buf: ByteArray?, begin: Int = 0, end: Int? = null): String {
        if (buf == null) return ""
        val realEnd = end ?: buf.size
        val sb = StringBuilder(3 * (realEnd - begin))
        for (pos in begin until realEnd) {
            if (sb.isNotEmpty()) sb.append(' ')
            val b = buf[pos].toInt() and 0xff
            val c1 = b / 16
            val c2 = b % 16
            sb.append(if (c1 >= 10) 'A' + (c1 - 10) else '0' + c1)
            sb.append(if (c2 >= 10) 'A' + (c2 - 10) else '0' + c2)
        }
        return sb.toString()
    }

    fun hexToAscii(hex: String, padIfOdd: Boolean = false): String {
        return try {
            var cleanHex = hex.replace(" ", "").trim()
            if (cleanHex.length % 2 != 0) {
                if (padIfOdd) {
                    cleanHex = cleanHex.padStart(cleanHex.length + 1, '0')
                } else {
                    throw IllegalArgumentException("Hex string must have even length: $cleanHex")
                }
            }

            val output = StringBuilder()
            for (i in cleanHex.indices step 2) {
                val str = cleanHex.substring(i, i + 2)
                output.append(str.toInt(16).toChar())
            }
            output.toString()
        } catch (e: Exception) {
            Log.e("TextUtil", "hexToAscii failed: $hex", e)
            ""
        }
    }

    fun convertByteToHexString(byteArray: ByteArray): String {
        val buff = StringBuilder()
        for (byte in byteArray) {
            buff.append(String.format(HEX_FORMAT, byte))
        }
        return buff.toString()
    }
}

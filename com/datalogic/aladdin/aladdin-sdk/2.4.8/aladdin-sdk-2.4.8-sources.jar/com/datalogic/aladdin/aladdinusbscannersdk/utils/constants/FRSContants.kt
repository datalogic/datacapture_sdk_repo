package com.datalogic.aladdin.aladdinusbscannersdk.utils.constants

object FRSContants {
    // FRS PID
    //val SERVICE_PRODUCT_IDS = listOf("16384", "16390", "16386")
    //16386: Magellan-1500 in COM port

    // FRS command
    const val READ_CONFIG_DATA = 0x0011
    const val WRITE_CONFIG_DATA = 0x0010
    const val SAVE_CONFIG = 0x0012
    const val REBOOT_CONFIG = 0x001A
    // header bytes
    const val HEADER_WRITE: Byte = 0x01
    const val EXTENDED_HEADER_WRITE: Byte = 0x81.toByte()
    const val HEADER_READ: Byte = 0x02
    const val EXTENDED_HEADER_READ: Byte = 0x82.toByte()

    // command bytes
    val DEACTIVATE_SERVICEPORT: ByteArray = byteArrayOf(0x00, 0x09, 0x02)
    val ACCESS_CONFIGURATION_MARKER: ByteArray = byteArrayOf(0x00, 0x08)
    val WRITE_CONFIGURATION_ITEM: ByteArray = byteArrayOf(0x00, 0x10)
    val READ_CONFIGURATION_ITEM: ByteArray = byteArrayOf(0x00, 0x11)
    val COPY_CURRENTCONFIGURATION_TO_USERCONFIGURATION: ByteArray = byteArrayOf(0x00, 0x12)
    val DISABLE_SCANNING: ByteArray = byteArrayOf(0x00, 0x14, 0x00)
    val ENABLE_SCANNING: ByteArray = byteArrayOf(0x00, 0x14, 0x01)
    val RESET_SCANNER: ByteArray = byteArrayOf(0x00, 0x1a)
    val GET_EVENT_LOG_ENTRY_N: ByteArray = byteArrayOf(0x00, 0x2c)
    val READ_VERSION: ByteArray = byteArrayOf(0x01, 0x1b)
    val READ_IDENTIFICATION: ByteArray = byteArrayOf(0x01, 0x1c)
    val GET_NUMBER_OF_STATISTICS_ENHANCED: ByteArray = byteArrayOf(0x01, 0x31, 0x00)
    val READ_STATISTIC_ENHANCED: ByteArray = byteArrayOf(0x01, 0x31, 0x01)
    val READ_MEMORY: ByteArray = byteArrayOf(0x01, 0x32)
    val CONFIGURATION_READ: ByteArray = byteArrayOf(0x01, 0x46)
    val GET_EVENT_LOG_ENTRY_N_ENHANCED: ByteArray = byteArrayOf(0x02, 0x2c)
    val READ_SERIAL: ByteArray = byteArrayOf(0x02, 0x40, 0x02)
    val READ_MODEL: ByteArray = byteArrayOf(0x02, 0x40, 0x04)
    val READ_BOARD_SERIAL: ByteArray = byteArrayOf(0x02, 0x40, 0x06)
    val READ_SCANNER_HWID: ByteArray = byteArrayOf(0x02, 0x40, 0x08)
    val READ_SUCCESSIVE_CONFIGURATION_GROUPS: ByteArray = byteArrayOf(0x02, 0x46)
    val IMAGE_CAPTURE: ByteArray = byteArrayOf(0x02, 0x91.toByte())
    val WRITE_SINGLE_RECORD: ByteArray = byteArrayOf(0x06, 0x00, 0x00) // line-by-line
    val WRITE_RECORD_BUFFERED: ByteArray = byteArrayOf(0x06, 0x00, 0x01) // bulk transfer
    val NEXT_LINE: ByteArray = byteArrayOf(0x0D, 0x0A)
    val SUBMIT_TRANSFER_UPDATER: ByteArray = byteArrayOf(0x06, 0x00, 0x02)
    val SOFTWARE_UPDATE_START: ByteArray = byteArrayOf(0x06, 0x10, 0x00)
    val SOFTWARE_UPDATE_SEND_DATA: ByteArray = byteArrayOf(0x06, 0x10, 0x01)
    val SOFTWARE_UPDATE_STATUS: ByteArray = byteArrayOf(0x06, 0x10, 0x02)
    val RECLAIM_INTERNALDRIVE: ByteArray = byteArrayOf(0x15, 0x01, 0x00)
    const val SENSOR_ID = "00"
    const val IMAGE_FORMAT = "01"
    const val IMAGE_ILLUMINATION = "00"

    const val ACKByte: Byte = 0x06
    const val BELByte: Byte = 0x07
    const val DC3Byte: Byte = 0x13
    const val DC4Byte: Byte = 0x14
    const val NAKByte: Byte = 0x15
    const val SYNByte: Byte = 0x16
    const val CANByte: Byte = 0x18

    const val LIMIT_BUFFER: Int = 200000

    // response bytes
    val ACK: ByteArray = byteArrayOf(ACKByte)
    val BEL: ByteArray = byteArrayOf(BELByte)
    val DC3: ByteArray = byteArrayOf(DC3Byte)
    val DC4: ByteArray = byteArrayOf(DC4Byte)
    val NAK: ByteArray = byteArrayOf(NAKByte)
    val SYN: ByteArray = byteArrayOf(SYNByte)
    val CAN: ByteArray = byteArrayOf(CANByte)

    val doubleReadHeaders: HashSet<Byte> = HashSet(listOf(SYNByte, DC3Byte, DC4Byte))

    // config items
    val CI_CONFIGURATION_FILE_ID: ByteArray = byteArrayOf(0x00, 0x60)
    val CA_LABEL_EDIT_SCRIPT: ByteArray = byteArrayOf(0x7F, 0xF8.toByte())

    const val CI_INTERFACE_TYPE: String = "0001"
}
import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.ActivityCompat
import com.datalogic.aladdin.aladdinusbscannersdk.model.Data
import com.datalogic.aladdin.aladdinusbscannersdk.model.DatalogicDeviceManager.onStatusListener
import com.datalogic.aladdin.aladdinusbscannersdk.model.LabelCodeType
import com.datalogic.aladdin.aladdinusbscannersdk.model.LabelIDControl
import com.datalogic.aladdin.aladdinusbscannersdk.model.UsbScanData
import com.datalogic.aladdin.aladdinusbscannersdk.utils.LabelParsing
import com.datalogic.aladdin.aladdinusbscannersdk.utils.bluetoothutils.PairBluetoothDevice
import com.datalogic.aladdin.aladdinusbscannersdk.utils.bluetoothutils.SerialSocket
import com.datalogic.aladdin.aladdinusbscannersdk.utils.bluetoothutils.TextUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.dioString
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.findKeyInHealthList
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.findKeyInInformationList
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.findKeyInStatisticsList
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.byteArrayToHexStringWithSpaces
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.makePrintableString
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.UsbUtils.Companion.addKeyValueIfAbsent
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.ERR_TIMEOUT
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.OPEN_FAILURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.SUCCESS
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.BluetoothPairingStatus
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DIOCmdValue
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DeviceStatus
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.UsbDioListener
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.UsbScanListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean


class DatalogicBluetoothDevice(
    val bluetoothDevice: BluetoothDevice
) {
    private var tag = DatalogicBluetoothDevice::class.java.simpleName
    val id: String = bluetoothDevice.address
    private var isAlreadyBonded = false
    private var bluetoothSocket: BluetoothSocket? = null

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: SerialSocket? = null

    var status: MutableState<DeviceStatus> = mutableStateOf(DeviceStatus.CLOSED)
        private set
    private var onBluetoothDioListener: UsbDioListener? = null
    private var connectResult = BluetoothPairingStatus.Unsuccessful
    var name = ""
    private var jobReadingStatus: AtomicBoolean = AtomicBoolean(true)

    private var labelCodeType: LabelCodeType = LabelCodeType.NONE
    private var labelIDControl: LabelIDControl = LabelIDControl.DISABLE

    private var TAG: String = DatalogicBluetoothDevice::class.java.simpleName

    /**
     * Get the current label code type setting
     * @return Current LabelCodeType value
     */
    fun getCurrentLabelCodeType(): LabelCodeType {
        return labelCodeType
    }

    /**
     * Set the label code type for barcode parsing
     * @param labelCodeType The LabelCodeType to use for parsing
     */
    fun setCurrentLabelCodeType(labelCodeType: LabelCodeType) {
        this.labelCodeType = labelCodeType
    }

    /**
     * Get the current label ID control setting
     * @return Current LabelIDControl value
     */
    fun getCurrentLabelIDControl(): LabelIDControl {
        return labelIDControl
    }

    /**
     * Set the label ID control for barcode parsing
     * @param labelIDControl The LabelIDControl to use for parsing
     */
    fun setCurrentLabelIDControl(labelIDControl: LabelIDControl) {
        this.labelIDControl = labelIDControl
    }

    fun connectDevice(
        serialListener: UsbScanListener,
        context: Activity,
        onComplete: (BluetoothPairingStatus) -> Unit
    ) {
        val executor = Executors.newSingleThreadExecutor()
        executor.execute {
            try {
                status.value = DeviceStatus.NONE
                connectSPP(serialListener, context)
                while (status.value == DeviceStatus.NONE) {
                    Thread.sleep(100)
                }
                Log.d(tag, "[connectDevice] Status: $connectResult")
                if (connectResult == BluetoothPairingStatus.Successful) {
                    status.value = DeviceStatus.OPENED
                } else {
                    status.value = DeviceStatus.CLOSED
                }
                Handler(Looper.getMainLooper()).post {
                    onComplete(connectResult)
                }
            } finally {
                executor.shutdown()
            }
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun connectSPP(
        serialListener: UsbScanListener,
        context: Activity
    ) {
        connectResult = BluetoothPairingStatus.Unsuccessful
        Log.d(tag, "going for fresh connection")
        val bluetoothManager =
            context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val mBluetoothAdapter = bluetoothManager.adapter

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && ActivityCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.d(tag, "[connectSPP] do not have permission for connect")
            return
        }
        if (!PairBluetoothDevice().ensureBluetoothPermissions(context)) {
            Log.d(tag, "[connectSPP] do not have permission for scanning")
            return
        }

        if (bluetoothDevice.name != null && bluetoothDevice.name.isNotEmpty()) {
            name = bluetoothDevice.name
            Log.d(tag, "[connectSPP] Begin connect to device $name")
        }
        GlobalScope.launch {
            try {
                if (mBluetoothAdapter.isDiscovering) {
                    Log.e(tag, "Bluetooth Adapter isDiscovering => cancel Discovering")
                    mBluetoothAdapter.cancelDiscovery()
                }

                // Secure RFCOMM first
                bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(sppUuid)
                bluetoothSocket?.connect()
                Log.i(tag, "[connectSPP] Device ${bluetoothDevice.name} SPP connection successful.")

                // Wire socket BEFORE starting reader
                bluetoothSocket?.let {
                    socket = SerialSocket(context, it)
                    socket?.connected = true
                }

                // Flip reading flag + public status, THEN start reader
                connectResult = BluetoothPairingStatus.Successful
                setStatusDevice(connected = true)
                bluetoothReadingCoroutine(serialListener)
            } catch (exp: java.lang.Exception) {
                Log.e(tag, "[connectSPP] caught exception while connecting SPP device: $exp")
                setStatusDevice(connected = false)
                bluetoothSocket?.close()
                bluetoothSocket = null
                socket = null
                onStatusListener?.onError(OPEN_FAILURE)
            }
        }
        return
    }

    fun clearConnection(context: Context) {
        Log.d(tag, "clearConnection $id")
        isAlreadyBonded = false
        socket?.let { it.connected = false }
        bluetoothSocket?.let {
            it.close()
            setStatusDevice(connected = false)
            Log.i(tag, "clearConnection, bluetoothSocket: $bluetoothSocket")
            bluetoothSocket = null
        }
        status.value = DeviceStatus.CLOSED
    }

    private fun bluetoothReadingCoroutine(serialListener: UsbScanListener) {
        CoroutineScope(Dispatchers.IO).launch {
            while (jobReadingStatus.get()) {
                try {
                    socket?.let { socket ->
                        val response = socket.receiveWithTimeout(100, 100)
                        if (response != null) {
                            val decoded = response.toString(Charsets.UTF_8)
                            Log.i(tag, "[SerialSocket::bluetoothReadingCoroutine] rawLabel: " +
                                    TextUtil.convertByteToHexString(response))
                            Log.i(tag, "[SerialSocket::bluetoothReadingCoroutine] Data scan: $decoded")
                            val barcodeType = extractLabelCodeType(decoded)
                            val bluetoothScanData = UsbScanData(response, decoded, barcodeType ?: "")
                            serialListener.onScan(bluetoothScanData)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(tag, "[bluetoothReadingCoroutine] coroutine errors.", e)
                }
                Thread.sleep(100)
            }
        }
    }

    fun setStatusDevice(connected: Boolean) {
        status.value = if (connected) {
            DeviceStatus.OPENED
        } else {
            DeviceStatus.CLOSED
        }
        jobReadingStatus.set(connected)
    }

    fun dioCommand(commandType: DIOCmdValue, cmd: String, context: Context): String {
        var response: ByteArray? = null

        // Check if device connection is available
        if (status.value == DeviceStatus.OPENED) {
            Log.d(tag, "[dioCommand] commandType: $commandType - cmd: $cmd")
            var commandBytes: ByteArray = byteArrayOf()
            if (commandType != DIOCmdValue.OTHER) {
                commandBytes = commandType.comValue
            } else {
                commandBytes = if (cmd.startsWith("$") || cmd.length == 1) {
                    (cmd + "\r").toByteArray(Charsets.UTF_8)
                } else if (cmd.contains("0x")) {
                    try {
                        cmd.split(",").map {
                            Integer.parseInt(it.trim().replace("0x", ""), 16).toByte()
                        }.toByteArray()
                    } catch (e: NumberFormatException) {
                        Log.d(tag, "[dioCommand] Not a valid Command")

                        return "Not a valid Command"
                    }
                } else {
                    // Try to parse as decimal values
                    try {
                        cmd.split(",").map { it.trim().toInt().toByte() }.toByteArray()
                    } catch (e: NumberFormatException) {
                        // If not parseable, treat as plain string
                        cmd.toByteArray(Charsets.UTF_8)
                    }
                }
            }
            Log.d(tag, "[dioCommand] commandBytes.isNotEmpty() = ${commandBytes.isNotEmpty()}")

            // Execute the command
            if (commandBytes.isNotEmpty()) {
                // Special handling for GOOD_BEEP command which doesn't return a response
                if (commandType == DIOCmdValue.GOOD_BEEP ||
                    commandType == DIOCmdValue.ENABLE_SCANNER ||
                    commandType == DIOCmdValue.DISABLE_SCANNER ||
                    commandType == DIOCmdValue.RESET_SCANNER
                ) {
                    Log.d(tag, "[dioCommand] sendHost: $commandBytes")
                    val result = socket?.send(commandBytes)
                    Log.d(tag, "[dioCommand] sendHost result = $result")

                    return if (result == SUCCESS) {
                        "Command Executed Successfully"
                    } else {
                        "Failed to send beep command"
                    }
                } else if (commandType == DIOCmdValue.ERROR_BEEP) {
                    Log.d(tag, "[dioCommand] sendHost Error beep: $commandBytes")
                    var timeSuccess = 0
                    var result = socket?.send(commandBytes)
                    if (result == SUCCESS) timeSuccess++
                    Thread.sleep(500)
                    Log.d(tag, "[dioCommand] sendHost Error beep again")
                    result = socket?.send(commandBytes)
                    if (result == SUCCESS) timeSuccess++
                    return if (timeSuccess == 2) {
                        "Command Executed Successfully"
                    } else {
                        "Failed to send error beep command"
                    }
                } else if (commandType == DIOCmdValue.OTHER) {
                    // For all other commands, send and wait for response
                    Log.d(tag, "[dioCommand] sendReceive commandType == DIOCmdValue.OTHER")
                    response = socket?.sendReceive(
                        command = commandBytes,
                        startTimeout = 5000,
                        endTimeout = 700
                    )
                } else {
                    Log.d(tag, "[dioCommand] sendReceive")
                    response = socket?.sendReceive(
                        command = commandBytes,
                        startTimeout = 700,
                        endTimeout = 700,
                        isCheckResponse = true
                    )
                }
            } else {
                Log.d(tag, "[dioCommand] Command is empty")
                return "Command is empty"
            }

            // Format the response based on command type
            return if (response != null) {
                formatDioResponse(response, commandType, context)
            } else {
                "Command Executed Successfully"
            }
        }

        return ""
    }

    private fun formatDioResponse(
        buf: ByteArray,
        commandType: DIOCmdValue,
        context: Context
    ): String {
        // Get the DIO information data
        val data = dioString(context)

        // Handle empty response for commands that expect data
        if (buf.isEmpty()) {
            return when (commandType) {
                DIOCmdValue.IDENTIFICATION -> {
                    onBluetoothDioListener?.fireDioErrorEvent(
                        ERR_TIMEOUT,
                        "Unable to get identification information timeout exception."
                    )
                    ""
                }

                DIOCmdValue.HEALTH -> {
                    onBluetoothDioListener?.fireDioErrorEvent(
                        ERR_TIMEOUT,
                        "Error retrieving Health via DirectIO because of timeout exception."
                    )
                    ""
                }

                DIOCmdValue.STATISTICS -> {
                    onBluetoothDioListener?.fireDioErrorEvent(
                        ERR_TIMEOUT,
                        "Error retrieving Statistical data via DirectIO because of timeout exception."
                    )
                    ""
                }

                DIOCmdValue.ENABLE_SCANNER, DIOCmdValue.DISABLE_SCANNER, DIOCmdValue.OTHER -> {
                    "Command Executed Successfully"
                }

                else -> {
                    "Command Executed Successfully"
                }
            }
        }

        // Process standard responses
        return when (commandType) {
            DIOCmdValue.IDENTIFICATION, DIOCmdValue.HEALTH, DIOCmdValue.STATISTICS -> {
                processStandardResponse(buf, commandType, data)
            }

            DIOCmdValue.ENABLE_SCANNER, DIOCmdValue.DISABLE_SCANNER, DIOCmdValue.GOOD_BEEP, DIOCmdValue.ERROR_BEEP -> {
                "Command Executed Successfully"
            }

            // For OTHER command types, format response to include both hex and ASCII
            DIOCmdValue.OTHER -> {
                // Format the response with both hex and ASCII representations
                val hexString = byteArrayToHexStringWithSpaces(buf)

                // Create ASCII representation for printable characters
                val asciiString = makePrintableString(buf)

                // Combine both formats in the response
                "Hex: $hexString\nASCII: $asciiString"
            }

            // For any other command types not specifically handled
            else -> {
                // Format the response as a hex string
                SmartUtil.bytesToHex0X(buf).trim()
            }
        }
    }

    private fun processStandardResponse(
        buf: ByteArray,
        commandType: DIOCmdValue,
        data: Data
    ): String {
        val separator = "[\u0003\u0001]" // ETX character
        val prefix = when (commandType) {
            DIOCmdValue.IDENTIFICATION -> "Sp<"
            DIOCmdValue.HEALTH -> "Sp="
            DIOCmdValue.STATISTICS -> "Sp>"
            else -> ""
        }

        val strInfoString = String(buf)

        // For HEALTH command, handle case where data starts with SOH
        val segments = if (commandType == DIOCmdValue.HEALTH && strInfoString.contains("\u0001")) {
            strInfoString.substringAfter("\u0001").split(separator.toRegex()).toTypedArray()
        } else {
            strInfoString.split(separator.toRegex()).toTypedArray()
        }

        // Process segments and build result map
        val resultMap = HashMap<String, String>()

        for (segment in segments) {
            val truncated = segment.replace("\\p{Cntrl}".toRegex(), "")
            val truncated2 = truncated.replace(prefix.toRegex(), "")

            if (truncated2.length >= 1) {
                val key = truncated2.substring(0, 1)
                val name = when (commandType) {
                    DIOCmdValue.IDENTIFICATION -> findKeyInInformationList(data.Information, key)
                    DIOCmdValue.HEALTH -> findKeyInHealthList(data.Health, key)
                    DIOCmdValue.STATISTICS -> findKeyInStatisticsList(data.Statistics, key)
                    else -> null
                }

                if (name != null) {
                    val value = if (truncated2.length > 1) truncated2.substring(1) else " "
                    addKeyValueIfAbsent(resultMap, name, "$truncated2 {$name:$value}")
                }
            }
        }

        return resultMap.values.joinToString(separator = ", ")
    }

    fun registerBluetoothDioListener(listener: UsbDioListener): Int {
        return if (onBluetoothDioListener == null) {
            onBluetoothDioListener = listener
            SUCCESS
        } else {
            AladdinConstants.LISTENER_ALREADY_REGISTERED_ERROR
        }
    }

    fun unregisterBluetoothDioListener(listener: UsbDioListener): Int {
        return if (listener == onBluetoothDioListener) {
            onBluetoothDioListener = null
            SUCCESS
        } else {
            AladdinConstants.LISTENER_NOT_REGISTERED_ERROR
        }
    }

    /**
     * Extract and process label code type from barcode data based on current settings.
     * labelIDControl determines the position where to look for label identification data.
     * labelCodeType determines which type of code to extract and identify the barcode type.
     *
     * @param barcodeData The raw barcode data string to process
     * @return Processed barcode data with appropriate label code identification
     */
    private fun extractLabelCodeType(barcodeData: String): String? {
        if (labelCodeType == LabelCodeType.NONE || labelIDControl == LabelIDControl.DISABLE) {
            Log.d(TAG, "Label processing disabled, returning original data")
            return ""
        }

        try {
            // Extract label identification data from the specified position
            val labelIdentificationData = when (labelIDControl) {
                LabelIDControl.PREFIX -> {
                    // Look for identification data at the beginning of barcode data
                    extractIdentification(barcodeData, LabelIDControl.PREFIX)
                }

                LabelIDControl.SUFFIX -> {
                    // Look for identification data at the end of barcode data
                    extractIdentification(barcodeData, LabelIDControl.SUFFIX)
                }

                LabelIDControl.DISABLE -> {
                    // Already handled above, but included for completeness
                    null
                }
            }

            if (labelIdentificationData == null) {
                Log.d(TAG, "No label identification data found at ${labelIDControl.code} position")
                return ""
            }

            Log.d(
                TAG,
                "Found label identification data: $labelIdentificationData at ${labelIDControl.code} position"
            )

            // Use the extracted identification data to find the label type based on labelCodeType
            val labelFormatEntry = when (labelCodeType) {
                LabelCodeType.USA -> {
                    LabelParsing.getLabelFormatByUSACode(labelIdentificationData)?.also {
                        Log.d(
                            TAG,
                            "Identified label type by USA code '$labelIdentificationData': ${it.tagName}"
                        )
                    }
                }

                LabelCodeType.EU -> {
                    LabelParsing.getLabelFormatByEUCode(labelIdentificationData)?.also {
                        Log.d(
                            TAG,
                            "Identified label type by EU code '$labelIdentificationData': ${it.tagName}"
                        )
                    }
                }

                LabelCodeType.COMSC -> {
                    LabelParsing.getLabelFormatBySCRS232Code(labelIdentificationData)?.also {
                        Log.d(
                            TAG,
                            "Identified label type by COMSC/SCRS232 code '$labelIdentificationData': ${it.tagName}"
                        )
                    }
                }

                LabelCodeType.NONE -> null
            }

            if (labelFormatEntry == null) {
                Log.d(
                    TAG,
                    "Could not identify label type for ${labelCodeType.code} code: $labelIdentificationData"
                )
                return ""
            }

            Log.d(TAG, "Successfully identified barcode type: ${labelFormatEntry.tagName}")

            // Return the original barcode data since the identification was successful
            // The identification data was used for type detection, not for modifying the output
            return labelFormatEntry.tagName
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting label code type from data: $barcodeData", e)
            return ""
        }
    }

    /**
     * Extract identification data from the prefix (beginning) of barcode data
     * This looks for common label identification patterns at the start
     */
    private fun extractIdentification(
        barcodeData: String,
        labelIDControl: LabelIDControl
    ): String? {
        if (barcodeData.isEmpty()) return null

        var extractedLabelID: String = ""
        var barcodeDataToExtract = barcodeData

        if (labelIDControl == LabelIDControl.PREFIX) {
            if (barcodeDataToExtract.length >= 4) {
                extractedLabelID = barcodeDataToExtract.substring(0, 4)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
            // Check for 2-character codes (like "46", "41", etc.)
            if (barcodeDataToExtract.length >= 2) {
                extractedLabelID = barcodeDataToExtract.substring(0, 2)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
            // Check for single character codes
            if (barcodeDataToExtract.isNotEmpty()) {
                extractedLabelID = barcodeDataToExtract.substring(0, 1)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
        } else if (labelIDControl == LabelIDControl.SUFFIX) {
            // Try different suffix lengths commonly used for label identification
            // Check for 4-character codes first (like "4646", "5152", etc.)
            if (barcodeDataToExtract.length >= 4) {
                extractedLabelID = barcodeDataToExtract.substring(barcodeData.length - 4)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
            // Check for 2-character codes (like "46", "41", etc.)
            if (barcodeDataToExtract.length >= 2) {
                val extractedLabelID = barcodeDataToExtract.substring(barcodeData.length - 2)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
            // Check for single character codes
            if (barcodeDataToExtract.isNotEmpty()) {
                val extractedLabelID = barcodeDataToExtract.substring(barcodeData.length - 1)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
        }

        return null
    }

    /**
     * Check if the given code is a valid identification code based on current labelCodeType
     */
    private fun isValidIdentificationCode(code: String): Boolean {
        val codeAsciiToHex = CharsUtil.asciiStringToHexString(code)

        return when (labelCodeType) {
            LabelCodeType.USA -> LabelParsing.isValidUSACode(codeAsciiToHex)
            LabelCodeType.EU -> LabelParsing.isValidEUCode(codeAsciiToHex)
            LabelCodeType.COMSC -> LabelParsing.getLabelFormatBySCRS232Code(codeAsciiToHex) != null
            LabelCodeType.NONE -> false
        }
    }

}
package com.datalogic.aladdin.aladdinusbscannersdk.model

data class DataRowCCF(
    var rowNumber: Int,
    var rowData: String
)

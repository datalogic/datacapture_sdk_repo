package com.datalogic.aladdin.aladdinusbscannersdk.usbaccess

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.REQUEST_CODE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.REQUEST_VALUE_OUT
import java.io.ByteArrayOutputStream

class HostOem() {
    var usbDeviceConnection: UsbDeviceConnection? = null // Should move to connection
    var usbInterface: UsbInterface? = null
    var usbEndpoint: UsbEndpoint? = null

    // scale interface and endpoint
    var scaleInterface: UsbInterface? = null
    var scaleEndpoint: UsbEndpoint? = null

    private val commandResponseLock = Object()
    private var TAG: String = HostOem::class.java.simpleName

    // This function will send the command to the scanner
    fun send(command: ByteArray): Boolean {
        // Synchronize with the same lock used for sending commands
        synchronized(commandResponseLock) {
            // Check if the USB connection is available
            if (usbDeviceConnection == null && usbInterface == null) {
                Log.e(TAG, "No USB device connection available || null usbInterface.")
                return false
            }

            // Define the request type, request, value, and index (these vary by device)
            val requestType =
                UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT  // Example: Host-to-device, Class request, Interface recipient
            val request = REQUEST_CODE      // Example request code (based on device specification)
            val value = REQUEST_VALUE_OUT     // Example value (depends on the scanner)
            val index =
                usbInterface!!.id // Interface index (if the device has multiple interfaces, specify the correct one)

            // Send the control transfer with the provided byteArray data
            val result = usbDeviceConnection!!.controlTransfer(
                requestType, request,
                value, index, command, command.size, 100
            )

            return if (result >= 0) {
                Log.d(TAG, "Control command sent successfully. Bytes transferred: $result")
                true
            } else {
                Log.d(TAG, "Failed to send control command. Result: $result")
                false
            }
        }
    }

    /**
     * Send a command specifically to the scale interface
     */
    fun sendScaleCommand(command: ByteArray): Boolean {
        if (scaleInterface == null || usbDeviceConnection == null) {
            Log.e(TAG, "Scale interface not available")
            return false
        }

        try {
            // Use control transfer specifically for the scale interface
            val requestType =
                UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
            val request = REQUEST_CODE      // HID Set_Report request
            val value = REQUEST_VALUE_OUT    // Output report
            val index = scaleInterface!!.id  // Use the scale interface ID

            val result = usbDeviceConnection!!.controlTransfer(
                requestType, request, value, index, command, command.size, 100
            )

            return if (result >= 0) {
                Log.d(TAG, "Scale command sent successfully. Bytes transferred: $result")
                true
            } else {
                Log.e(TAG, "Failed to send scale command. Result: $result")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error sending scale command", e)
            return false
        }
    }

    fun receiveBothScaleAndBarcodeWithTimeout(
        startTimeout: Long,
        endTimeout: Long,
        isGettingScaleData: Boolean = false
    ): Pair<ByteArray?, ByteArray?> {
        // Check for barcode connection first
        if (usbDeviceConnection == null || usbEndpoint == null) {
            return Pair(null, null)
        }

        // Check if we should read scale data and if we can read it
        val shouldReadScale = isGettingScaleData && scaleEndpoint != null

        val scaleData: ByteArray? = if (shouldReadScale) {
            receiveOnScaleInterfaceWithTimeout(startTimeout, endTimeout)
        } else {
            ByteArray(0)
        }

        val barcodeData: ByteArray? = receiveOnDeviceInterfaceWithTimeout(startTimeout, endTimeout)

        return Pair(
            if (scaleData != null) scaleData else null,
            if (barcodeData != null) barcodeData else null
        )
    }

    fun receiveOnScaleInterfaceWithTimeout(startTimeout: Long, endTimeout: Long): ByteArray? {
        // Synchronize with the same lock used for sending commands
        synchronized(commandResponseLock) {
            if (usbDeviceConnection == null && scaleEndpoint == null) {
                return null
            } else {
                var timeout = startTimeout
                var lastTime = System.currentTimeMillis()
                val buffer = ByteArrayOutputStream()
                val data = ByteArray(scaleEndpoint!!.maxPacketSize)
                // Continue reading until we have a complete message or timeout
                while (System.currentTimeMillis() - lastTime < timeout) {
                    if (usbDeviceConnection!!.bulkTransfer(
                            scaleEndpoint, data,
                            scaleEndpoint!!.maxPacketSize, 50
                        ) > 0
                    ) {
                        if (data.isNotEmpty()) {
                            buffer.write(data, 0, data.size)
                            lastTime = System.currentTimeMillis()
                            timeout = endTimeout
                        } else {
                            break
                        }
                    }
                }
                return if (buffer.size() > 0) buffer.toByteArray() else null
            }
        }
    }

    fun receiveOnDeviceInterfaceWithTimeout(startTimeout: Long, endTimeout: Long): ByteArray? {
        // Synchronize with the same lock used for sending commands
        synchronized(commandResponseLock) {
            if (usbDeviceConnection == null && usbEndpoint == null) {
                return null
            } else {
                var timeout = startTimeout
                var lastTime = System.currentTimeMillis()
                val buffer = ByteArrayOutputStream()
                val data = ByteArray(usbEndpoint!!.maxPacketSize)
                // Continue reading until we have a complete message or timeout
                while (System.currentTimeMillis() - lastTime < timeout) {
                    if (usbDeviceConnection!!.bulkTransfer(
                            usbEndpoint, data,
                            usbEndpoint!!.maxPacketSize, 50
                        ) > 0
                    ) {
                        if (data.isNotEmpty()) {
                            buffer.write(data, 0, data.size)
                            lastTime = System.currentTimeMillis()
                            timeout = endTimeout
                        } else {
                            break
                        }
                    }
                }
                return if (buffer.size() > 0) buffer.toByteArray() else null
            }
        }
    }

    fun sendReceive(command: ByteArray): ByteArray? {
        // Synchronize with the same lock used for sending commands
        synchronized(commandResponseLock) {
            val sendResult: Boolean = send(command)
            return if (sendResult) {
                receiveOnDeviceInterfaceWithTimeout(500, 500)
            } else {
                null
            }
        }
    }

    private fun byteArrayToString(data: ByteArray?): String {
        val result: String
        val sb = java.lang.StringBuilder()
        if (data == null) {
            return "[0] **invalid packet - byte array is null."
        }
        if (data.size == 0) {
            return "[0] **invalid packet - byte array is empty."
        }
        for (datum in data) {
            sb.append(String.format(" 0x%02X", datum))
        }
        result = "[" + data.size + "]" + sb.toString()
        return result
    }

}
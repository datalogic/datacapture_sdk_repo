package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

/**
 * Scanner device status states, simplified to essential operations
 */
enum class DeviceStatus {
    CLOSED,   // Device is closed/disconnected
    OPENED,   // Device is connected, claimed, and ready to scan
    NONE      // Special state for UI/error handling only
}
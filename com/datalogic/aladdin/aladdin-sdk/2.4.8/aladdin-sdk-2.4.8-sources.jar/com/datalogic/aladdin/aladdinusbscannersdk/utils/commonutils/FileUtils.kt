package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils

import android.content.Context
import android.icu.text.SimpleDateFormat
import android.os.Environment
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.RandomAccessFile
import java.io.Reader
import java.util.Date
import java.util.Locale

object FileUtils {
    private const val MAX_BUFFER: Int = 4096

    @Throws(IOException::class)
    fun writeEntireFile(toFile: File, text: String) {
        val parent = toFile.parentFile
        if (parent != null && !parent.exists()) {
            parent.mkdirs()
        }
        FileWriter(toFile).use { writer ->
            writer.write(text)
        }
    }

    @Throws(IOException::class)
    fun readFully(reader: Reader, bufferSize: Int): String {
        require(bufferSize > 0) { "Buffer size must be greater than 0" }

        val buffer = CharArray(bufferSize)
        val textBuffer = StringBuilder()

        reader.use {
            var length: Int
            while (reader.read(buffer).also { length = it } != -1) {
                textBuffer.appendRange(buffer, 0, length)
            }
        }

        return textBuffer.toString()
    }

    @Throws(IOException::class)
    fun readFully(file: File): String {
        InputStreamReader(FileInputStream(file)).use { reader ->
            return readFully(reader, MAX_BUFFER)
        }
    }

    fun appendStringToFile(toFile: File, text: String) {
        try {
            val parent = toFile.parentFile
            if (parent != null && !parent.exists()) {
                parent.mkdirs()
            }
            FileWriter(toFile, true).use { writer ->
                writer.write(text)
            }
        } catch (ioe: IOException) {
            System.err.println("Append New String Error: ${ioe.message}")
        }
    }

    @Throws(Exception::class)
    fun tmpFile(context: Context, fileName: String): File {
        val timestamp =
            SimpleDateFormat("HH_mm_ss_SSSSSSS").format(Date()) // Added Locale for consistency

        // Corrected directory name construction
        val uniqueDirName = "tempDir_$timestamp" // Just the unique part
        val tmpDir = File(context.cacheDir, uniqueDirName) // Create 'tempDir_timestamp' INSIDE filesDir

        if (!tmpDir.exists()) {// Not usually needed for a directory you are about to use and then delete its contents
            if (!tmpDir.mkdirs()) { // Use mkdirs() to create parent dirs if needed, though filesDir should exist
                throw IOException("Could not create temp directory: ${tmpDir.absolutePath}")
            }
        }

        val tmpFile = File(tmpDir, fileName)
        tmpFile.deleteOnExit()
        // Managing temp file deletion is often better done explicitly when you're finished.
        return tmpFile
    }
}



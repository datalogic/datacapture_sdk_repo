package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class ConfigurationFeature(val comFeatureId: String,val magellanfeatureId: ByteArray, val featureName: String) {
    FETCH_ALL(
        "\$S,cC3EN,cC8EN,c8BEN,c3BEN,cABEN,cEBEN,cI2EN,c4BEN,cP4EN,cPOEN,cDMEN,cQREN,cAZEN,cMXEN\r",
        byteArrayOf(),"Query All"
    ),
    THIRTYNINE("CC3EN", byteArrayOf( 0x00, 0x8E.toByte()),"Code 39"),
    ONETWENTYEIGHT("CC8EN",byteArrayOf(0x00, 0x92.toByte()), "Code 128"),
    EANEIGHT("C8BEN",byteArrayOf(0x02, 0xD2.toByte()), "EAN 8"),
    EANTHIRTEEN("C3BEN",byteArrayOf(0x02, 0xD3.toByte()), "EAN 13"),
    UPCA("CABEN",byteArrayOf(0x02, 0xD0.toByte()),  "UPC A"),
    UPCE("CEBEN", byteArrayOf(0x02, 0xD1.toByte()),"UPC E"),
    INTERLEAVED("CI2EN", byteArrayOf(0x00, 0x90.toByte()),"Interleaved 2 of 5"),
    GS1DATABAR("C4BEN",  byteArrayOf(),"GS1 Databar"),
    PDF417("CP4EN",byteArrayOf(0x05, 0xA1.toByte()), "PDF417"),
    //POSTNET("CPOEN", "Postnet"),
    IMB("CPOEN", byteArrayOf(0x05, 0x27.toByte()),"IMB"),
    DATAMATRIX("CDMEN", byteArrayOf(0x01, 0x00.toByte()),"Data Matrix"),
    QR("CQREN",byteArrayOf(0x03, 0xD7.toByte()), "QR"),
    ATZEC("CAZEN",byteArrayOf(0x04, 0x30.toByte()), "Aztec"),
    MAXICODE("CMXEN", byteArrayOf(0x03, 0xD0.toByte()),"Maxicode");

    companion object {
        private val map = ConfigurationFeature.values().associateBy(ConfigurationFeature::comFeatureId)
        fun fromComFeatureId(featureId: String) = map[featureId]

        private val magellanfeatureIdMap = ConfigurationFeature.values().associateBy(ConfigurationFeature::magellanfeatureId)
        fun fromMagellanfeatureId(magellanfeatureId: ByteArray) = magellanfeatureIdMap[magellanfeatureId]
    }

}
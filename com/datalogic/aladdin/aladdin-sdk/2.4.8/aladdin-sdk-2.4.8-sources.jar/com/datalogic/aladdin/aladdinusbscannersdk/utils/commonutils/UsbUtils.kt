package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import com.datalogic.aladdin.aladdinusbscannersdk.model.DatalogicDeviceManager

class UsbUtils {

    companion object {
        private var TAG: String = DatalogicDeviceManager::class.java.simpleName
        /**
         * Function to get the HID interface of a device.
         *
         * @param device the device to query.
         * @return the HID interface of the device.
         */
        fun getHIDInterface(device: UsbDevice?): UsbInterface? {
            requireNotNull(device) { "Device can not be null" }
            for (i in 0 until device.interfaceCount) {
                if (device.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_HID) {
                    return device.getInterface(i)
                }
            }
            return null
        }

        /**
         * Function to get the input endpoint
         *
         * @param usbInterface the interface to query.
         * @return the input enrpoint of the interface.
         */
        fun getInEndpoint(usbInterface: UsbInterface): UsbEndpoint? {
            for (i in 0 until usbInterface.endpointCount) {
                val endpoint = usbInterface.getEndpoint(i)
                if (endpoint.type == UsbConstants.USB_ENDPOINT_XFER_INT && endpoint.direction == UsbConstants.USB_DIR_IN) return endpoint
            }
            return null
        }

        // Function to add a new key-value pair to the HashMap if the key does not already exist
        fun addKeyValueIfAbsent(map: HashMap<String, String>, key: String, value: String) {
            if (!map.containsKey(key)) {
                map[key] = value
            }
        }
    }

}
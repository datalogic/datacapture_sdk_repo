package com.datalogic.aladdin.aladdinusbscannersdk.model

data class UsbScanData(
    val rawData: ByteArray,
    val barcodeData: String,
    val barcodeType: String
)
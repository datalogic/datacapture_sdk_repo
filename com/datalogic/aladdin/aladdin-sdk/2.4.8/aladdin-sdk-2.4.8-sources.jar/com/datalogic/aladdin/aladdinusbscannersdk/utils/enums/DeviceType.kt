package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class DeviceType {
    HHS,
    FRS
}

enum class DeviceConnectType {
    USB,
    BLUETOOTH
}
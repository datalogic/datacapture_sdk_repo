package com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners

import android.bluetooth.BluetoothDevice
import android.hardware.usb.UsbDevice

interface BluetoothListener {

    /**
     * Function called when a device is attached.
     */
    fun onDeviceAttachedListener(device: BluetoothDevice)

    /**
     * Function called when a device is detached.
     */
    fun onDeviceDetachedListener(device: BluetoothDevice)

}
package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS

import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil

object FRSScannerTypes {
    const val UNKNOWN_XXXX: Byte = 0xFF.toByte()
    const val TOWNSHEND_1400i2D: Byte = 0x23
    const val TOWNSHEND_1100i: Byte = 0x24
    const val HUYGENS_8300: Byte = 0x2A
    const val HUYGENS_8300_SCALE: Byte = 0x2B

    // Using CP here to indicate the Checkpoint EAS.
    const val RIGGS_8500XT_CP: Byte = 0x2C
    const val RIGGS_8500XT_CP_SCALE: Byte = 0x2D
    const val HUYGENS_8400: Byte = 0x2E
    const val HUYGENS_8400_SCALE: Byte = 0x2F

    // Using SM here to specify the Sensormatic EAS.
    const val RIGGS_8500XT_SM: Byte = 0x30
    const val RIGGS_8500XT_SM_SCALE: Byte = 0x31
    const val HALLEY_2200_2300: Byte = 0x32
    const val TIGER_3200VSi: Byte = 0x34
    const val LION_3300HSi: Byte = 0x35
    const val HALEN_800i: Byte = 0x36
    const val MOSAIC_9800i: Byte = 0x37
    const val MOSAIC_LITE_9800i: Byte = 0x38
    const val TESSERA_9300i: Byte = 0x39
    const val TESSERA_9400i: Byte = 0x3A

    const val CUMULUS_3410VSI: Byte = 0x3B
    const val CIRRUS_3450VSI: Byte = 0x3C
    const val CUMULUS_3510HSI: Byte = 0x3D
    const val NIMBUS_3550HSI: Byte = 0x3E
    const val BOTERO_1500i: Byte = 0x3F

    const val FRESCO_9600i: Byte = 0x40 //64
    const val FRESCO_9900i: Byte = 0x41 //65

    const val TESSERA_9400i_CD: Byte = 0x43
    const val MOSAIC_9800i_CD: Byte = 0x44

    const val APOLLO_9550i: Byte = 0x45
    const val APOLLO_9550iB: Byte = 0x46
    const val CURIE_900i: Byte = 0x47

    const val GEMINI_3610i: Byte = 0x48

    const val GEMINI_3710i: Byte = 0x49

    const val ACK_BYTE: Byte = 0x06
    const val BEL_BYTE: Byte = 0x07
    const val DC3_BYTE: Byte = 0x13
    const val DC4_BYTE: Byte = 0x14
    const val NAK_BYTE: Byte = 0x15
    const val SYN_BYTE: Byte = 0x16
    const val CAN_BYTE: Byte = 0x18

    val ACK_BYTEARRAY: ByteArray = byteArrayOf(0x06)
    val BEL_BYTEARRAY: ByteArray = byteArrayOf(0x07)
    val DC3_BYTEARRAY: ByteArray = byteArrayOf(0x13)
    val DC4_BYTEARRAY: ByteArray = byteArrayOf(0x14)
    val NAK_BYTEARRAY: ByteArray = byteArrayOf(0x15)
    val SYN_BYTEARRAY: ByteArray = byteArrayOf(0x16)
    val CAN_BYTEARRAY: ByteArray = byteArrayOf(0x18)
    const val ACK = "ACK"
    const val LIMIT_BUFFER = 200000

    val CONFIGURATION_READ = byteArrayOf(0x01, 0x46.toByte())
    val READ_SUCCESSIVE_CONFIGURATION_GROUPS: ByteArray = byteArrayOf(0x02, 0x46.toByte())
    val DOUBLE_READ_HEADERS: HashSet<Byte?> = hashSetOf(SYN_BYTE, DC3_BYTE, DC4_BYTE)
    val WRITE_CONFIGURATION_ITEM = byteArrayOf(0x00, 0x10)
    val scannerTypeToText: HashMap<Byte?, String?> = HashMap()

    init {
        scannerTypeToText[TOWNSHEND_1400i2D] = "Magellan-1400i2D"
        scannerTypeToText[UNKNOWN_XXXX] = "Unknown"
        scannerTypeToText[TOWNSHEND_1100i] = "Magellan-1100i"
        scannerTypeToText[HUYGENS_8300] = "Magellan-8300"
        scannerTypeToText[HUYGENS_8300_SCALE] = "Magellan-8300"
        scannerTypeToText[RIGGS_8500XT_CP] = "Magellan-8500"
        scannerTypeToText[RIGGS_8500XT_CP_SCALE] = "Magellan-8500"
        scannerTypeToText[RIGGS_8500XT_SM] = "Magellan-8500"
        scannerTypeToText[RIGGS_8500XT_SM_SCALE] = "Magellan-8500"
        scannerTypeToText[HUYGENS_8400] = "Magellan-8400"
        scannerTypeToText[HUYGENS_8400_SCALE] = "Magellan-8400"
        scannerTypeToText[HALLEY_2200_2300] = "Magellan-2X00"
        scannerTypeToText[TIGER_3200VSi] = "Magellan-3200VSi"
        scannerTypeToText[LION_3300HSi] = "Magellan-3300HSi"
        scannerTypeToText[HALEN_800i] = "Magellan-800i"
        scannerTypeToText[MOSAIC_9800i] = "Magellan-9800i"
        scannerTypeToText[MOSAIC_LITE_9800i] = "Magellan-9800i lite"
        scannerTypeToText[MOSAIC_9800i_CD] = "Magellan-9800i-CD"
        // Tessera Family
        scannerTypeToText[TESSERA_9300i] = "Magellan-9300i"
        scannerTypeToText[TESSERA_9400i] = "Magellan-9400i"
        scannerTypeToText[TESSERA_9400i_CD] = "Magellan-9400i-CD"
        // Cumulus Family
        scannerTypeToText[CUMULUS_3410VSI] = "Magellan-3410VSI"
        scannerTypeToText[CUMULUS_3510HSI] = "Magellan-3510HSI"
        // Cirrus Family
        scannerTypeToText[CIRRUS_3450VSI] = "Magellan-3450VSI"
        scannerTypeToText[NIMBUS_3550HSI] = "Magellan-3550HSI"
        // Botero
        scannerTypeToText[BOTERO_1500i] = "Magellan-1500i"
        // Fresco Family
        scannerTypeToText[FRESCO_9600i] = "Magellan-9600i"
        scannerTypeToText[FRESCO_9900i] = "Magellan-9900i"
        // Curie
        scannerTypeToText[CURIE_900i] = "Magellan-900i"
        // Apollo family
        scannerTypeToText[APOLLO_9550i] = "Magellan-9550i"
        scannerTypeToText[APOLLO_9550iB] = "Magellan-9550iB"
        scannerTypeToText[GEMINI_3610i] = "Magellan-3610i"
        scannerTypeToText[GEMINI_3710i] = "Magellan-3710i"
    }

    // incomplete list because only used for Fresco ethernet device detection
    val hwidToScannerType: HashMap<String?, Byte?> = HashMap<String?, Byte?>()

    init {
        hwidToScannerType["9600"] = FRESCO_9600i
        hwidToScannerType["9900"] = FRESCO_9900i
    }

    val scannerTypeToScanalyzerText: HashMap<Byte?, String?> = HashMap<Byte?, String?>()

    init {
        scannerTypeToScanalyzerText[TOWNSHEND_1400i2D] = "1400i2D"
        scannerTypeToScanalyzerText[UNKNOWN_XXXX] = "Unknown"
        scannerTypeToScanalyzerText[TOWNSHEND_1100i] = "1100i"
        scannerTypeToScanalyzerText[HUYGENS_8300] = "8300"
        scannerTypeToScanalyzerText[HUYGENS_8300_SCALE] = "8300"
        scannerTypeToScanalyzerText[RIGGS_8500XT_CP] = "8500"
        scannerTypeToScanalyzerText[RIGGS_8500XT_CP_SCALE] = "8500"
        scannerTypeToScanalyzerText[RIGGS_8500XT_SM] = "8500"
        scannerTypeToScanalyzerText[RIGGS_8500XT_SM_SCALE] = "8500"
        scannerTypeToScanalyzerText[HUYGENS_8400] = "8400"
        scannerTypeToScanalyzerText[HUYGENS_8400_SCALE] = "8400"
        scannerTypeToScanalyzerText[HALLEY_2200_2300] = "2X00"
        scannerTypeToScanalyzerText[TIGER_3200VSi] = "3200VSi"
        scannerTypeToScanalyzerText[LION_3300HSi] = "3300HSi"
        scannerTypeToScanalyzerText[HALEN_800i] = "800i"
        scannerTypeToScanalyzerText[MOSAIC_9800i] = "9800i"
        scannerTypeToScanalyzerText[MOSAIC_LITE_9800i] = "9800i lite"
        scannerTypeToScanalyzerText[MOSAIC_9800i_CD] = "9800i-CD"
        // Tessera Family
        scannerTypeToScanalyzerText[TESSERA_9300i] = "9300i"
        scannerTypeToScanalyzerText[TESSERA_9400i] = "9400i"
        scannerTypeToScanalyzerText[TESSERA_9400i_CD] = "9400i-CD"
        // Cumulus Family
        scannerTypeToScanalyzerText[CUMULUS_3410VSI] = "3410VSI"
        scannerTypeToScanalyzerText[CUMULUS_3510HSI] = "3510HSI"
        // Cirrus Family
        scannerTypeToScanalyzerText[CIRRUS_3450VSI] = "3450VSI"
        scannerTypeToScanalyzerText[NIMBUS_3550HSI] = "3550HSI"
        // Botero
        scannerTypeToScanalyzerText[BOTERO_1500i] = "1500i"
        // Fresco Family
        scannerTypeToScanalyzerText[FRESCO_9600i] = "9600i"
        scannerTypeToScanalyzerText[FRESCO_9900i] = "9900i"
        // Curie
        scannerTypeToScanalyzerText[CURIE_900i] = "900i"
        // Apollo Family
        scannerTypeToScanalyzerText[APOLLO_9550i] = "9550i"
        scannerTypeToScanalyzerText[APOLLO_9550iB] = "9550iB"
    }

    // used to map names of scanners as displayed to XML name. Needed because multiple FRS products use the same XML.
    // Caution: If this map is updated, please update this Map on Angular code too.
    val scannerTextToXmlText: HashMap<String?, String?> = HashMap<String?, String?>()

    init {
        scannerTextToXmlText["Magellan-9800i-CD"] = "Magellan-9800i"
        scannerTextToXmlText["Magellan-9800i lite"] = "Magellan-9800i"
        scannerTextToXmlText["Magellan-9300i"] = "Magellan-9400i"
        scannerTextToXmlText["Magellan-9400i-CD"] = "Magellan-9400i"
        scannerTextToXmlText["Magellan-3410VSI"] = "Magellan-3x10i"
        scannerTextToXmlText["Magellan-3510HSI"] = "Magellan-3x10i"
        scannerTextToXmlText["Magellan-3450VSI"] = "Magellan-3x50i"
        scannerTextToXmlText["Magellan-3550HSI"] = "Magellan-3x50i"
        scannerTextToXmlText["Magellan-9600i"] = "Magellan-9900i"
    }

    // FRS firmware file uses the USB OEM PID as a unique identifier. USB HID kbd is also unique thus listed
    // USB COM is not unique and the same for all the below listed platforms so not used here.
    var scannerTypeToPid: HashMap<Byte, Array<String>> = HashMap()

    init {
        scannerTypeToPid[MOSAIC_9800i] =
            arrayOf("1511", "2511")
        scannerTypeToPid[MOSAIC_LITE_9800i] =
            arrayOf("1511", "2511")
        scannerTypeToPid[MOSAIC_9800i_CD] =
            arrayOf("1511", "2511")
        // Tessera Family
        scannerTypeToPid[TESSERA_9300i] =
            arrayOf("1512", "2512")
        scannerTypeToPid[TESSERA_9400i] =
            arrayOf("1512", "2512")
        scannerTypeToPid[TESSERA_9400i_CD] =
            arrayOf("1512", "2512")
        // Cumulus Family
        scannerTypeToPid[CUMULUS_3410VSI] =
            arrayOf("1513", "2513")
        scannerTypeToPid[CUMULUS_3510HSI] =
            arrayOf("1513", "2513")
        // Cirrus Family
        scannerTypeToPid[CIRRUS_3450VSI] =
            arrayOf("1514", "2514")
        scannerTypeToPid[NIMBUS_3550HSI] =
            arrayOf("1514", "2514")
        // Botero
        scannerTypeToPid[BOTERO_1500i] =
            arrayOf("1604", "2604")
        // Fresco Family
        scannerTypeToPid[FRESCO_9600i] =
            arrayOf("1515", "1516", "2515")
        scannerTypeToPid[FRESCO_9900i] =
            arrayOf("1515", "1516", "2515")
        // Curie (not including USB kbd here because it is the same as Apollo
        scannerTypeToPid[CURIE_900i] = arrayOf("1605")
        // Apollo
        scannerTypeToPid[APOLLO_9550i] = arrayOf("1517")
        scannerTypeToPid[APOLLO_9550iB] = arrayOf("1517")
        scannerTypeToPid[GEMINI_3610i] = arrayOf("1517", "1518")
        scannerTypeToPid[GEMINI_3710i] = arrayOf("1517", "1518")

    }

    // timeout in milliseconds
    var scannerTypeToHDLTimeout: HashMap<Byte, Int> = HashMap()

    init {
        scannerTypeToHDLTimeout[MOSAIC_9800i] = 1000
        scannerTypeToHDLTimeout[MOSAIC_LITE_9800i] = 1000
        scannerTypeToHDLTimeout[MOSAIC_9800i_CD] = 1000
        // Tessera Family
        scannerTypeToHDLTimeout[TESSERA_9300i] = 1000
        scannerTypeToHDLTimeout[TESSERA_9400i] = 30000
        scannerTypeToHDLTimeout[TESSERA_9400i_CD] = 30000
        // Cumulus Family
        scannerTypeToHDLTimeout[CUMULUS_3410VSI] = 1000
        scannerTypeToHDLTimeout[CUMULUS_3510HSI] = 30000
        // Cirrus Family
        scannerTypeToHDLTimeout[CIRRUS_3450VSI] = 30000
        scannerTypeToHDLTimeout[NIMBUS_3550HSI] = 30000
        // Botero
        scannerTypeToHDLTimeout[BOTERO_1500i] = 30000
        //Fresco
        scannerTypeToHDLTimeout[FRESCO_9600i] = 200 * 1000
        scannerTypeToHDLTimeout[FRESCO_9900i] = 200 * 1000
        // Curie
        scannerTypeToHDLTimeout[CURIE_900i] = 60000
    }

    // timeout in milliseconds
    var scannerTypeToHDLFinalLineTimeout: HashMap<Byte, Int> = HashMap()

    init {
        scannerTypeToHDLFinalLineTimeout[MOSAIC_9800i] = 60000
        scannerTypeToHDLFinalLineTimeout[MOSAIC_LITE_9800i] = 60000
        scannerTypeToHDLFinalLineTimeout[MOSAIC_9800i_CD] = 60000
        // Tessera Family
        scannerTypeToHDLFinalLineTimeout[TESSERA_9300i] = 2 * 60000
        scannerTypeToHDLFinalLineTimeout[TESSERA_9400i] = 2 * 60000
        scannerTypeToHDLFinalLineTimeout[TESSERA_9400i_CD] = 2 * 60000
        // Cumulus Family
        scannerTypeToHDLFinalLineTimeout[CUMULUS_3410VSI] = 60000
        scannerTypeToHDLFinalLineTimeout[CUMULUS_3510HSI] = 60000
        // Cirrus Family
        scannerTypeToHDLFinalLineTimeout[CIRRUS_3450VSI] = 30000
        scannerTypeToHDLFinalLineTimeout[NIMBUS_3550HSI] = 30000
        // Botero
        scannerTypeToHDLFinalLineTimeout[BOTERO_1500i] = 60000
        //Fresco
        scannerTypeToHDLFinalLineTimeout[FRESCO_9600i] = 7 * 60000
        scannerTypeToHDLFinalLineTimeout[FRESCO_9900i] = 7 * 60000
        // Apollo
        scannerTypeToHDLFinalLineTimeout[APOLLO_9550i] = 2 * 60000
        scannerTypeToHDLFinalLineTimeout[APOLLO_9550iB] = 2 * 60000
        // Curie
        scannerTypeToHDLFinalLineTimeout[CURIE_900i] = 2 * 60000
    }

    var canHaveScale: Array<Byte> = arrayOf(
        HUYGENS_8300_SCALE,
        HUYGENS_8400_SCALE,
        RIGGS_8500XT_SM_SCALE,
        TESSERA_9300i,
        TESSERA_9400i,
        TESSERA_9400i_CD,
        MOSAIC_9800i,
        MOSAIC_LITE_9800i,
        MOSAIC_9800i_CD,
        FRESCO_9600i,
        FRESCO_9900i,
        APOLLO_9550i,
        APOLLO_9550iB,
    )

    // FRS scanners that use SWU file to update
    var swuUpdate: Array<Byte> = arrayOf(
        FRESCO_9600i,
        FRESCO_9900i,
        CURIE_900i,
        APOLLO_9550i,
        APOLLO_9550iB
    )

    val READ_CURRENT_INTERFACE: ByteArray = SmartUtil.hexStringToByteArray("00110001")
    val READ_VERSION: ByteArray = byteArrayOf(0x01, 0x1b)
    val READ_CURRENT_CONFIGURATION: ByteArray = byteArrayOf(0x01, 0x46.toByte())
    val READ_DEFAULT_CONFIGURATION: ByteArray = byteArrayOf(0x00, 0x47.toByte())
    val CA_LABEL_EDIT_SCRIPT = byteArrayOf(0x7F, 0xF8.toByte())
    val RESTORE_CONFIGURATION = SmartUtil.hexStringToByteArray("00107FFB0047")
    val READ_ULE: ByteArray = SmartUtil.hexStringToByteArray("00117FF8")
    val RESET_SCANNER = SmartUtil.hexStringToByteArray("001A")
    val RECLAIM_INTERNAL_DRIVE = SmartUtil.hexStringToByteArray("150100")
    val WRITE_SINGLE_RECORD = SmartUtil.hexStringToByteArray("060000") // line-by-line
    val WRITE_RECORD_BUFFERED = SmartUtil.hexStringToByteArray("060001") // bulk transfer
    val NEXT_LINE = SmartUtil.hexStringToByteArray("0D0A")
    val SUBMIT_TRANSFER_UPDATER = SmartUtil.hexStringToByteArray("060002")
    val SOFTWARE_UPDATE_START = SmartUtil.hexStringToByteArray("061000")
    val SOFTWARE_UPDATE_SEND_DATA = SmartUtil.hexStringToByteArray("061001")
    val SOFTWARE_UPDATE_STATUS = SmartUtil.hexStringToByteArray("061002")

    val SEALED_TAGS: Set<String> = setOf(
        "0416","068F","0407","068E","040A","041B","0481","0409","0406","049F","000C"
    )

}
package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model

import android.content.Context
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FileUtils
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil
import java.io.File
import java.io.IOException

class HexPage(
    var startAddress: String,
    private val dataPaths: MutableList<String>,
    private val context: Context
) : Cloneable {

    var data: File? = null
    private var pktSize: Int = 2048
    private var pktMinSize: Int = 256
    var numBlock: Int = 0
    var countBlock: Int = 0
    var currentIndex: Int = 0
    private val hb = HexBlock()

    init {
        try {
            data = FileUtils.tmpFile(context,"temp.txt")
            data?.absolutePath?.let { dataPaths.add(it) }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }

    public override fun clone(): Any {
        val hp = HexPage(startAddress, dataPaths, context)
        try {
            hp.data = FileUtils.tmpFile(context, "temp.txt")
            dataPaths.add(hp.data!!.absolutePath)
            data?.let { FileUtils.readFully(it) }
                ?.let { FileUtils.appendStringToFile(hp.data!!, it) }
            if (System.getProperty("os.name") == "Linux") {
                Thread.sleep(100)
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
        hp.pktSize = pktSize
        hp.pktMinSize = pktMinSize
        hp.numBlock = numBlock
        hp.countBlock = countBlock
        hp.currentIndex = currentIndex
        return hp
    }

    fun addData(newData: StringBuffer) {
        try {
            FileUtils.appendStringToFile(data!!, formatData(newData))
            if (System.getProperty("os.name") == "Linux") {
                Thread.sleep(100)
            }
        } catch (ex: InterruptedException) {
            ex.printStackTrace()
        }
    }

    fun getStringData(): String? {
        return try {
            data?.let { FileUtils.readFully(it) }
        } catch (ex: IOException) {
            ex.printStackTrace()
            null
        }
    }

    fun setData(newData: String) {
        try {
            FileUtils.writeEntireFile(data!!, newData)
        } catch (ex: IOException) {
            ex.printStackTrace()
        }
    }

    fun setDataFile(dataFile: File) {
        data = dataFile
    }

    private fun formatData(sb: StringBuffer): String {
        return try {
            sb.toString().replace("\n", "\r\n")
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    fun getNextHexBlock(data: String): HexBlock {
        var numCharToGet = 2 * pktSize
        var addChar = 0

        if (currentIndex + numCharToGet > data.length) {
            val numBlockChar = 2 * pktMinSize
            numCharToGet = data.length - currentIndex
            hb.last = true
            addChar = numBlockChar - numCharToGet % numBlockChar
        } else {
            hb.last = currentIndex + numCharToGet == data.length
        }

        val temp = data.substring(currentIndex, currentIndex + numCharToGet)
        hb.data = StringBuffer(temp)

        if (addChar > 0) {
            hb.data!!.append("F".repeat(addChar))
        }

        hb.address = SmartUtil.bigEndian(SmartUtil.addHex(startAddress, (currentIndex / 2).toLong()))
        hb.numBlock = ++countBlock
        currentIndex += numCharToGet
        return hb
    }

    fun compareTo(other: HexPage): Int {
        return this.startAddress.compareTo(other.startAddress)
    }

    fun getSize(): Int {
        val start = startAddress.toInt(16)
        val endAddr = SmartUtil.addHex(startAddress, data?.length()?.div(2) ?: 0)
        val end = endAddr.toInt(16)
        return end - start
    }

    /*override fun toString(): String {
        return buildString {
            append("\n----HexPage ----\n")
            append("startAddress: 0x$startAddress")
            append(" endAddress: 0x${getEndAddress()}")
            append(" size: 0x${Integer.toHexString((data?.length()?.div(2) ?: 0).toInt())}")
            //append("\ndata: ${StringUtils.abbreviate(data.toString(), 13)}")
            append("\nnumBlockTx: $numBlock\n")
        }
    }*/

    fun getEndAddress(): String {
        return SmartUtil.addHex(startAddress, data?.length()?.div(2) ?: 0)
    }

    fun checkMaxSize(maxAddress: Int) {
        val endAddr = SmartUtil.getHexInt(getEndAddress())
        val excess = endAddr - maxAddress
        if (excess > 0) {
            val newLength = (data?.length() ?: 0) - excess * 2
            if ((data?.length() ?: 0) > newLength) {
                setLengthData(newLength)
            }
        }
    }

    fun checkStartAddress(startAddressReq: String) {
        val req = SmartUtil.getHexInt(startAddressReq)
        val current = SmartUtil.getHexInt(startAddress)
        if (req > current) {
            val removeSize = (req - current) * 2
            val newData = getStringData()?.substring(removeSize)
            newData?.let {
                setData(it)
                startAddress = startAddressReq
            }
        }
    }

    fun setLengthData(newLength: Long) {
        val initString = StringBuffer(getStringData())
        initString.setLength(newLength.toInt())
        setData(initString.toString())
    }

    fun calcNumBlock(pktSize: Int, pktMinSize: Int) {
        this.pktSize = pktSize
        this.pktMinSize = pktMinSize
        this.numBlock = _calcNumBlock(pktSize)
    }

    private fun _calcNumBlock(maxLength: Int): Int {
        val numCharToGet = 2 * maxLength
        val dl = data?.length()?.toLong() ?: 0
        val numB = (dl / numCharToGet).toInt()
        return if (dl % numCharToGet > 0) numB + 1 else numB
    }

    fun getPackageSize(): Int = pktSize

    fun resetHexBlock() {
        countBlock = 0
        currentIndex = 0
    }
}

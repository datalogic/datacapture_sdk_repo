package com.datalogic.quickpairingapp.utils

import android.content.Context
import android.content.SharedPreferences
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.BluetoothConstants
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.BluetoothConstants.Companion.EMPTY_LONG
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.BluetoothConstants.Companion.EMPTY_STRING


class SharedPreferenceUtil {
    companion object {
        private const val prefName = "quickPairingPrefKeys"
        private var sharedPreferences: SharedPreferences? = null
        private var editor: SharedPreferences.Editor? = null
        private const val keySelectedHostType = "KEY_SELECTED_HOST_TYPE"
        private const val keyIsPermissionDialogDisplayed = "KEY_IS_PERMISSION_DIALOG_DISPLAYED"
        private const val keySelectedBTProfile = "KEY_SELECTED_BT_PROFILE"
        private const val keyCurrentAccessToken = "KEY_CURRENT_ACCESS_TOKEN"
        private const val keyAccessTokenGenerateTime = "KEY_ACCESS_TOKEN_GENERATE_TIME"
        private const val keyDynamicStringForPairing = "KEY_DYNAMIC_STR_FOR_PAIRING"
        private const val keyIntentActionName="KEY_INTENT_ACTION_NAME"
        private const val keyIntentHostName = "KEY_INTENT_HOST_NAME"

        fun initSharedPreference(context: Context) {
            sharedPreferences = context.getSharedPreferences(prefName, Context.MODE_PRIVATE)
            editor = sharedPreferences?.edit()
        }

        fun saveBTProfile(profile: String) {
            editor?.let {
                editor?.putString(keySelectedBTProfile, profile)
                editor?.apply()
            }
        }

        fun getBTProfile(): String? {
            sharedPreferences?.let {
                return sharedPreferences?.getString(
                    keySelectedBTProfile, BluetoothConstants.HID_BT_PROFILE
                )
            }
            return BluetoothConstants.HID_BT_PROFILE
        }

        fun saveHostType(type: String) {
            editor?.let {
                editor?.putString(keySelectedHostType, type)
                editor?.apply()
            }
        }

        fun getHostType(): String? {
            sharedPreferences?.let {
                return sharedPreferences?.getString(
                    keySelectedHostType, BluetoothConstants.UNCONFIGURED_HOST_TYPE
                )
            }
            return BluetoothConstants.UNCONFIGURED_HOST_TYPE
        }

        fun isPermissionDialogDisplay(): Boolean? {
            sharedPreferences?.let {
                return sharedPreferences?.getBoolean(keyIsPermissionDialogDisplayed, false)
            }
            return false
        }


        fun saveIsPermissionDialogDisplayed(value: Boolean) {
            editor?.let {
                editor?.putBoolean(keyIsPermissionDialogDisplayed, value)
                editor?.apply()
            }
        }

        fun saveCurrentAccessToken(value: String) {
            if (value.isNotEmpty()) {
                editor?.let {
                    editor?.putString(keyCurrentAccessToken, value)
                    editor?.apply()
                }
            }
        }

        fun getCurrentAccessToken(): String {
            sharedPreferences?.let {
                val extra = sharedPreferences?.getString(
                    keyCurrentAccessToken,
                    EMPTY_STRING
                )
                if (extra != null) {
                    if (extra.isNotEmpty()) {
                        return extra
                    }
                }
            }
            return EMPTY_STRING
        }

        fun saveAccessTokenGenerateTime(accessTokenGenerateTime: Long) {
            editor?.let {
                editor?.putLong(keyAccessTokenGenerateTime, accessTokenGenerateTime)
                editor?.apply()
            }
        }

        fun getAccessTokenGenerateTime(): Long? {
            sharedPreferences?.let {
                return sharedPreferences?.getLong(
                    keyAccessTokenGenerateTime, EMPTY_LONG
                )
            }
            return EMPTY_LONG
        }


        fun saveDynamicPairingStr(value: String) {
            if (value.isNotEmpty()) {
                editor?.let {
                    editor?.putString(keyDynamicStringForPairing, value)
                    editor?.apply()
                }
            }
        }

        fun getDynamicPairingStr(): String {
            sharedPreferences?.let {
                val extra = sharedPreferences?.getString(
                    keyDynamicStringForPairing,
                    EMPTY_STRING
                )
                if (extra != null) {
                    if (extra.isNotEmpty()) {
                        return extra
                    }
                }
            }
            return EMPTY_STRING
        }

        fun saveIntentActionName(actionName: String) {
            editor?.let {
                editor?.putString(keyIntentActionName, actionName)
                editor?.apply()
            }
        }

        fun getIntentActionName() :String? {
            sharedPreferences?.let {
                return sharedPreferences?.getString(
                    keyIntentActionName, EMPTY_STRING
                )
            }
            return EMPTY_STRING
        }

        fun saveIntentHostname(hostName: String) {
            editor?.let {
                editor?.putString(keyIntentHostName, hostName)
                editor?.apply()
            }
        }

        fun getIntentHostName(): String? {
            sharedPreferences?.let {
                return sharedPreferences?.getString(
                    keyIntentHostName, EMPTY_STRING
                )
            }
            return EMPTY_STRING
        }
    }
}
package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model

import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.addHex


class HexBlock {
    var address: String? = null
    var data: StringBuffer? = null
    var numBlock: Int = 0
    var last: Boolean = false

    override fun toString(): String {
        var t = "HexBlok- "
        t += "\t numBlock: $numBlock"
        t += ",\t length: " + data!!.length / 2
        t += ",address: $address"
        t += ",endAdddress: " + addHex(address!!, (data!!.length / 2).toLong())
        t += ",\t data: "
        val b = data.toString().toByteArray()
        var i = 0
        while (i < data!!.length && i < 128) {
            t += data!!.substring(i, i + 2)
            t += " "
            i += 2
        }
        t += ",\t last: $last"
        return t
    }
}
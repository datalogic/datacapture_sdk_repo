import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSDevice
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants.IMAGE_FORMAT
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants.ENABLE_SCANNING
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants.IMAGE_CAPTURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants.SENSOR_ID
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants.IMAGE_ILLUMINATION


class ImageCaptureFRS(val pid: String) {

    private val frsDevice: FRSDevice = FRSDevice()

    fun imageCaptureAuto(serviceSerial: ServiceSerial): ByteArray {
        // Step 1: Send enable scanning command
        val enableCommand: ByteArray = frsDevice.createFullFRSCommand(ENABLE_SCANNING)
        val res = serviceSerial.sendReceive(enableCommand,5000,1000)
        val cmd = IMAGE_CAPTURE + formatMsg()
        val imageCommand = frsDevice.createFullFRSCommand(cmd)

        val dataReceive = serviceSerial.sendReceive(imageCommand, 40000, 1000)

        return frsDevice.extractMagellanResponseData(dataReceive)
    }

    private fun formatMsg(): ByteArray {
        val msg: String = if (pid == "16384") {
            "01" + "01"
        } else {
            SENSOR_ID + IMAGE_FORMAT + IMAGE_ILLUMINATION
        }
        return msg.chunked(2).map {
            it.toInt(16).toByte()
        }.toByteArray()
    }

}
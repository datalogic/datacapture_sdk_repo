package com.datalogic.aladdin.aladdinusbscannersdk.utils.constants

class BluetoothConstants {
    companion object {
        const val HID_BT_PROFILE = "HID"
        const val SPP_BT_PROFILE = "SPP"
        const val CONFIGURED_HOST_TYPE = "Configured"
        const val UNCONFIGURED_HOST_TYPE = "Unconfigured"
        const val CONNECTED = 1
        const val DISCONNECTED = 3
        const val ACTION_CONNECTION_STATE_CHANGED = "action_connection_state_changed"
        const val EXTRA_CONNECTION_STATE = "extra_connection_state"
        const val VERSION_CONSTANT = "V "
        const val LOCATION_SERVICE_DISABLE_ERROR_MSG = "Location Services disabled (code 4)"
        const val LOCATION_PERMISSION_DISABLE_ERROR_MSG = "Location Permission missing (code 3)"
        const val DYNAMIC_PAIRING_CONSTANT = "Y"
        const val EMPTY_STRING = ""
        const val EMPTY_LONG = 0L
        const val DELAY_3000: Long = 3000
        const val SECOND_30: Long = 30 * 1000
        const val SECOND_60: Long = 60 * 1000
        const val DATALOGIC_MAC_PREFIX = "00:07:BE"
    }
}
package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model

import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil

data class HexRecord(
    var count: Int = 0,
    var countS: String = "",
    var address: String = "",
    var type: String = "",
    var data: String = "",
    var chk: String = ""
) : Comparable<HexRecord> {
    private val TAG = this.javaClass.simpleName

    fun getEndAddress(): String {
        return if (isDataRecord()) {
            SmartUtil.addHex(address, count.toLong())
        } else {
            "-"
        }
    }

    fun addSegmentAddress(segAddress: String) {
        val addressInt = address.toInt(16)
        val addressSegInt = segAddress.toInt(16)
        val newAddress = addressInt + addressSegInt
        address = newAddress.toString(16).uppercase().padStart(8, '0')
    }

    fun addExtAddress(extAddress: String) {
        val eAddr = extAddress.takeLast(4)
        val addr = address.takeLast(4)
        address = eAddr + addr
    }

    fun isDataRecord(): Boolean {
        return type == "00"
    }

    override fun toString(): String {
        return buildString {
            append("HexRecord-")
            append("\tlen: $count")
            append("\tlenS: $countS")
            append(",\t address: $address")
            append(",\t Endaddress: ${getEndAddress()}")
            append(",\t type: $type")
            append(",\t data: $data")
            append(",\t chk: $chk")
        }
    }

    override fun compareTo(other: HexRecord): Int {
        return this.address.compareTo(other.address)
    }
}

package com.datalogic.aladdin.aladdinusbscannersdk.utils.bluetoothutils

import android.bluetooth.BluetoothSocket
import android.content.Context
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.FAILURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.SUCCESS
import java.io.ByteArrayOutputStream
import java.io.IOException


class SerialSocket(
    val context: Context,
    val socket: BluetoothSocket
) {
    private var tag = SerialSocket::class.java.simpleName
    var connected = false
    private val commandResponseLock = Object()
    var buffer: ByteArray = byteArrayOf()

    @Throws(IOException::class)
    fun write(data: ByteArray) {
        if (!connected) throw IOException("not connected")

        Log.d(tag, "[SerialSocket::write] device connected -> socket.outputStream?.write(data)")
        socket.outputStream?.write(data)
    }
    fun receiveWithTimeout(startTimeout: Long, endTimeout: Long, isCheckResponse: Boolean = false): ByteArray? {
        synchronized(commandResponseLock) {
            val input = socket.inputStream ?: return null
            val buffer = ByteArrayOutputStream()
            var lastTime = System.currentTimeMillis()
            var timeout = startTimeout
            val temp = ByteArray(1024)
            while (System.currentTimeMillis() - lastTime < timeout) {
                val available = input.available()
                if (available > 0) {
                    val readSize = input.read(temp, 0, minOf(temp.size, available))
                    if (readSize > 0) {
                        buffer.write(temp, 0, readSize)
                        lastTime = System.currentTimeMillis()
                        timeout = endTimeout
                        val data = buffer.toByteArray()
                        if (isCheckResponse && (data[0] == 0x06.toByte() || data.toString(Charsets.UTF_8).startsWith("$>")))
                            return data
                    }
                } else {
                    Thread.sleep(10)
                }
            }
            return if (buffer.size() > 0) buffer.toByteArray() else null
        }
    }

    fun clearInputBuffer(socket: BluetoothSocket?) {
        if (socket == null) return

        val inputStream = socket.inputStream ?: return
        Log.d(tag, "[clearInputBuffer] socket is not null")

        try {
            val tempBuffer = ByteArray(256)
            while (inputStream.available() > 0) {
                val bytesRead = inputStream.read(tempBuffer)
                if (bytesRead <= 0) break
            }
            Log.d(tag, "[clearInputBuffer] buffer cleared")
        } catch (e: Exception) {
            Log.w(tag, "[clearInputBuffer] Error clearing input buffer", e)
        }
    }

    fun sendReceive(command: ByteArray, startTimeout: Long, endTimeout: Long, isCheckResponse: Boolean = false): ByteArray? {
        synchronized(commandResponseLock) {
            var response: ByteArray? = null
            try {
                // Clear any pending data in the input buffer
                Log.d(tag, "[sendReceive] clearInputBuffer")
                clearInputBuffer(socket)
                // Send the command
                try {
                    write(command)
                } catch (e: Exception) {
                    Log.e(tag, "[sendReceive] Failed to write command: $e")
                    return null
                }
                // Read the response with timeout
                response = receiveWithTimeout(startTimeout, endTimeout, isCheckResponse)
            } catch (e: Exception) {
                Log.e(tag, "[sendReceive] Error during command execution", e)
            }

            return response
        }
    }

    /**
     * More aggressive USB connection reset for persistent write errors
     */
    fun send(data: ByteArray): Int {
        synchronized(commandResponseLock) {
            return try {
                write(data)
                SUCCESS
            } catch (e: Exception) {
                Log.e(tag, "[send] Send command error: ", e)
                FAILURE
            }
        }
    }
}

package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class HostType {
    Configured,
    Unconfigured
}
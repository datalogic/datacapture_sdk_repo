package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model

import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil

class FirmwarePage {
    var offset: String = ""
    var size: String = ""
    var sapNumber: String = ""
    var id: String = ""
    var pid: String = ""
    var developerOnly: String = ""
    var labelBlock: String = ""
    var blockVersion101: String = ""
    var blockVersion12: String = ""
    var index: Int = 0
    var checkPID: Boolean = false
    var isSelected: Boolean = false
    var toBeUpgraded: Boolean = true
    var processed: Boolean = false
    var discardReason: String = ""
    var hexPages: MutableList<HexPage> = mutableListOf()

    fun getMaxAddress(): Int {
        return SmartUtil.getHexInt(offset) + SmartUtil.getHexInt(size)
    }

    fun addHPage(hPage: HexPage) {
        hexPages.add(hPage)
    }

    fun getHPages(): List<HexPage> {
        return hexPages
    }

    override fun toString(): String {
        val sb = StringBuilder()
        sb.append("block ")
        sb.append("start: ").append(offset).append(" ")
        sb.append("size: ").append(size).append("\n")
        for (elem in hexPages) {
            sb.append(elem).append("\n")
        }
        return sb.toString()
    }
}

package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class BluetoothPairingStatus {
    Successful,
    Unsuccessful,
    Timeout
}
package com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners

import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DeviceStatus

interface StatusListener {

    /**
     * Function called when a device Status Change.
     */
    fun onStatus(productId:String, status: DeviceStatus, deviceName: String)


    fun onError(errorStatus : Int)
}
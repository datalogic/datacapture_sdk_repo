package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS

enum class CopyToLevel(val text: String) {
    COPY_TO_USER("Copy to user"),
    COPY_TO_FACTORY("Copy to factory"),
    COPY_TO_USER_AND_FACTORY("Copy to user and factory");

    override fun toString(): String = text
}

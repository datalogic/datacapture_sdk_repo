package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils

class IFType {
    var iF_Type: String = ""
    var iF_Value: String = ""
    var iF_Class: String = ""

     companion object {
         private val ifTypes = arrayOf(
             "IBM-P17", "4", "IBM",
         "IBM-P5B", "8", "IBM",
         "IBM-P9B", "23", "IBM",
         "USB-OEM", "45", "IBM",
         "KBD-AT", "29", "Keyboard",
         "KBD-AT-ALT", "26", "Keyboard",
         "KBD-AT-ALT-NK", "10", "Keyboard",
         "KBD-AT-NK", "11", "Keyboard",
         "KBD-DIG-VT", "1B", "Keyboard",
         "KBD-IBM-3153", "14", "Keyboard",
         "KBD-IBM-M", "15", "Keyboard",
         "KBD-IBM-MB", "16", "Keyboard",
         "ETH-STD-TEMP", "19", "Ethernet",
         "KBD-WYSE-ASCII", "18", "Keyboard",
         "KBD-WYSE-PC", "17", "Keyboard",
         "KBD-WYSE-VT220", "1A", "Keyboard",
         "KBD-XT", "28", "Keyboard",
         "USB-KBD", "35", "Keyboard",
         "USB-KBD-ALT", "2B", "Keyboard",
         "USB-KBD-APPLE", "2C", "Keyboard",
         "NULL", "46", "Null",
         "RS232-STD", "5", "RS232-STD",
         "USB-COM-STD", "47", "RS232-STD",
         "RS232-WN", "12", "RS232-WN",
         "RS232-OPOS", "13", "RS232-OPOS",
         "USB-POS", "44", "USB-HID-POS",
         "WAND", "24", "Wand",
         "ETH-STD", "48", "Ethernet",
         "USB-COMPOSITE", "4D", "USB-COMPOSITE",
         "USB-TEC", "41", "USB-TEC",
         "USB-COM-MGL", "40", "USB-COM-MGL",
         "RS232-AUX", "43", "RS232-AUX",
         "WIFI-STD", "4E", "WIFI-STD"
         )

         val ifTypeMap: MutableMap<String, IFType> = mutableMapOf()

         init {
             for (i in ifTypes.indices step 3) {
                 val ifType = IFType().apply {
                 iF_Type = ifTypes[i]
                 iF_Value = ifTypes[i + 1].padStart(2, '0')
                 iF_Class = ifTypes[i + 2]
                 }
                 ifTypeMap[ifType.iF_Value] = ifType
                 }
             }
         }
}

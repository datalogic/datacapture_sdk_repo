package com.datalogic.aladdin.aladdinusbscannersdk.model

import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.BluetoothPairingStatus

data class BluetoothPairingData(
    val deviceName: String,
    val pairingStatus: BluetoothPairingStatus,
    val message: String
)

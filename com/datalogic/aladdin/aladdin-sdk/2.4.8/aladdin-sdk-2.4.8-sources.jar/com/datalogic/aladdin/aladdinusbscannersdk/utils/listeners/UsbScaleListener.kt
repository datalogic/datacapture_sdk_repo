package com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners

import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData

interface UsbScaleListener {
    fun onScale(scaleData: ScaleData)
}
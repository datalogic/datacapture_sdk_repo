package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils;

public class HHSDevice {
    public static final String ENTER_CONFIG_MODE = "$S\r";
    public static final String EXIT_CONFIG_MODE = "$s\r";
    public static final String DEVICE_NAME_AND_SW_RELEASE = "$!\r";
}

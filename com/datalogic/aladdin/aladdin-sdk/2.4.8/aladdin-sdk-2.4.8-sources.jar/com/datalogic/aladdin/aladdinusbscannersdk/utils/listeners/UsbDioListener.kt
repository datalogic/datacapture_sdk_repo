package com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners

/**
 * Interface of the lister for device DIO Commands get failed.
 */
interface UsbDioListener {
    /**
     * Function called when a DIO Commands get failed.
     */
    fun fireDioErrorEvent(errorCode: Int, message: String)

}
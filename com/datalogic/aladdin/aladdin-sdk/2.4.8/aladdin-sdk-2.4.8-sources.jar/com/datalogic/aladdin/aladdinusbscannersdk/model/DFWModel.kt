package com.datalogic.aladdin.aladdinusbscannersdk.model

data class FirmwareDescriptor(
    val project: String,
    val platform: Platform,
    val product: ProductDFW,
    val blocks: List<Block>,
    val hex: HexData?
)

data class Platform(
    val protocol: String,
    val type: String,
    val fmwrInitTimeout: Int,
    val signature: Boolean,
    val name: String
)

data class ProductDFW(
    val ecLevel: String,
    val pidNumber: String,
    val isRadioDevice: Boolean,
    val validPidSet: List<String>,
    val name: String
)

data class Block(
    val offset: String,
    val size: String,
    val label: String,
    val id: String,
    val version: String,
    val pid: String,
    val developerOnly: Boolean,
    val type: String
)

data class HexData(
    val pidSet: String,
    val idSet: String,
    val label: String,
    val data: String
)
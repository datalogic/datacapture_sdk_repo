package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils

import android.content.Context
import android.os.Environment
import com.datalogic.aladdin.aladdinusbscannersdk.model.Data
import com.datalogic.aladdin.aladdinusbscannersdk.model.HealthItem
import com.datalogic.aladdin.aladdinusbscannersdk.model.InformationItem
import com.datalogic.aladdin.aladdinusbscannersdk.model.ProductResponse
import com.datalogic.aladdin.aladdinusbscannersdk.model.StatisticsItem
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.DIO_JSON_FILE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.JSON_FILE
import com.google.gson.Gson
import java.io.File
import java.io.FileInputStream
import kotlin.text.Charsets.UTF_8


object LocalJSONParser {
    fun inputStreamToString(context:Context) : ProductResponse{
        val inputStream = context.assets.open(JSON_FILE)
        val size = inputStream.available()
        val buffer = ByteArray(size)
        inputStream.read(buffer)
        inputStream.close()
        val json = String(buffer, charset = UTF_8)
        // Parse the JSON data
        val gson = Gson()
        return gson.fromJson(json, ProductResponse::class.java)
    }

    fun dioString(context:Context) : Data{
        val inputStream = context.assets.open(DIO_JSON_FILE)
        val size = inputStream.available()
        val buffer = ByteArray(size)
        inputStream.read(buffer)
        inputStream.close()
        val json = String(buffer, charset = UTF_8)
        // Parse the JSON data
        val gson = Gson()
        return gson.fromJson(json, Data::class.java)
    }

    fun findKeyInHealthList(data: List<HealthItem>, searchKey: String): String? {
        for (item in data) {
            if (item.key == searchKey) {
                return item.name
            }
        }
        return null
    }

    fun findKeyInStatisticsList(data: List<StatisticsItem>, searchKey: String): String? {
        for (item in data) {
            if (item.key == searchKey) {
                return item.name
            }
        }
        return null
    }

    fun findKeyInInformationList(data: List<InformationItem>, searchKey: String): String? {
        for (item in data) {
            if (item.key == searchKey) {
                return item.name
            }
        }
        return null
    }

    fun inputStreamFromDownloads(): ProductResponse? {
        val file = findJsonFile() ?: return null
        return try {
            val inputStream = FileInputStream(file)
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            val json = String(buffer, charset = UTF_8)
            val gson = Gson()
            gson.fromJson(json, ProductResponse::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun findJsonFile(): File? {
        val publicDownloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val publicFile = File(publicDownloadsDir, JSON_FILE)
        if (publicFile.exists()) return publicFile
        return null
    }

}

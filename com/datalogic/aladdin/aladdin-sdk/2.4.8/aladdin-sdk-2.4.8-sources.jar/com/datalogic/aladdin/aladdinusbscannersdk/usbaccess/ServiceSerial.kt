package com.datalogic.aladdin.aladdinusbscannersdk.usbaccess

import android.content.ContentValues
import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.model.DatalogicDeviceManager
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.CAN_NOT_FIND_COM_PORT
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.FAILURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.SUCCESS
import com.hoho.android.usbserial.driver.UsbSerialPort
import java.io.ByteArrayOutputStream
import java.io.IOException

class ServiceSerial() {
    private var TAG: String = ServiceSerial::class.java.simpleName
    private val MAX_CONNECTION_RETRIES = 5
    private val CONNECTION_RETRY_DELAY = 500L
    private val device_response_try_number = 3000
    private val device_response_try_timeout = 5L
    private val usbDriver = UsbDriver()
    private val commandResponseLock = Object()

    // Increased buffer size for better performance during firmware updates
    //private val BUFFER_SIZE = 4048 // Increased from default maxPacketSize (typically 64-512 bytes)

    var usbServiceSerialPort: UsbSerialPort? = null // Should move to connection
    var usbHostSerialPort: UsbSerialPort? = null // Should move to connection
    var usbDeviceServiceConnection: UsbDeviceConnection? = null // Should move to connection
    var usbDeviceHostConnection: UsbDeviceConnection? = null

    fun open(
        usbManager: UsbManager,
        productIdString: String,
        vendorIdString: String,
        context: Context
    ): Boolean {
        // If already open through this instance, return true
        if (isOpen()) {
            return true
        }

        // Create a new connection using existing logic
        if (createNewConnection(usbManager, productIdString, vendorIdString, context)) {
            return true
        }

        return false
    }

    // Create a new connection (existing logic extracted to a method)
    private fun createNewConnection(
        usbManager: UsbManager,
        productIdString: String,
        vendorIdString: String,
        context: Context
    ): Boolean {
        val driver = usbDriver.findDriver(productIdString, vendorIdString, usbManager, context)

        if (driver == null) {
            DatalogicDeviceManager.onStatusListener?.onError(CAN_NOT_FIND_COM_PORT)
            return false
        }

        // Connection retry logic from the existing open method
        var connectionAttempts = 0
        var connected = false

        while (!connected && connectionAttempts < MAX_CONNECTION_RETRIES) {
            connectionAttempts++
            Log.d(TAG, "Connection attempt $connectionAttempts of $MAX_CONNECTION_RETRIES")

            try {
                usbDeviceServiceConnection = usbManager.openDevice(driver.device)
                usbDeviceHostConnection = usbManager.openDevice(driver.device)
                if (usbDeviceServiceConnection == null || usbDeviceHostConnection == null) {
                    Log.e(TAG, "Failed to open USB connection, retrying...")
                    Thread.sleep(CONNECTION_RETRY_DELAY + (device_response_try_timeout * device_response_try_number / 100))
                    continue
                }


                if (driver.ports.size < 2) {
                    usbServiceSerialPort = driver.ports[0]
                    usbHostSerialPort = null
                } else {
                    usbServiceSerialPort = driver.ports[0]
                    usbHostSerialPort = driver.ports[1]
                }

                if (usbServiceSerialPort != null) {
                    try {
                        usbServiceSerialPort?.open(usbDeviceServiceConnection)
                        usbServiceSerialPort?.rts = true
                        usbServiceSerialPort?.dtr = true
                        usbServiceSerialPort?.setParameters(
                            115200,
                            UsbSerialPort.DATABITS_8,
                            UsbSerialPort.STOPBITS_1,
                            UsbSerialPort.PARITY_NONE
                        )
                        connected = true
                        Log.d(TAG, "Successfully connected to device on attempt $connectionAttempts")

                    } catch (e: Exception) {
                        Log.e(TAG, "Error opening port on attempt $connectionAttempts: ${e.message}")
                        try {
                            usbServiceSerialPort?.close()
                        } catch (closeEx: Exception) {
                            // Ignore close exceptions
                        }
                        Thread.sleep(CONNECTION_RETRY_DELAY + (device_response_try_timeout * 50))
                    }
                } else {
                    Log.e(TAG, "Failed to get COM port, retrying...")
                    usbDeviceServiceConnection?.close()
                    usbDeviceServiceConnection = null
                    Thread.sleep(CONNECTION_RETRY_DELAY + (device_response_try_timeout * device_response_try_number / 100))
                    continue
                }

                //Try to configure HOST COM PORT
                if (usbHostSerialPort != null) {
                    try {
                        usbHostSerialPort?.open(usbDeviceHostConnection)
                        usbHostSerialPort?.rts = true
                        usbHostSerialPort?.dtr = true
                        usbHostSerialPort?.setParameters(
                            115200,
                            UsbSerialPort.DATABITS_8,
                            UsbSerialPort.STOPBITS_1,
                            UsbSerialPort.PARITY_NONE
                        )
                        connected = true
                        Log.d(TAG, "Successfully connected to device on attempt $connectionAttempts")

                    } catch (e: Exception) {
                        Log.e(TAG, "Error opening port on attempt $connectionAttempts: ${e.message}")
                        try {
                            usbHostSerialPort?.close()
                        } catch (closeEx: Exception) {
                            // Ignore close exceptions
                        }
                        Thread.sleep(CONNECTION_RETRY_DELAY + (device_response_try_timeout * 50))
                    }
                }

                if (connected) {
                    return true
                }
            } catch (e: Exception) {
                Log.e(TAG, "Connection exception on attempt $connectionAttempts: ${e.message}")
                Thread.sleep(CONNECTION_RETRY_DELAY + (device_response_try_timeout * 100))
            }
        }

        Log.e(TAG, "Failed to connect after $MAX_CONNECTION_RETRIES attempts")
        DatalogicDeviceManager.onStatusListener?.onError(CAN_NOT_FIND_COM_PORT)
        return false
    }

    fun close(device: UsbDevice) {
        // Synchronize with the same lock used for sending commands
        synchronized(commandResponseLock) {
            try {
                // Close the serial port with proper error handling
                try {
                    if (usbServiceSerialPort != null && usbServiceSerialPort!!.isOpen) {
                        usbServiceSerialPort?.close()
                    }
                    usbServiceSerialPort = null
                    if (usbHostSerialPort != null && usbHostSerialPort!!.isOpen) {
                        usbHostSerialPort?.close()
                    }
                    usbHostSerialPort = null
                } catch (e: IOException) {
                    Log.e(TAG, "Error closing port.", e)
                }

                // Close the USB connection with proper error handling
                try {
                    if (usbDeviceServiceConnection != null) {
                        usbDeviceServiceConnection?.close()
                    }
                    usbDeviceServiceConnection = null
                    if (usbDeviceHostConnection != null) {
                        usbDeviceHostConnection?.close()
                    }
                    usbDeviceHostConnection = null
                } catch (e: Exception) {
                    Log.e(TAG, "Error closing USB connection.", e)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error during connection close", e)
            }
        }
    }

    fun isOpen(): Boolean {
        return usbServiceSerialPort != null
    }

    fun sendReceive(
        command: ByteArray,
        startTimeout: Long,
        endTimeout: Long,
        isCheckResponse: Boolean = false
    ): ByteArray? {
        // Synchronize on the lock object to prevent concurrent command execution
        synchronized(commandResponseLock) {
            if (usbServiceSerialPort == null) {
                return null
            }

            var response: ByteArray? = null

            try {
                // Clear any pending data in the input buffer
                clearInputBuffer(usbServiceSerialPort)

                // Send the command
                val writeResult = send(command)
                if (writeResult != SUCCESS) {
                    Log.e(TAG,"Failed to write command")
                    return null
                }

                // Read the response with timeout
                response = receiveWithTimeout(startTimeout, endTimeout, isCheckResponse)

            } catch (e: Exception) {
                Log.e(TAG, "Error during command execution", e)
            }

            return response
        }
    }

    fun sendReceiveHost(
        command: ByteArray,
        startTimeout: Long,
        endTimeout: Long
    ): ByteArray? {
        if (usbHostSerialPort != null) {
            // Synchronize on the lock object to prevent concurrent command execution
            synchronized(commandResponseLock) {
                var response: ByteArray? = null

                try {
                    // Clear any pending data in the input buffer
                    clearInputBuffer(usbHostSerialPort)

                    // Send the command
                    val writeResult = sendHost(command)
                    if (writeResult != SUCCESS) {
                        Log.e(TAG, "Failed to write command")
                        return null
                    }

                    // Read the response with timeout
                    response = receiveWithTimeoutHost(startTimeout, endTimeout)
                } catch (e: Exception) {
                    Log.e(TAG, "Error during command execution", e)
                }
                return response
            }
        } else {
            return sendReceive(command, startTimeout, endTimeout)
        }
    }

    /**
     * More aggressive USB connection reset for persistent write errors
     */
    fun send(data: ByteArray): Int {
        // Synchronize on the lock object to prevent concurrent command execution
        synchronized(commandResponseLock) {
            return try {
                if (usbServiceSerialPort != null) {
                    // Increase timeout for firmware updates and large data transfers
                    val timeout = if (data.size > 1024) 1000 else 500 // 1 seconds for large data
                    usbServiceSerialPort?.write(data, timeout)
                    SUCCESS
                } else {
                    FAILURE
                }
            } catch (e: Exception) {
                Log.e(TAG, "Send command error: ", e)
                FAILURE
            }
        }
    }

    fun sendHost(data: ByteArray): Int {
        if (usbHostSerialPort != null) {
            // Synchronize on the lock object to prevent concurrent command execution
            synchronized(commandResponseLock) {
                return try {
                    usbHostSerialPort?.write(data, 500)
                    SUCCESS
                } catch (e: Exception) {
                    Log.e(TAG, "Send command error: ", e)
                    FAILURE
                }
            }
        } else {
            return send(data)
        }
    }

    /**
     * Reads a complete response from the USB device with timeout.
     *
     * @param timeout Maximum time to wait for the response in milliseconds
     * @return The response bytes or null if timeout occurred
     */
    fun receiveWithTimeout(startTimeout: Long, endTimeout: Long, isCheckResponse: Boolean = false): ByteArray? {
        // Synchronize on the lock object to prevent concurrent command execution
        synchronized(commandResponseLock) {
            if (usbServiceSerialPort == null) {
                return null
            }

            var lastTime = System.currentTimeMillis()
            val buffer = ByteArrayOutputStream()
            var timeout = startTimeout
            //var reset = true
            // Use larger buffer size for better performance during firmware updates
            //val bufferSize = BUFFER_SIZE
            val bufferSize = usbServiceSerialPort!!.readEndpoint.maxPacketSize

            // Continue reading until we have a complete message or timeout
            while (System.currentTimeMillis() - lastTime < timeout) {
                val chunk = ByteArray(bufferSize)
                val bytesRead = usbServiceSerialPort?.read(chunk, 50) ?: 0

                if (bytesRead > 0) {
                    buffer.write(chunk, 0, bytesRead)
                    lastTime = System.currentTimeMillis()
                    timeout = endTimeout
                } else {
                    //Reset RTD and DTR in case buffer is full
                    /*if(System.currentTimeMillis() - lastTime > 20000 && reset) {
                        usbServiceSerialPort!!.dtr = false
                        usbServiceSerialPort!!.rts = false

                        Thread.sleep(100)

                        usbServiceSerialPort!!.dtr = true
                        usbServiceSerialPort!!.rts = true

                        reset = false
                    }*/

                    // Short pause to avoid CPU spinning
                    try {
                        Thread.sleep(10)
                    } catch (e: InterruptedException) {
                        // Ignore interruption
                    }
                }
                if(isCheckResponse && buffer.size() > 0 &&
                    (buffer.toByteArray()[0] == 6.toByte()
                            || buffer.toString().startsWith("$>"))){
                    return buffer.toByteArray()
                }
            }
            return if (buffer.size() > 0) buffer.toByteArray() else null
        }
    }

    fun sendReceiveImage(
        command: ByteArray,
        imageSize: Int,
        startTimeout: Long,
        endTimeout: Long,
    ): ByteArray? {
        // Synchronize on the lock object to prevent concurrent command execution
        synchronized(commandResponseLock) {
            if (usbServiceSerialPort == null) {
                return null
            }
            var response: ByteArray? = null
            try {
                clearInputBuffer(usbServiceSerialPort)
                val writeResult = send(command)
                if (writeResult != SUCCESS) {
                    Log.e(TAG,"Failed to write command")
                    return null
                }
                readDataNonBlocking(imageSize, startTimeout, endTimeout)
                Log.e(TAG, "Waiting Thread readDataNonBlocking finish")
                while (!imageOk) {
                    Thread.sleep(10)
                }
                if (image.size() > 0) {
                    response = image.toByteArray()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error during command execution", e)
            }

            return response
        }
    }

    var image = ByteArrayOutputStream()
    var imageOk = false
    fun readDataNonBlocking(imageSize: Int, startTimeout: Long, endTimeout: Long) {
        imageOk = false
        image = ByteArrayOutputStream()
        Thread {
            val bufferSize = usbServiceSerialPort!!.readEndpoint.maxPacketSize
            val chunk = ByteArray(bufferSize)
            var lastTime = System.currentTimeMillis()
            var timeout = startTimeout

            Log.d(TAG, "Thread readDataNonBlocking start")
            while (System.currentTimeMillis() - lastTime < timeout) {
                val bytesRead = usbServiceSerialPort?.read(chunk, 0) ?: 0
                if (bytesRead > 0) {
                    lastTime = System.currentTimeMillis()
                    timeout = endTimeout
                    image.write(chunk, 0, bytesRead)
                }

                if (image.size() >= imageSize) {
                    break
                }
            }
            imageOk = true
            Log.d(TAG, "Thread readDataNonBlocking end")
        }.start()
    }

    fun receiveWithTimeoutHost(startTimeout: Long, endTimeout: Long): ByteArray? {
        if (usbHostSerialPort != null) {
            // Synchronize on the lock object to prevent concurrent command execution
            synchronized(commandResponseLock) {
                var lastTime = System.currentTimeMillis()
                val buffer = ByteArrayOutputStream()
                var timeout = startTimeout
                //var reset = true
                // Use larger buffer size for better performance during firmware updates
                //val bufferSize = BUFFER_SIZE
                val bufferSize = usbHostSerialPort!!.readEndpoint.maxPacketSize

                // Continue reading until we have a complete message or timeout
                while (System.currentTimeMillis() - lastTime < timeout) {
                    val chunk = ByteArray(bufferSize)
                    val bytesRead = usbHostSerialPort?.read(chunk, 50) ?: 0

                    if (bytesRead > 0) {
                        buffer.write(chunk, 0, bytesRead)
                        lastTime = System.currentTimeMillis()
                        timeout = endTimeout
                    } else {
                        //Reset RTD and DTR in case buffer is full
                        /*if(System.currentTimeMillis() - lastTime > 20000 && reset) {
                            usbServiceSerialPort!!.dtr = false
                            usbServiceSerialPort!!.rts = false

                            Thread.sleep(100)

                            usbServiceSerialPort!!.dtr = true
                            usbServiceSerialPort!!.rts = true

                            reset = false
                        }*/

                        // Short pause to avoid CPU spinning
                        try {
                            Thread.sleep(10)
                        } catch (e: InterruptedException) {
                            // Ignore interruption
                        }
                    }
                }

                return if (buffer.size() > 0) buffer.toByteArray() else null
            }
        } else {
            return receiveWithTimeout(startTimeout, endTimeout)
        }
    }

    fun getUsbSerialPort(): UsbSerialPort? {
        return usbServiceSerialPort
    }

    /**
     * Clears any pending data in the input buffer
     */
    fun clearInputBuffer(usbSerialPort: UsbSerialPort?) {
        if (usbSerialPort == null) return

        try {
            // Read with a very short timeout just to clear the buffer
            //val tempBuffer = ByteArray(BUFFER_SIZE)
            val tempBuffer = ByteArray(256)
            while (true) {
                val bytesRead = usbSerialPort.read(tempBuffer, 10) ?: 0
                if (bytesRead <= 0) break
            }
        } catch (e: Exception) {
            Log.w(ContentValues.TAG, "Error clearing input buffer", e)
        }
    }

    fun sendReceiveString(byteArray: ByteArray): String{
        sendReceive(byteArray, 3000, 200)?.let {
            return String(it, Charsets.UTF_8)
        }
        return ""
    }

}

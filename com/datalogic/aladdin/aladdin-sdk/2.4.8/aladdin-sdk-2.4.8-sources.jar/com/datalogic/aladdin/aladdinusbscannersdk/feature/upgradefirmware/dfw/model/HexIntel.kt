package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model

import android.content.Context
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FileUtils
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.customLeftPad
import org.apache.commons.lang3.StringUtils
import java.io.File
import java.util.*

class HexIntel(hex: File, private val dataPaths: MutableList<String>, private val context: Context) {
    private val pageByAddress: MutableMap<String, HexPage> = TreeMap()
    private val TAG = this.javaClass.simpleName
    init {
        parseByString(hex)
    }

    fun getFullPage(address: String, maxAddressI: Int): HexPage? {
        var addressS = address.removePrefix("0x")
        val iterator = pageByAddress.keys.iterator()
        while (iterator.hasNext()) {
            val startPageAddress = iterator.next()
            val hp = pageByAddress[startPageAddress] ?: continue
            addressS = address.customLeftPad(hp.startAddress.length,  '0')
            if (startPageAddress.equals(addressS, ignoreCase = true)) {
                var hexPage = hp
                while (iterator.hasNext()) {
                    val nextPageAddress = iterator.next()
                    val nextPage = pageByAddress[nextPageAddress] ?: continue
                    val nextStartAddr = SmartUtil.getHexInt(nextPage.startAddress)
                    if (nextStartAddr < maxAddressI) {
                        val prevEndAddressI = SmartUtil.getHexInt(hexPage.getEndAddress())
                        val newStartAddressI = SmartUtil.getHexInt(nextPage.startAddress)
                        val gap = newStartAddressI - prevEndAddressI
                        if (gap > 1_000_000) { // 1MB is suspiciously big for most firmware
                            Log.e(TAG, "Suspicious HEX: requested to fill gap of $gap bytes. Skipping to avoid OOM.")
                            // throw, or skip, or only fill a small max size (e.g. 1MB)
                            // break
                        } else if (gap > 0) {
                            val newData = StringUtils.rightPad("", 2 * gap, "F")
                            hexPage.addData(StringBuffer(newData))
                        }
                        nextPage.getStringData()?.let { StringBuffer(it) }
                            ?.let { hexPage.addData(it) }
                    }
                }
                return hexPage
            }
        }
        return null
    }

    fun getAllPageMuseo(startAddressReq: String, endAddressReqI: Int): List<HexPage> {
        var startAddressReqS = startAddressReq.removePrefix("0x")
        val list = mutableListOf<HexPage>()
        for ((startAddressPageHexS, hp) in pageByAddress) {
            val startAddressHexPageI = SmartUtil.getHexInt(startAddressPageHexS)
            val endAddressHexPageI = SmartUtil.getHexInt(hp.getEndAddress())
            startAddressReqS = startAddressReqS.customLeftPad(hp.startAddress.length, '0')
            val startAddressReqI = SmartUtil.getHexInt(startAddressReqS)
            val inRange = !(startAddressHexPageI >= endAddressReqI || endAddressHexPageI <= startAddressReqI)
            if (inRange) {
                val hexPage = hp.clone() as HexPage
                if (startAddressReqI > startAddressHexPageI) {
                    startAddressReqS = startAddressReqS.customLeftPad(hp.startAddress.length, '0')
                    hexPage.checkStartAddress(startAddressReqS)
                }
                list.add(hexPage)
            }
        }
        return list
    }

    fun getFullPageMuseo(startAddressReq: String, maxAddressReqI: Int): HexPage? {
        var startAddressReqS = startAddressReq.removePrefix("0x")
        for ((startPageAddressS, hp) in pageByAddress) {
            val startPageAddressInt = SmartUtil.getHexInt(startPageAddressS)
            val endAddressI = SmartUtil.getHexInt(hp.getEndAddress())
            startAddressReqS = startAddressReqS.customLeftPad(hp.startAddress.length, '0')
            val startAddressReqI = SmartUtil.getHexInt(startAddressReqS)
            if (startAddressReqI in startPageAddressInt..endAddressI) {
                val hexPage = hp.clone() as HexPage
                if (startAddressReqI > startPageAddressInt) {
                    startAddressReqS = startAddressReqS.customLeftPad(hp.startAddress.length, '0')
                    hexPage.checkStartAddress(startAddressReqS)
                }
                return hexPage
            }
        }
        return null
    }

    fun getPageByAddress(address: String): HexPage? {
        var addr = address.removePrefix("0x")
        for ((key, hp) in pageByAddress) {
            addr = addr.customLeftPad(hp.startAddress.length, '0')
            if (key.equals(addr, ignoreCase = true)) return hp
        }
        return null
    }

    fun getPageByNextAddress(address: String): HexPage? {
        var addr = address.removePrefix("0x")
        val iterator = pageByAddress.entries.iterator()
        while (iterator.hasNext()) {
            val (key, hp) = iterator.next()
            addr = addr.customLeftPad(hp.startAddress.length, '0')
            if (key.equals(addr, ignoreCase = true)) {
                return if (iterator.hasNext()) iterator.next().value else null
            }
        }
        return null
    }

    private fun parseByString(hex: File) {
        val records = FileUtils.readFully(hex).split(":").toTypedArray()
        var lastExtAddress = "0000"
        var lastTypeAddress = 2
        val recordByAddress = mutableMapOf<String, HexRecord>()
        val recordList = mutableListOf<HexRecord>()

        for (record in records) {
            if (record.length < 10) continue
            val hr = HexRecord().apply {
                countS = record.substring(0, 2)
                count = countS.toInt(16)
                address = record.substring(2, 6)
                type = record.substring(6, 8)
                data = record.substring(8, 8 + 2 * count)
                chk = record.substring(8 + 2 * count, 8 + 2 * count + 2)
            }
            when (hr.type) {
                "01" -> {}
                "04" -> {
                    lastExtAddress = hr.data
                    lastTypeAddress = 4
                }
                "02" -> {
                    lastExtAddress = hr.data + "0"
                    lastTypeAddress = 2
                }
                else -> if (hr.isDataRecord()) {
                    when (lastTypeAddress) {
                        2 -> hr.addSegmentAddress(lastExtAddress)
                        4 -> hr.addExtAddress(lastExtAddress)
                    }
                    recordList.add(hr)
                    recordByAddress[hr.address] = hr
                } else {
                    Log.d(TAG, "record type non elab: $hr")
                }
            }
        }

        recordList.sort()
        var hexPage: HexPage? = null
        var file: File? = null
        var data = StringBuffer()

        for (record in recordList) {
            if (hexPage == null) {
                hexPage = HexPage(record.address, dataPaths, context)
                pageByAddress[record.address] = hexPage
                data = StringBuffer()
                file = FileUtils.tmpFile(context, "temp.txt")
                dataPaths.add(file.absolutePath)
            }
            if (data.length > 10_000_000) {  // or some reasonable value
                Log.e(TAG, "DATA BUFFER TOO BIG: length=${data.length}")
                throw IllegalStateException("HEX parsing logic produced a buffer that is too large.")
            }
            data.append(record.data)
            if (data.length > 2_000_000) {
                file?.let {
                    FileUtils.appendStringToFile(file, data.toString())
                }
                data.setLength(0)
            }
            hexPage = file?.let { getNextBlock(data, it, recordByAddress, record, hexPage) }
        }
    }

    private fun getNextBlock(
        data: StringBuffer,
        file: File,
        recordByAddress: Map<String, HexRecord>,
        r: HexRecord,
        currentPage: HexPage?
    ): HexPage? {
        var hexPage = currentPage
        var endAddress = r.getEndAddress()
        var nextR = recordByAddress[endAddress]
        var append = ""

        if (nextR == null) {
            for (i in 0 until 1) {
                endAddress = SmartUtil.addHex(endAddress, 1)
                nextR = recordByAddress[endAddress]
                append += "FF"
                if (nextR != null) break
            }
            if (nextR != null) {
                data.append(append)
            } else {
                FileUtils.appendStringToFile(file, data.toString())
                hexPage?.setDataFile(file)
                hexPage = null
            }
        }
        return hexPage
    }
}

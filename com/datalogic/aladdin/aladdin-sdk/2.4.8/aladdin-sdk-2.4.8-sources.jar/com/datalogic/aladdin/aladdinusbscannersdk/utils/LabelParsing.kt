package com.datalogic.aladdin.aladdinusbscannersdk.utils

/**
 * Data class representing a label format entry
 */
data class LabelFormatEntry(
    val tagName: String?,
    val usaCode: String?,
    val euCode: String?,
    val scrs232: String?,
)

/**
 * Data class representing a parsed label with its metadata
 */
data class ParsedLabel(
    val rawData: String,
    val parsedData: String,
    val labelType: LabelFormatEntry?
)

class LabelParsing {
    companion object {
        private const val LABEL_START = "LABEL_START"
        private const val LABEL_END = "LABEL_END"

        /**
         * Parse a label string by extracting content between LABEL_START and LABEL_END markers
         */
        fun parseLabel(label: String): String {
            return label.substringAfter(LABEL_START).substringBefore(LABEL_END).trim()
        }

        /**
         * Check if a label string contains valid start and end markers
         */
        fun isValidLabel(label: String): Boolean {
            return label.contains(LABEL_START) && label.contains(LABEL_END)
        }

        /**
         * Parse a label with full metadata information
         */
        fun parseLabelWithMetadata(label: String): ParsedLabel {
            val parsedData = parseLabel(label)
            val labelType = identifyLabelType(label)
            return ParsedLabel(label, parsedData, labelType)
        }

        /**
         * Get label format entry by tag name
         */
        fun getLabelFormatByTagName(tagName: String): LabelFormatEntry? {
            return LabelFormat.findByTagName(tagName)?.toLabelFormatEntry()
        }

        /**
         * Get label format entry by USA code
         */
        fun getLabelFormatByUSACode(code: String): LabelFormatEntry? {
            return LabelFormat.findByUSACode(code)?.toLabelFormatEntry()
        }

        /**
         * Get label format entry by EU code
         */
        fun getLabelFormatByEUCode(code: String): LabelFormatEntry? {
            return LabelFormat.findByEUCode(code)?.toLabelFormatEntry()
        }

        /**
         * Get label format entry by SCRS232 code
         */
        fun getLabelFormatBySCRS232Code(code: String): LabelFormatEntry? {
            return LabelFormat.findBySCRS232Code(code)?.toLabelFormatEntry()
        }

        /**
         * Identify the label type based on various criteria
         */
        fun identifyLabelType(label: String): LabelFormatEntry? {
            LabelFormat.entries.forEach { labelFormat ->
                labelFormat.usaCode?.let {
                    if (label.contains(
                            it,
                            ignoreCase = true
                        )
                    ) return labelFormat.toLabelFormatEntry()
                }
                labelFormat.euCode?.let {
                    if (label.contains(
                            it,
                            ignoreCase = true
                        )
                    ) return labelFormat.toLabelFormatEntry()
                }
                if (label.contains(labelFormat.tagName, ignoreCase = true)) {
                    return labelFormat.toLabelFormatEntry()
                }
            }
            return null
        }

        /**
         * Get all USA codes
         */
        fun getAllUSACodes(): List<String> {
            return LabelFormat.entries.mapNotNull { it.usaCode }.distinct()
        }

        /**
         * Get all EU codes
         */
        fun getAllEUCodes(): List<String> {
            return LabelFormat.entries.mapNotNull { it.euCode }.distinct()
        }

        /**
         * Get all Tag Names
         */
        fun getAllTagNames(): List<String> {
            return LabelFormat.entries.map { it.tagName }
        }

        /**
         * Check if a USA code exists
         */
        fun isValidUSACode(code: String): Boolean {
            return LabelFormat.entries.any { it.usaCode.equals(code, ignoreCase = true) }
        }

        /**
         * Check if an EU code exists
         */
        fun isValidEUCode(code: String): Boolean {
            return LabelFormat.entries.any { it.euCode.equals(code, ignoreCase = true) }
        }

        /**
         * Check if a Tag Name exists
         */
        fun isValidTagName(tagName: String): Boolean {
            return LabelFormat.entries.any { it.tagName == tagName }
        }
    }
}

/**
 * Extension function to convert LabelFormat enum to LabelFormatEntry data class
 */
private fun LabelFormat.toLabelFormatEntry(): LabelFormatEntry {
    return LabelFormatEntry(
        tagName = this.tagName,
        usaCode = this.usaCode,
        euCode = this.euCode,
        scrs232 = this.scrs232
    )
}

/**
 * Comprehensive enum containing label formats that match BarcodeType class
 * Maps Tag Names (extracted from UPOS Identifier Names), USA codes, EU codes, and SCRS232 codes
 * Updated based on LabelParsingformat.txt with UPOS-based tagNames
 */
enum class LabelFormat(
    val tagName: String,
    val usaCode: String?,
    val euCode: String?,
    val scrs232: String?
) {
    // Barcode types matching BarcodeType enum with UPOS-based tagNames from LabelParsingformat.txt
    ABC_CODABAR("Codabar", "53", "53", null),
    ANKER_PLESSEY("PLESSEY", "6F", "6F", null),
    AZTEC("AZTEC", "417A", "21", "417A"),
    BC412("OTHER", "39", "39", null),
    CHINA_SENSIBLE_CODE("HANXIN", "2453", "2453", null),
    CODABAR("Codabar", "25", "52", "25"),
    ISSN("EAN13", "6E", "6E", null),
    CODABLOCK_A("CodablockA", "6E", "6E", null),
    CODABLOCK_F("CodablockF", "6C", "6D", null),
    CODE11("Code11", "4345", "62", null),
    CODE128("Code128", "23", "54", "4233"),
    CODE16K("Code16k", "70", "70", null),
    CODE39("Code39", "2A", "56", "4231"),
    CODE39_CIP("CodeCIP", "59", "59", null),
    CODE39_DANISH_PPT("Code39", "2459", "2459", null),
    CODE39_LAPOSTE("Code39", "2461", "2461", null),
    CODE39_PZN("Code39", "245A", "245A", null),
    CODE4("OTHER", "34", "34", null),
    CODE49("Code49", "71", "71", null),
    CODE5("OTHER", "6A", "6A", null),
    CODE93("Code93", "26", "55", "26"),
    COMPRESSED_2OF5("ITF_CK", "68", "68", null),
    DATABAR_14("RSS14", "5234", "75", "5234"),
    DATABAR_14_COMPOSITE("GS1DATABAR", "5234", "63", "5234"),
    DATABAR_EXPANDED("RSS_EXPANDED", "5258", "74", "5258"),
    DATABAR_EXPANDED_COMPOSITE("GS1DATABAR_E", "5258", "64", "5258"),
    DATABAR_LIMITED("GS1DATABAR_TYPE2", "524C", "76", "524C"),
    DATABAR_LIMITED_COMPOSITE("GS1DATABAR_TYPE2", "524C", "69", "524C"),
    S25("TF", "73", "50", "73"),
    DATALOGIC_2OF5("TF", "73", "73", null),
    DATAMATRIX("DATAMATRIX", "446D", "77", "446D"),
    EAN128("EAN128", "5D4331", "6B", "5D4331"),
    EAN128_COMPOSITE("EAN128", "5D4331", "2445", "5D4331"),
    EAN13("EAN13", "46", "42", "46"),
    EAN13_COMPOSITE("EAN13_S", "46", "2446", "46"),
    EAN13_P2("EAN13_S", "46", "4C", "46"),
    EAN13_P5("EAN13_S", "46", "4D", "46"),
    EAN13_P8("EAN13_S", "46", "23", "46"),
    EAN8("EAN8", "4646", "41", "4646"),
    EAN8_COMPOSITE("EAN8_S", "4646", "2447", "4646"),
    EAN8_P2("EAN8_S", "4646", "4A", "4646"),
    EAN8_P5("EAN8_S", "4646", "4B", "4646"),
    EAN8_P8("EAN8_S", "4646", "2A", "4646"),
    FOLLET_2OF5("ITF", "4F", "4F", null),
    GS1_DATAMATRIX("GS1DATAMATRIX", "4467", "2477", "4467"),
    GS1_QR_CODE("GS1QRCODE", "5147", "2471", "5147"),
    GTIN("OTHER", "47", "2441", "47"),
    GTIN2("OTHER", "4732", "2442", "4732"),
    GTIN5("OTHER", "4735", "2443", "4735"),
    GTIN8("OTHER", "4738", "2444", "4738"),
    I2OF5("ITF", "69", "4E", "4232"),
    I2OF5_CIP_HR("ITF", "65", "65", null),
    IATA_INDUSTRIAL_2OF5("TF", "4941", "26", null),
    INDUSTRIAL_2OF5("TF", "57", "57", null),
    ISBN("EAN13", "49", "40", "49"),
    ISBT128_CONCAT("ISBT128", "66", "66", null),
    MATRIX_2OF5("TFMAT", "67", "67", null),
    MAXICODE("MAXICODE", "4D43", "78", null),
    PDF417("PDF417", "50", "72", "50"),
    MICRO_PDF("UPDF417", "6D50", "38", "6D50"),
    QR_CODE("QRCODE", "5152", "79", "5152"),
    MICROQR("UQRCODE", "2451", "2451", "2451"),
    MSI("MSI", "40", "5A", "40"),
    NW7_CODABAR("Codabar", "244E", "244E", null),
    PLESSEY("PLESSEY", "61", "61", null),
    POSTAL_AUSTRALIAN("AusPost", "244B", "244B", null),
    POSTAL_IMB("UsIntelligent", "2456", "2456", null),
    POSTAL_JAPANESE("JapanPost", "2452", "2452", null),
    POSTAL_KIX("DutchKix", "2455", "2455", null),
    POSTAL_PLANET("UsPlanet", "2457", "2457", null),
    POSTAL_PORTUGAL("OTHER", "2450", "2450", null),
    POSTAL_ROYAL_MAIL("UkPost", "244D", "244D", null),
    POSTAL_SWEDISH("SwedenPost", "2458", "2458", null),
    POSTNET("PostNet", "244C", "244C", null),
    TRIOPTIC("TRIOPTIC39", "2454", "2454", null),
    UPCA("UPCA", "41", "43", "41"),
    UPCA_COMPOSITE("UPCA_S", "41", "2448", "41"),
    UPCA_P2("UPCA_S", "41", "46", "41"),
    UPCA_P5("UPCA_S", "41", "47", "41"),
    UPCA_P8("UPCA_S", "41", "51", "41"),
    UPCE("UPCE", "45", "44", "45"),
    UPCE_COMPOSITE("UPCE_S", "45", "244A", "45"),
    UPCE_P2("UPCE_S", "45", "48", "45"),
    UPCE_P5("UPCE_S", "45", "49", "45"),
    UPCE_P8("UPCE_S", "45", "45", "45"),
    CODE32("Code32", null, "58", null),
    OCR_A("OCRA", "246F", "246F", null),
    OCR_B("OCRB", "2470", "2470", null);

    companion object {
        fun findByTagName(tagName: String): LabelFormat? = entries.find { it.tagName == tagName }
        fun findByUSACode(code: String): LabelFormat? = entries.find { it.usaCode.equals(code, ignoreCase = true) }
        fun findByEUCode(code: String): LabelFormat? = entries.find { it.euCode.equals(code, ignoreCase = true) }
        fun findBySCRS232Code(code: String): LabelFormat? = entries.find { it.scrs232 == code }
    }
}

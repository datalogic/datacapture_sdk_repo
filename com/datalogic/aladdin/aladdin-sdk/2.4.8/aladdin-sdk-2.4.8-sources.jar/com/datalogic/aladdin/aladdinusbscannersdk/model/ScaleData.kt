package com.datalogic.aladdin.aladdinusbscannersdk.model

import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.hexStringToByteArray
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.ScaleUnit

/**
 * Represents scale weight data and status received from a Datalogic scanner with scale.
 */
data class ScaleData(
    /**
     * Status of the scale (e.g. "Stable", "Unstable", "Over Capacity", etc.)
     */
    val status: String,

    /**
     * Weight reading from the scale, formatted with units (e.g. "01.23 lb")
     * Will be empty if status indicates no valid weight.
     */
    val weight: String,
    val unit: ScaleUnit
) {
    companion object { // Protocol Check/Configuration Commands
        val CHECK_SCALE_PROTOCOL_CMD: ByteArray = hexStringToByteArray("0011047C")
        val ENABLE_SCALE_PROTOCOL_CMD: ByteArray = hexStringToByteArray("0010047C00")
        val RESET_DEVICE_CMD: ByteArray = hexStringToByteArray("001A")

        // Weight request command (S14 + CR)
        val WEIGHT_REQUEST_CMD: ByteArray = byteArrayOf(0x53, 0x31, 0x34, 0x0D) // "S14\r"

        val SCALE_STATUS_CMD: ByteArray = byteArrayOf(0x53, 0x31, 0x33, 0x0D) // "S13\r"

        val WEIGHT_REQUEST_CMD_OEM_ENGLISH_WEIGHT: ByteArray = byteArrayOf(0x01, 0, 0, 0, 0)
        val WEIGHT_REQUEST_CMD_OEM_METRIC_WEIGHT: ByteArray = byteArrayOf(0x02, 0, 0, 0, 0)
        val WEIGHT_REQUEST_CMD_OEM_ZERO_SCALE: ByteArray = byteArrayOf(0x03, 0, 0, 0, 0)
        val REPORT_SCALE_CONFIG: ByteArray = byteArrayOf(0x21, 0, 0, 0, 0)

        // Scale status values from protocol documentation
        val STATUS_NOT_READY: Char = '0'      // 0x30
        val STATUS_UNSTABLE: Char = '1'        // 0x31
        val STATUS_OVER_CAPACITY: Char = '2'  // 0x32
        val STATUS_STABLE_ZERO: Char = '3'     // 0x33
        val STATUS_STABLE_NON_ZERO: Char = '4' // 0x34
        val STATUS_UNDER_ZERO: Char = '5'    // 0x35
    }
}

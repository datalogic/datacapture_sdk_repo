package com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners

import com.datalogic.aladdin.aladdinusbscannersdk.model.UsbScanData

/**
 * This interface contains a single abstract method that is triggered when a device scans a barcode.
 */
fun interface UsbScanListener {
    /**
     * Function called when a Usb scan event is fired.
     * Receives ScanData of the scanned barcode as an argument.
     */
    fun onScan(scanData: UsbScanData)
}
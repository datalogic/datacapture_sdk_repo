package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class DeviceInterface(val interfaceName: String, val value: ByteArray) {
    RS232("RS232", byteArrayOf(0x00, 0x05)),
    RS232_WN("RS232_WN", byteArrayOf(0x00, 0x12)),
    RS232_SC("RS232_SC", byteArrayOf(0x00, 0x20)),
    RS232_DEBUG("RS232_DEBUG", byteArrayOf(0x00, 0x01)),
    USB_COM("USB_COM", byteArrayOf(0x00, 0x47)),
    USB_OEM("USB_OEM", byteArrayOf(0x00, 0x45)),
    USB_KEYBOARD("USB_KEYBOARD", byteArrayOf(0x00, 0x35)),
    USB_COMSC("USB_COMSC", byteArrayOf(0x00, 0x1E)),
    System("System", byteArrayOf(0x00, 0x46)),
}
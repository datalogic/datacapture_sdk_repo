package com.datalogic.aladdin.aladdinusbscannersdk.utils.constants

object AladdinConstants {
    const val FAILURE = -1
    const val SUCCESS = 0
    const val LISTENER_ALREADY_REGISTERED_ERROR = 2
    const val LISTENER_NOT_REGISTERED_ERROR = 3
    const val USB_PERMISSION_DENIED = 4


    const val OPEN_FAILURE = 101
    const val CLAIM_FAILURE = 102
    const val RELEASE_FAILURE = 103
    const val CLOSE_FAILURE = 104
    const val ENABLE_FAILURE = 105
    const val DISABLE_FAILURE = 106
    const val CAN_NOT_FIND_DEVICE = 107
    const val CAN_NOT_FIND_COM_PORT = 108
    const val ERR_DIO_NOT_ALLOWED = -114
    /**
     * Direct IO command is undefined.
     */
    const val ERR_DIO_UNDEFINED = -115

    //region Errors
    /**
     * Generic command error.
     */
    const val ERR_CMD = -100
    const val ERR_FAILURE = 111
    const val ERR_TIMEOUT = 112
    const val CONFIG_ERR_FAILURE = 113

    val listIfTypeMap = hashMapOf(
        "05" to "RS232 STD",
        "47" to "USB COM STD",
        "12" to "RS232 WN",
        "40" to "USB MAG",
        "23" to "IBM P9B",
        "29" to "KBD AT",
        "26" to "KBD AT ALT",
        "11" to "KBD AT NK",
        "10" to "KBD AT ALT NK",
        "44" to "USB POS",
        "41" to "USB TEC",
        "13" to "RS232 OPOS",
        "45" to "USB OEM",
        "35" to "USB KBD",
        "2B" to "USB KBD ALT",
        "4D" to "USB COMPOSITE",
        "43" to "RS232 AUX",
        "4E" to "WIFI STD",
        "24" to "x"
    )
    const val S37 = "S37"
    const val SWU = "SWU"
    const val DFW = "DFW"

    const val COMPANY_NAME = "Datalogic"
    const val VERSION_SDK  = "AndroidSDK"

}
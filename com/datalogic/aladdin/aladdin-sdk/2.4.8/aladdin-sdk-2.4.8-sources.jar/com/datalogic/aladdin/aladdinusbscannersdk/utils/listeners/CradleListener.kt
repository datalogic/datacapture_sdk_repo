package com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners

import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DeviceStatus

interface CradleListener {
    fun onDockListener(docked: Boolean)
    fun onLinkListener(linked: Boolean)
}
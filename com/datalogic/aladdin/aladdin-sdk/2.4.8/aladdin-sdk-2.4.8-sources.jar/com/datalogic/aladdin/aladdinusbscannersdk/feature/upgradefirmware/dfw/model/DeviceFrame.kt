package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model

object DeviceFrame {
    const val START: Byte = 0x4C
    const val TERMINATOR: Byte = 0x0D
    const val ECHO: Byte = 0x41
    const val NEW_ECHO: Byte = 0x42
    const val ETX: Byte = 0x03
    const val ACK: Byte = 0x06
    const val NAK: Byte = 0x15
    const val WAIT_END: Byte = 0x24
    const val WAIT_END_OK: Byte = 0x25

    val etxBytes = byteArrayOf(START, ETX, TERMINATOR)
    val ackBytes = byteArrayOf(START, ACK, TERMINATOR)
    val nakBytes = byteArrayOf(START, NAK, TERMINATOR)
}

package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS

import android.content.ContentValues.TAG
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.model.DataUtils.getUleCmdList
import com.datalogic.aladdin.aladdinusbscannersdk.model.FRSInterface
import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.addChecksum
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.formatLine
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.parseScannerResponse
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.byteArrayToHexString
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.byteArrayToHexStringForLog
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants
import org.apache.commons.lang3.ArrayUtils
import java.nio.ByteBuffer
import java.util.Arrays


class FRSDevice {
    companion object {
        val READ_CONFIGURATION_ITEM: ByteArray = byteArrayOf(0x00, 0x11)
        val CI_INTERFACE_TYPE: String = "0001"
        val CA_LABEL_EDIT_SCRIPT = byteArrayOf(0x7F, 0xF8.toByte())
        val frsInterfaceList = arrayListOf(
            FRSInterface("RS232-STD", "0005"),
            FRSInterface("RS232-WN", "0012"),
            FRSInterface("RS232-Debug", "0001"),
            FRSInterface("Keyboard", "0035"),
            FRSInterface("USB-COM", "0047"),
            FRSInterface("USB-OEM", "0045"),
            FRSInterface("ORT", "0099"),
            FRSInterface("USB-COMSC", "001E")
        )
        val READ_VERSION: ByteArray = byteArrayOf(0x01, 0x1B)
    }

    fun createFullFRSCommand(commandBytes: ByteArray): ByteArray {
        // Step 1: Start of Header (SOH) is fixed to 0x81
        val soh: Byte = 0x81.toByte()

        // Extract command (first two bytes) and data (remaining bytes)
        val cmdBytes = if (commandBytes.size >= 2) {
            byteArrayOf(commandBytes[0], commandBytes[1])
        } else {
            // Ensure we have at least two bytes for command
            byteArrayOf(
                if (commandBytes.isNotEmpty()) commandBytes[0] else 0x00,
                if (commandBytes.size > 1) commandBytes[1] else 0x00
            )
        }

        // Extract any additional bytes as data
        val data = if (commandBytes.size > 2) {
            commandBytes.copyOfRange(2, commandBytes.size)
        } else {
            ByteArray(0)
        }

        // Step 2: Length calculation - Total length excluding SOH
        // Length = Command(2 bytes) + Data + BCC (1 byte)
        val length = 2 + data.size + 1

        // Convert length to a 4-byte array (MSB first)
        val lengthBytes = ByteArray(4)
        for (i in 0 until 4) {
            lengthBytes[i] = (length shr (8 * (3 - i)) and 0xFF).toByte()
        }

        // Step 3: Prepare the full byte array for message
        val fullMessage =
            ByteArray(1 + 4 + 2 + data.size + 1) // SOH + Length + Command + Data + BCC

        // Place SOH in the first byte
        fullMessage[0] = soh

        // Place length bytes starting from index 1
        System.arraycopy(lengthBytes, 0, fullMessage, 1, 4)

        // Place command bytes starting from index 5
        System.arraycopy(cmdBytes, 0, fullMessage, 5, 2)

        // Place data starting from index 7 (if any)
        if (data.isNotEmpty()) {
            System.arraycopy(data, 0, fullMessage, 7, data.size)
        }

        // Step 4: Calculate the BCC (checksum)
        val bcc = calculateChecksum(fullMessage)

        // Place BCC in the last byte
        fullMessage[fullMessage.size - 1] = bcc

        return fullMessage
    }

    private fun calculateChecksum(message: ByteArray): Byte {
        // Sum all bytes except for the BCC
        var sum = 0
        for (i in message.indices) {
            if (i != message.size - 1) { // Skip the BCC byte (last byte)
                sum += message[i].toInt() and 0xFF
            }
        }

        // Reduce sum by subtracting 0x100 if necessary
        while (sum >= 0x100) {
            sum -= 0x100
        }

        // Calculate BCC (two's complement of the sum)
        val bcc = (0x100 - sum) and 0xFF
        return bcc.toByte()
    }

    /**
     * Parses the response from a Magellan READ_VERSION command
     *
     * @param response The response byte array from the device
     * @return The parsed device model string
     */
    fun parseMagellanVersionResponse(response: ByteArray): String {
        if (response.isEmpty()) {
            return "Magellan Scanner"
        }

        try {
            Log.d(
                TAG,
                "Magellan raw version response: ${SmartUtil.byteArrayToHexStringWithSpaces(response)}"
            )

            // Extract the actual data from the full response according to protocol
            val formattedResponse = extractMagellanResponseData(response)
            Log.d(
                TAG,
                "Extracted data: ${SmartUtil.byteArrayToHexStringWithSpaces(formattedResponse)}"
            )

            // The scanner type is typically in the second byte
            if (formattedResponse.size >= 2) {
                val scannerType = formattedResponse[1]

                // Get scanner name from the type mapping
                val scannerString =
                    FRSScannerTypes.scannerTypeToText.getOrDefault(scannerType, null)

                Log.d(
                    TAG,
                    "Magellan scanner type byte: 0x${scannerType.toString(16)}, mapped to: $scannerString"
                )

                // If we have a valid scanner model from the type byte, use it
                return when {
                    scannerString != null && scannerString != "Unknown" -> scannerString
                    else -> "Magellan Scanner"
                }
            }

            return "Magellan Scanner"
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing Magellan version response", e)
            return "Magellan Scanner"
        }
    }

    /**
     * Extracts the actual data portion from the full response based on protocol headers
     */
    fun extractMagellanResponseData(fullResponse: ByteArray?): ByteArray {
        if (fullResponse == null || fullResponse.isEmpty()) {
            return ByteArray(0)
        }

        // Check for special headers (SYN, DC3, DC4) that need to be skipped
        var startIndex = 0
        if (fullResponse[0].toInt() and 0xFF in arrayOf(0x16, 0x13, 0x14)) {
            startIndex = 1
            if (fullResponse.size <= 1) {
                return ByteArray(0)
            }
        }

        // Check header type
        return when (fullResponse[startIndex].toInt() and 0xFF) {
            // Standard header (STX)
            0x02 -> {
                if (fullResponse.size < startIndex + 3) {
                    return ByteArray(0)
                }
                val expectedLength = fullResponse[startIndex + 1].toInt() and 0xFF
                if (fullResponse.size - startIndex - 2 < expectedLength) {
                    return ByteArray(0)
                }
                Arrays.copyOfRange(fullResponse, startIndex + 2, startIndex + 2 + expectedLength)
            }

            // Extended header
            0x82 -> {
                if (fullResponse.size < startIndex + 6) {
                    return ByteArray(0)
                }
                val expectedLength = ((fullResponse[startIndex + 1].toInt() and 0xFF) shl 24) or
                        ((fullResponse[startIndex + 2].toInt() and 0xFF) shl 16) or
                        ((fullResponse[startIndex + 3].toInt() and 0xFF) shl 8) or
                        (fullResponse[startIndex + 4].toInt() and 0xFF)
                if (fullResponse.size - startIndex - 5 < expectedLength) {
                    return ByteArray(0)
                }
                Arrays.copyOfRange(fullResponse, startIndex + 5, startIndex + 5 + expectedLength)
            }

            // Single byte response
            else -> {
                if (fullResponse.size == startIndex + 1) {
                    Arrays.copyOfRange(fullResponse, startIndex, startIndex + 1)
                } else {
                    // For any other format, return full response for compatibility
                    Arrays.copyOfRange(fullResponse, startIndex, fullResponse.size)
                }
            }
        }
    }

    /**
     * Read all FRS configuration features from the device
     *
     * @param connection The USB serial connection to the device
     * @return A map of configuration features and their values
     */
    fun readAllFrsConfig(connection: ServiceSerial): Map<String, String> {
        Log.d("UsbConnection", "Reading all FRS features at once")

        return try {
            // Create command to read all configurations at once
            val command = createFullFRSCommand(FRSContants.READ_SUCCESSIVE_CONFIGURATION_GROUPS)

            // Send command and get response with appropriate timeout
            val response = connection.sendReceive(
                command = command,
                startTimeout = 700,
                endTimeout = 700
            ) ?: run {
                Log.e("UsbConnection", "No response received for configuration read command")
                return emptyMap()
            }

            if (response.isEmpty()) {
                Log.e("UsbConnection", "Empty response received for configuration read command")
                return emptyMap()
            }

            // Extract and process the data
            val parsedData = extractMagellanResponseData(response)
            Log.d("UsbConnection", "Full parsed data: ${byteArrayToHexStringForLog(parsedData)}")

            if (parsedData.isEmpty()) {
                Log.e("UsbConnection", "No valid data extracted from response")
                return emptyMap()
            }

            Log.d("UsbConnection", "Parsed data length: ${parsedData.size} bytes")
            return parseFrsConfigTlv(parsedData)

        } catch (e: Exception) {
            Log.e("UsbConnection", "Error reading all FRS features: ${e.message}", e)
            emptyMap()
        }
    }

    /**
     * Parse TLV (Type-Length-Value) formatted configuration data from buffer
     *
     * @param data The raw data buffer to parse
     * @return Map of configuration tag IDs and their values
     */
    fun parseFrsConfigTlv(data: ByteArray): Map<String, String> {
        val result = mutableMapOf<String, String>()
        val buffer = ByteBuffer.wrap(data)

        // Skip header bytes - typically first 8 bytes
        if (buffer.remaining() > 8) {
            buffer.position(8)
        }

        try {
            // Parse TLV structures until we run out of data
            while (buffer.remaining() > 2) {
                // Read configuration item number (2 bytes)
                val confItemNumber = buffer.getShort().toInt() and 0xFFFF
                var tagSize = 1

                // Check if high bit is set (variable length tag)
                if ((confItemNumber and 0x8000) > 0) {
                    // Clear high bit from item number
                    val actualItemNumber = confItemNumber and 0x7FFF
                    // Read tag size
                    tagSize = buffer.get().toInt() and 0xFF

                    // Read tag value
                    val tagValue = ByteArray(tagSize)
                    if (buffer.remaining() >= tagSize) {
                        buffer.get(tagValue, 0, tagSize)
                        // Format tag ID as 4-digit hex string
                        val tagId = String.format("%04X", actualItemNumber)
                        // Format value as hex string
                        val value = tagValue.joinToString("") {
                            String.format("%02X", it.toInt() and 0xFF)
                        }
                        result[tagId] = value
                    }
                } else {
                    // Fixed length tag (1 byte)
                    if (buffer.remaining() >= 1) {
                        val tagValue = buffer.get().toInt() and 0xFF
                        // Format tag ID as 4-digit hex string
                        val tagId = String.format("%04X", confItemNumber)
                        result[tagId] = String.format("%02X", tagValue)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("UsbConnection", "Error parsing TLV data: ${e.message}", e)
        }
        return result
    }

    fun commit(copyToLevel: String): String {
        return when (copyToLevel) {
            CopyToLevel.COPY_TO_FACTORY.toString() -> formatLine(addChecksum("7FFE01"), "Commit interface to factory")
            CopyToLevel.COPY_TO_USER_AND_FACTORY.toString() -> formatLine(addChecksum("7FFF01"), "Commit interface to user AND factory")
            CopyToLevel.COPY_TO_USER.toString() -> formatLine(addChecksum("7FFD01"), "Save interface to user area")
            else -> formatLine(addChecksum("7FFD01"), "Save interface to user area")
        }
    }

    fun generateInterfaceHeader(currentInterface: FRSInterface): String {
        val temp = "7FFB${currentInterface.value}"
        return formatLine(addChecksum(temp), "Restore from Master Defaults")
    }

    fun setULE(sb: StringBuffer, ule: String) {
        sb.append("#-------< BEGIN ULE SCRIPT >-------------------------------\r\n")
        val cmdList = getUleCmdList(ule).toTypedArray()
        for (cmdRaw in cmdList) {
            var cmd = cmdRaw.substring(2) // Remove "$U" prefix
            cmd = byteArrayToHexString(CA_LABEL_EDIT_SCRIPT) + cmd
            sb.append(addChecksum(cmd)).append("\r\n")
        }
        sb.append("#-------< END ULE SCRIPT >-------------------------------\r\n")
    }

    fun getNextTagFromBuffer(buffer: ByteBuffer): Pair<String, String?> {
        var confItemNumber = buffer.char.code
        var tagSize = 1

        if ((confItemNumber and 0x8000) > 0) {
            confItemNumber = confItemNumber and 0x7FFF
            tagSize = buffer.get().toInt() and 0xFF
        }

        val tagValue = ByteArray(tagSize)
        buffer.get(tagValue, 0, tagSize)

        val tagName = confItemNumber.toString(16).padStart(4, '0').uppercase()
        val value = byteArrayToHexString(tagValue)

        return tagName to value
    }

    fun readUle(serial: ServiceSerial): String {
        val response = serial.sendReceive(createFullFRSCommand(
            FRSScannerTypes.READ_ULE), 500, 200)
        val result = response?.let { parseScannerResponse(it) }
        return String(result?.get("data") as ByteArray).substring(8)
    }

    fun getResponseTypeName(response: ByteArray?): String {
        return when {
            response == null -> "NULL"
            response.contentEquals(FRSScannerTypes.ACK_BYTEARRAY) -> "ACK"
            response.contentEquals(FRSScannerTypes.NAK_BYTEARRAY) -> "NAK"
            response.contentEquals(FRSScannerTypes.BEL_BYTEARRAY) -> "BEL"
            response.contentEquals(FRSScannerTypes.CAN_BYTEARRAY) -> "CAN"
            else -> "Unknown Response"
        }
    }
}
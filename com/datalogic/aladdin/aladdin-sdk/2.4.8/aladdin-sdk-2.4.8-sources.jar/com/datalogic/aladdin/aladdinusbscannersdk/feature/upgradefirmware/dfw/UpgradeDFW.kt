package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw

import android.content.Context
import android.hardware.usb.*
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.FirmwareUpdater
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model.DeviceFrame
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model.DevicePid
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model.FirmwareData
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model.FirmwarePage
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model.HexBlock
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model.HexPage
import com.datalogic.aladdin.aladdinusbscannersdk.model.DatalogicDevice
import com.datalogic.aladdin.aladdinusbscannersdk.model.DatalogicDeviceManager
import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.PROTOCOL_1D10
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.PROTOCOL_1D101
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.PROTOCOL_1D11
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.PROTOCOL_1D12
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.PROTOCOL_1D21
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSDevice
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSScannerTypes
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.REQUEST_CODE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.REQUEST_VALUE_FEATURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.REQUEST_VALUE_OUT
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DeviceType
import kotlinx.coroutines.*
import java.io.File
import java.util.IllegalFormatCodePointException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.collections.contains
import kotlin.collections.contentToString
import kotlin.math.max

class UpgradeDFW(
    firmwareFile: File,
    private val datalogicDevice: DatalogicDevice,
    private val context: Context, override var isUpgradeBoot: Boolean
) : FirmwareUpdater() {
    companion object {
        private val TAG = this.javaClass.simpleName

        // Protocol constants
        private const val ACK = 0x06
        private const val NACK = 0x15
        private const val RESTART_RESPONSE = 0x31
        private const val INSTALLING_RESPONSE = 0x27

        // Vendor and Product IDs
        const val FIRST_VENDOR_ID = 0x080C
        const val SECOND_VENDOR_ID = 0x05F9
        const val FIRST_PRODUCT_ID = 0x0700
        const val SECOND_PRODUCT_ID = 0x5204
        const val SECOND_PRODUCT_ID_FOR_OEM = 0x5800

        // Packet constants
        const val PACKET_LENGTH = 2048
        val ECHO = byteArrayOf(0x45, 0x69, 0x0D, 0x00, 0x00)
        val END = byteArrayOf(0x45, 0x6C, 0x0D, 0x00, 0x00)
        private val START_APP = byteArrayOf(0x45, 0x70, 0x0D, 0x00, 0x00)
        private val START_APP_AND_DELETE = byteArrayOf(0x45, 0x71, 0x0D, 0x00, 0x00)
        val JOIN = byteArrayOf(0x45, 0x6D, 0x00, 0x00, 0x0D)

        // Block-based protocol commands
        private val JOIN_BLOCK =
            byteArrayOf(0x45, 0x6F, 0x00, 0x0D, 0x00) // {0x45, 0x6F=opcode, 0x00=id, 0x0D}
        private val HOST_END =
            byteArrayOf(0x45, 0x6C, 0x00, 0x0D, 0x00) // {0x45, 0x6C=opcode, 0x00=id, 0x0D}
        private val VERSION =
            byteArrayOf(0x45, 0x72, 0x00, 0x0D, 0x00) // {0x45, 0x72=opcode, 0x00=id, 0x0D}
        private val REJECT = byteArrayOf(0x45, 0x6E, 0x0D, 0x00, 0x00)

        private const val FLASH_WRITE_START = 0x24
        private const val FLASH_WRITE_END = 0x25
        private const val VERSION_RESPONSE = 0x26
        var isUpgradeDFW = false
        var pidHID: String? = null
        private val VERSION101 = byteArrayOf(
            0x45, 0x72, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0D
        )
        const val RESULT_ETX = 0
        const val RESULT_ACK = 1
        const val RESULT_NACK = 2
        const val RESULT_TIMEOUT = 3
        const val RESULT_ERROR = 4

        // Response codes
        const val DEVICE_RESPONSE_ID = 0x4C
        const val PID_RESPONSE = 0x42
        const val ETX = 0x03
        const val SGN1_ERR = 0x21
        const val SGN2_ERR = 0x22
        const val LOW_BATTERY_ERR = 0x23
        const val GET_ID_RESPONSE = 0x43

        // Flash write results
        const val WRITE_FLASH_OK = "0"
        const val WRITE_FLASH_STOP_BY_USER = "1"
        const val WRITE_FLASH_TIMEOUT = "2"
        val S_MODE = "\$S\r".toByteArray()
        val RESET_HID = "\$i\r".toByteArray()
        val RESTART = RESTART_RESPONSE.toString(16)
        val FLASH_WR_END = FLASH_WRITE_END.toString(16)
    }

    private var usbConnection: UsbDeviceConnection? = null
    private var usbInterface: UsbInterface? = null
    private var usbEndpointIn: UsbEndpoint? = null
    private var usbEndpointOut: UsbEndpoint? = null

    private val isStopped = AtomicBoolean(false)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    var firmwareData: FirmwareData = FirmwareData(firmwareFile, context)
    private var completeStatus = ""
    private var hwid: Byte = 0
    private var totalPages = 0

    val filesByAllPages = mutableListOf<Pair<FirmwarePage, File>>()

    init {
        firmwareData.sendBoot = isUpgradeBoot
        totalPages =
            if (firmwareData.sendBoot)
                firmwareData.mApplicationPages.size + firmwareData.mBootPages.size
            else firmwareData.mApplicationPages.size
        when (val protocol = firmwareData.detectProtocol(firmwareFile)) {
            PROTOCOL_1D10 -> {
                firmwareData.elabXML10()
                firmwareData.setPages()
            }
            PROTOCOL_1D11,PROTOCOL_1D12 -> firmwareData.elabXML11()
            else -> {
                Log.e(TAG, "Unsupported protocol: $protocol")
                // handle error
            }
        }
        for (hd in firmwareData.mHexData) {
            Log.d(TAG, "HexData: pids=${hd.pids}, ids=${hd.ids}, hex(first20)=${hd.hex.take(20)}")
        }
    }

    private fun handleTimeout(serial: ServiceSerial) {
        val maxRetries = 3
        var retryCount = 0
        var success = false

        while (retryCount < maxRetries && !success) {
            try {
                val response = serial.sendReceive(
                    FRSDevice().createFullFRSCommand(FRSScannerTypes.READ_VERSION),
                    1000, 500
                )
                val result = response?.let { CharsUtil.parseScannerResponse(it) }
                val data = result?.get("data") as ByteArray?
                if (data != null && data.size == 56) {
                    hwid = data[1] // hwid = 71 hwid = response[1];
                    success = true
                } else {
                    retryCount++
                    if (retryCount < maxRetries) {
                        Thread.sleep(200L * retryCount)
                    }
                }
            } catch (ex: Exception) {
                retryCount++
                Log.d(TAG, "handleTimeout attempt $retryCount failed: ${ex.message}")
                if (retryCount < maxRetries) {
                    Thread.sleep(200L * retryCount)
                }
            }
        }
        if (!success) {
            Log.d(TAG, "handleTimeout failed after $maxRetries attempts")
        }
    }

    /**
     * Set USB connection from DatalogicDeviceManager
     */
    fun setUsbConnection(
        connection: UsbDeviceConnection?,
        usbInterface1: UsbInterface?,
        endpointIn: UsbEndpoint?,
        endpointOut: UsbEndpoint?
    ) {
        usbConnection = connection
        usbInterface = usbInterface1
        usbEndpointIn = endpointIn
        usbEndpointOut = endpointOut
        Log.d(
            TAG,
            "USB connection set: connection=${connection != null}, interface=${usbInterface != null}, in=${endpointIn != null}, out=${endpointOut != null}"
        )
    }

    /**
     * Check if device is compatible for firmware upgrade
     */
    private fun isCompatibleDevice(device: UsbDevice): Boolean {
        val vendorId = device.vendorId
        val productId = device.productId

        return (vendorId == FIRST_VENDOR_ID || vendorId == SECOND_VENDOR_ID) &&
                (productId == FIRST_PRODUCT_ID || productId == SECOND_PRODUCT_ID ||
                        productId == SECOND_PRODUCT_ID_FOR_OEM)
    }

    /**
     * Start application on device
     */
    suspend fun startApplication(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Starting application on device...")

            val bytesWritten = usbConnection?.bulkTransfer(
                usbEndpointOut,
                START_APP,
                START_APP.size,
                firmwareData?.usbhidDataTimeout!!
            ) ?: -1

            if (bytesWritten > 0) {
                Log.d(TAG, "Application started successfully")
                true
            } else {
                Log.d(TAG, "Failed to start application")
                false
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error starting application", e)
            Log.d(TAG, "Error starting application: ${e.message}")
            false
        }
    }

    /**
     * Start application and delete firmware
     */
    suspend fun startApplicationAndDelete(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Starting application and deleting firmware...")

            val bytesWritten = usbConnection?.bulkTransfer(
                usbEndpointOut, START_APP_AND_DELETE,
                START_APP_AND_DELETE.size, firmwareData?.usbhidDataTimeout!!
            ) ?: -1

            if (bytesWritten > 0) {
                Log.d(TAG, "Application started and firmware deleted successfully")
                true
            } else {
                Log.d(TAG, "Failed to start application and delete firmware")
                false
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error starting application and deleting firmware", e)
            false
        }
    }

    /**
     * Wait for installation completion
     */
    private fun waitForInstallation(timeoutMs: Int): Boolean {
        try {
            Log.d(TAG, "Waiting for installation completion...")

            val startTime = System.currentTimeMillis()

            while (System.currentTimeMillis() - startTime < timeoutMs) {
                val response = ByteArray(PACKET_LENGTH)
                val bytesRead =
                    usbConnection?.bulkTransfer(usbEndpointIn, response, response.size, 1000) ?: -1

                if (bytesRead > 0) {
                    val status = parseInstallationResponse(response)
                    when (status) {
                        InstallationStatus.COMPLETE -> {
                            Log.d(TAG, "Installation completed successfully")
                            return true
                        }

                        InstallationStatus.ERROR -> {
                            Log.d(TAG, "Installation failed")
                            return false
                        }

                        InstallationStatus.IN_PROGRESS -> {
                            Log.d(TAG, "Installation in progress...")
                            continue
                        }
                    }
                }

                Thread.sleep(100)
            }

            Log.d(TAG, "Installation timeout")
            return false

        } catch (e: Exception) {
            Log.e(TAG, "Error waiting for installation", e)
            return false
        }
    }

    /**
     * Parse installation response
     */
    private fun parseInstallationResponse(response: ByteArray): InstallationStatus {
        try {
            if (response.size >= 2) {
                val opcode = response[1].toInt() and 0xFF
                return when (opcode) {
                    INSTALLING_RESPONSE -> InstallationStatus.IN_PROGRESS
                    ACK -> InstallationStatus.COMPLETE
                    NACK -> InstallationStatus.ERROR
                    else -> InstallationStatus.IN_PROGRESS
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing installation response", e)
        }
        return InstallationStatus.ERROR
    }

    /**
     * Installation status enum
     */
    private enum class InstallationStatus {
        IN_PROGRESS, COMPLETE, ERROR
    }

    /**
     * Stop the firmware upgrade process
     */
    fun stop() {
        isStopped.set(true)
        scope.cancel()
    }

    /**
     * Cleanup resources
     */
    private fun cleanup() {
        try {
            usbConnection?.releaseInterface(usbInterface)
            usbConnection?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error during cleanup", e)
        }
    }

    /**
     * Calculate MD5 hash of firmware file
     */
    /*fun calculateFirmwareMD5(): String? {
        return try {
            val firmwareFile = File(firmwareData.filePath)
            if (!firmwareFile.exists()) {
                return null
            }

            val md = MessageDigest.getInstance("MD5")
            val digest = md.digest(firmwareFile.readBytes())

            digest.joinToString("") { "%02x".format(it) }

        } catch (e: Exception) {
            Log.e(TAG, "Error calculating firmware MD5", e)
            null
        }
    }*/

    /**
     * Get number of blocks in firmware
     */
    fun getNumberOfBlocks(): Int {
        return try {
            val firmwareFile = File(firmwareData?.filePath!!)
            if (!firmwareFile.exists()) {
                return 0
            }
            val firmwareSize = firmwareFile.length()
            return ((firmwareSize + PACKET_LENGTH - 1) / PACKET_LENGTH).toInt()
        } catch (e: Exception) {
            Log.e(TAG, "Error calculating number of blocks", e)
            0
        }
    }

    override fun upgrade(progressCallback: (Int) -> Unit, resetCallback: () -> Unit, onComplete: () -> Unit, isUpgradeBoot: Boolean): Boolean {
        try {
            isUpgradeDFW = true
            datalogicDevice.resetDeviceHID(context)
            Thread.sleep(3000)
            DeviceHidForFWU.startScanPidHID(1000, 10)
            repeat(5) {
                if (DeviceHidForFWU.usbConnection != null
                    && DeviceHidForFWU.usbInterface != null
                    && DeviceHidForFWU.usbEndpointIn != null
                ) {
                    setUsbConnection(
                        DeviceHidForFWU.usbConnection,
                        DeviceHidForFWU.usbInterface,
                        DeviceHidForFWU.usbEndpointIn,
                        DeviceHidForFWU.usbEndpointOut
                    )
                    return@repeat
                }
                Thread.sleep(200)
            }
            upgradeBlock(true, true, progressCallback, isUpgradeBoot)
            isUpgradeDFW = false
            try {
                DatalogicDeviceManager.onUsbListener?.onDeviceDetachedListener(datalogicDevice.usbDevice)
            } catch (_: Exception) {}
            when (completeStatus){
                RESTART -> resetCallback()
                FLASH_WR_END,WRITE_FLASH_OK -> onComplete()
            }
            return true
        } catch (e: Exception){
            throw e
        }
    }

    override fun upgradeByBulkTransfer(progressCallback: (Int) -> Unit): Boolean {
        return false
    }

    override fun isSupportedBulkTransfer(): Boolean {
        return false
    }

    override fun getPid(file: File?): String {
        return firmwareData.pid.toString()
    }

    override fun isCheckPid(serial: ServiceSerial): Boolean {
        if (datalogicDevice.deviceType == DeviceType.FRS) {
            handleTimeout(serial)
            val expectedPid = FRSScannerTypes.scannerTypeToPid[hwid]//1605
            if (expectedPid?.contains(firmwareData.pid) == true)
                return true
            if (expectedPid == null || !expectedPid.contains(firmwareData.pid)) {
                Log.d(TAG,"Compare PID => Expected PID: ${expectedPid?.contentToString()}, Received PID: ${firmwareData.pid}")
            }
        } else {
            serial.sendReceive("\$S\r".toByteArray(), 500, 200, true)
            val response = serial.sendReceiveString("\$yD\r".toByteArray())
            val receivedPid = response.removePrefix("\$>").trim().removeSuffix("\r")
            println("Compare PID => Expected PID: ${firmwareData.pid}, Received PID: ${response.substring(2)}")
            firmwareData.validPidCradle?.let { it ->
                for (pid in it){
                    val expectedPid = pid.removePrefix("0X").removePrefix("0x").uppercase()
                    if(receivedPid.equals(expectedPid, ignoreCase = true))
                        return true
                }
            }
            if(firmwareData.pid?.removePrefix("0X")?.removePrefix("0x")?.uppercase() == receivedPid)
                return true
        }
        return false
    }

    override fun isValidSWU(): Boolean {
        return false
    }

    override fun loadFirmwareFile(onCompleteLoading: (() -> Unit)?, progressCallback: ((Int) -> Unit)?): Boolean {
        if (firmwareData.protocol == PROTOCOL_1D11
            || firmwareData.protocol == PROTOCOL_1D12
        ) {
            totalPages = firmwareData.mApplicationPages.size + firmwareData.mBootPages.size
            var done = 0
            for (dfwIndex in 0 until totalPages) {
                var hex: String
                var page: FirmwarePage?
                if(dfwIndex < firmwareData.mApplicationPages.size){
                    hex = firmwareData.findHexFor(firmwareData.mApplicationPages[dfwIndex]).hex
                    page = firmwareData.mApplicationPages[dfwIndex]
                } else {
                    hex = firmwareData.findHexFor(firmwareData.mBootPages[dfwIndex - firmwareData.mApplicationPages.size]).hex
                    page = firmwareData.mBootPages[dfwIndex - firmwareData.mApplicationPages.size]
                }
                if (hex.isBlank()) continue
                // Avoid stale file reuse: always rewrite; switch to exists() if you want caching
                val file = File(context.cacheDir, "fw_block_${page.pid}_${page.id}.bin")
                if (file.exists()) file.delete()

                val baseAddr = page.offset.removePrefix("0x").toLongOrNull(16) ?: 0L
                intelHexToBinFile(hex.lineSequence(), file, baseAddr)
                if (file.length() > 0L) {
                    filesByAllPages += page to file
                    Log.d(TAG, "fw_block_${page.pid}_${page.id}")
                    Log.d(TAG, "filesByAllPages size: ${filesByAllPages.size}")
                }
                done += 1
                val percent = (done * 100 / totalPages).coerceAtMost(99)
                progressCallback?.invoke(percent)
            }
            Log.d(TAG, "Completed loading firmware file")
            onCompleteLoading?.invoke()
            return filesByAllPages.isNotEmpty()
        } else {
            onCompleteLoading?.invoke()
            return true
        }
    }

    /**
     * Send echo command to device
     */
    private fun sendEchoCommand(timeoutMs: Int): ByteArray? {
        try {
            // 1. Send the echo command (OUT)
            val requestTypeOut =
                UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
            val bytesWritten = usbConnection!!.controlTransfer(
                requestTypeOut, REQUEST_CODE, REQUEST_VALUE_FEATURE,
                usbInterface!!.id, ECHO, ECHO.size, timeoutMs
            )
            Log.d(TAG, "sendEchoCommand Bytes written: $bytesWritten")
            if (bytesWritten <= 0) return null

            // 2. Read the response (IN) using the interrupt IN endpoint
            Thread.sleep(10) // Optional: give device time to respond
            val responseBuffer = ByteArray(64)
            val bytesRead = usbConnection!!.bulkTransfer(
                usbEndpointIn, responseBuffer, responseBuffer.size, timeoutMs
            )
            Log.d(TAG, "sendEchoCommand Bytes read: $bytesRead")

            // 3. Return the response
            return if (bytesRead > 0) responseBuffer.copyOf(bytesRead) else null

        } catch (e: Exception) {
            Log.e(TAG, "Error sending echo command", e)
            return null
        }
    }

    /**
     * Extract PID from device response
     */
    private fun extractPidFromResponse(response: ByteArray): String? {
        try {
            if (response.size >= 4) {
                val pidBytes = response.sliceArray(1..2)
                return String.format("0x%02X%02X", pidBytes[0], pidBytes[1])
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting PID from response", e)
        }
        return null
    }

    /**
     * Join device for firmware upgrade
     */
    private fun joinDevice(): Boolean {
        try {
            Log.d(TAG, "Joining device for firmware upgrade...")

            if (pidHID == null) {
                Log.d(TAG, "No HID PID available")
                return false
            }

            // Check PID compatibility if required
            /*if (firmwareData?.checkPid == true) {
                if (!isPidCompatible(pidHID!!)) {
                    val message = "Incompatible PID: $pidHID"
                    Log.d(TAG, message)
                    return false
                }
            }*/

            // Send join command
            firmwareData?.usbhidJoinAttempt?.let {
                repeat(it) { attempt ->

                    val joinResponse = sendJoinCommand(firmwareData?.usbhidJoinTimeout!!)
                    if (joinResponse != null) {
                        val status = parseJoinResponse(joinResponse)
                        when (status) {
                            JoinStatus.ACK -> {
                                Log.d(TAG, "Device joined successfully")
                                return true
                            }

                            JoinStatus.RESTART -> {
                                Log.d(TAG, "Device restarting, waiting...")
                                Thread.sleep(2000) // Wait for restart
                                /*DatalogicDeviceManager.deviceAttachLatch = CountDownLatch(1)
                                Log.d(TAG, "[joinDeviceExtended] Waiting for device to re-attach...")
                                try {
                                    Thread.sleep(10000)
                                    Log.d(
                                        TAG,
                                        "[joinDeviceExtended] Device re-attached successfully."
                                    )
                                    handleRestart()
                                    usbConnection?.let {
                                        joinDeviceExtended()
                                    }
                                } finally {
                                    // Clean up the latch
                                    DatalogicDeviceManager.deviceAttachLatch = null
                                }*/
                                if(firmwareData.protocol == PROTOCOL_1D10){
                                    handleRestartJoin()
                                } else {
                                    handleRestart()
                                }
                            }

                            JoinStatus.NACK -> {
                                Log.d(TAG, "Device rejected join request")
                                return false
                            }

                            JoinStatus.ERROR -> {
                                Log.d(TAG, "Error during join")
                                return false
                            }
                        }
                    }

                    Thread.sleep(firmwareData?.usbhidJoinTimeout!!.toLong())
                }
            }

            Log.d(TAG, "Failed to join device after ${firmwareData?.usbhidJoinAttempt} attempts")
            return false

        } catch (e: Exception) {
            Log.e(TAG, "Error joining device", e)
            return false
        }
    }

    private fun handleRestartJoin(){
        handleRestart()
        usbConnection?.let {
            joinDevice()
        }
    }
    /**
     * Check if PID is compatible with firmware
     */
    private fun isPidCompatible(devicePid: String): Boolean {
        if (firmwareData?.byCradle!!) {
            return firmwareData?.validPidCradle!!.any { validPid ->
                isPidMatch(devicePid, validPid)
            }
        } else {
            return isPidMatch(devicePid, firmwareData?.pid!!)
        }
    }

    /**
     * Check if two PIDs match (with wildcard support)
     */
    private fun isPidMatch(devicePid: String, firmwarePid: String): Boolean {
        return devicePid.equals(firmwarePid, ignoreCase = true)
    }

    /**
     * Send join command to device
     */
    private fun sendJoinCommand(timeoutMs: Int): ByteArray? {
        try {
            val joinCommand = JOIN.clone()
            // Set PID in join command
            Log.d(TAG, "sendJoinCommand: pidHID: ${pidHID}")
            Log.d(TAG, "sendJoinCommand: fwData.pid: ${firmwareData.pid}")
            val pidBytes = firmwareData.pid?.removePrefix("0x")?.chunked(2)
            if (pidBytes?.size!! >= 2) {
                joinCommand[2] = pidBytes[0].toInt(16).toByte()
                joinCommand[3] = pidBytes[1].toInt(16).toByte()
            }
            Log.d(TAG, "sendJoinCommand: pidBytes: ${pidBytes.joinToString(" ")}")
            Log.d(TAG, "sendJoinCommand: Join command: ${joinCommand.joinToString(" ")}")
            var bytesWritten = -1
            /*if (usbEndpointOut != null) {
                // Use bulkTransfer for OUT endpoint
                Log.d(TAG, "sendJoinCommand: Using bulkTransfer for OUT endpoint")
                bytesWritten = usbConnection?.bulkTransfer(
                    usbEndpointOut,
                    joinCommand,
                    joinCommand.size,
                    10000
                ) ?: -1
            } else {*/
            // Use controlTransfer for OUT if OUT endpoint is missing
            Log.d(TAG, "sendJoinCommand: Using controlTransfer for OUT (no OUT endpoint)")
            val requestTypeOut =
                UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
            bytesWritten = usbConnection?.controlTransfer(
                requestTypeOut, REQUEST_CODE, REQUEST_VALUE_FEATURE,
                usbInterface!!.id, joinCommand, joinCommand.size, timeoutMs
            ) ?: -1
            //}
            Log.d(TAG, "sendJoinCommand Bytes written: $bytesWritten")
            if (bytesWritten <= 0) return null

            // Read the response using bulkTransfer on IN endpoint
            Thread.sleep(10) // Optional: give device time to respond
            val response = ByteArray(64)
            val bytesRead =
                usbConnection?.bulkTransfer(usbEndpointIn, response, response.size, timeoutMs) ?: -1
            Log.d(TAG, "sendJoinCommand Bytes read: $bytesRead")
            if (bytesRead > 0) {
                Log.d(TAG, "sendJoinCommand Response: ${response.joinToString(" ")}")
                return response.copyOf(bytesRead)
            }
            return null
        } catch (e: Exception) {
            Log.e(TAG, "Error sending join command", e)
            return null
        }
    }

    /**
     * Parse join response
     */
    private fun parseJoinResponse(response: ByteArray): JoinStatus {
        try {
            if (response.size >= 3) {
                val opcode = response[1].toInt() and 0xFF
                return when (opcode) {
                    ACK -> JoinStatus.ACK
                    NACK -> JoinStatus.NACK
                    RESTART_RESPONSE -> JoinStatus.RESTART
                    else -> JoinStatus.ERROR
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing join response", e)
        }
        return JoinStatus.ERROR
    }

    /**
     * Join status enum
     */
    private enum class JoinStatus {
        ACK, NACK, RESTART, ERROR
    }

    /**
     * Send firmware block to device
     */
    private fun sendFirmwareBlock(
        blockNumber: Int, blockData: ByteArray
    ): Int {
        try {
            repeat(firmwareData?.usbhidDataAttempt!!) { attempt ->
                var bytesWritten = -1
                val requestTypeOut =
                    UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
                val chunkSize = 64
                var offset = 0
                Log.d(
                    TAG,
                    "controlTransfer params: requestCode=$requestTypeOut, requestValue=$REQUEST_VALUE_OUT, index=${usbInterface!!.id}"
                )
                bytesWritten = usbConnection?.controlTransfer(
                    requestTypeOut,
                    REQUEST_CODE,
                    REQUEST_VALUE_OUT,
                    usbInterface!!.id,
                    blockData,
                    blockData.size,
                    firmwareData?.usbhidDataTimeout!!
                ) ?: -1
                if (bytesWritten < 0) {
                    Log.e(TAG, "controlTransfer failed at offset $offset")
                }
                val data = blockData.joinToString(" ") { String.format("%02X", it) }
                Log.d(
                    TAG,
                    "send block data: $data /n sendFirmwareBlock Bytes written (controlTransfer): $bytesWritten"
                )

                if (bytesWritten > 0) {
                    Log.d(
                        TAG,
                        "sendFirmwareBlock Bytes written (controlTransfer) bytesWritten: $bytesWritten"
                    )
                }
            }
            return RESULT_TIMEOUT

        } catch (e: Exception) {
            Log.e(TAG, "Error sending firmware block $blockNumber", e)
            return RESULT_TIMEOUT
        }
    }

    /**
     * Send firmware block to device
     */
    private fun sendFirmwareBlock(
        blockNumber: Int, blockData: ByteArray,
        address: String
    ): Int {
        val etxString = SmartUtil.byteArrayToHexString(DeviceFrame.etxBytes)
        val ackString = SmartUtil.byteArrayToHexString(DeviceFrame.ackBytes)
        val nakString = SmartUtil.byteArrayToHexString(DeviceFrame.nakBytes)

        var result = RESULT_TIMEOUT
        var cnt = 0
        var iNAK = 0
        try {
            repeat(firmwareData?.usbhidDataAttempt!!) { attempt ->
                var bytesWritten = -1
                // --- DEBUG: Log block data and controlTransfer params ---
                Log.d(
                    TAG,
                    "Block $blockNumber first 8 bytes: ${
                        blockData.take(8).joinToString(" ") { String.format("%02X", it) }
                    }"
                )
                // TODO: Check if device expects different request code/value for data blocks
                // Alternative parameters to try:
                // - requestCode: 0x09 (SET_REPORT), 0x0A (GET_REPORT), 0x20-0xFF (vendor-specific)
                // - requestValue: 0x0200 (report ID), 0x0000, or vendor-specific value
                // - index: interface number, 0, or vendor-specific
                val requestTypeOut =
                    UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
                Log.d(
                    TAG,
                    "controlTransfer params: requestCode=$requestTypeOut, requestValue=$REQUEST_VALUE_OUT, index=${usbInterface!!.id}"
                )
                val dataSend = SmartUtil.byteArrayToHexString(blockData)
                val len = dataSend?.length?.div(2)
                var lenS = len?.let { Integer.toHexString(it).uppercase() }
                    ?.let { SmartUtil.bigEndian(it) }
                lenS = lenS?.padEnd(4, '0')
                val frame = StringBuilder(2057)
                    .append("456B")
                    .append(lenS)
                    .append(address)
                    .append(blockData.joinToString(" ") {
                        String.format(
                            "%02X",
                            it
                        )
                    })
                    .append("0D")

                val targetSize = 2057

                // Clean the hex first (remove spaces/newlines) and ensure even nibble count
                val cleanHex = frame.toString().replace("\\s".toRegex(), "")
                val evenHex = if (cleanHex.length % 2 == 1) cleanHex + "0" else cleanHex

                val bytes = SmartUtil.hexStringToByteArray(evenHex)

                // Ensure size == 2057: if shorter, zero-pad; if longer, handle as you prefer
                val message: ByteArray = when {
                    bytes.size == targetSize -> bytes
                    bytes.size  < targetSize -> bytes.copyOf(targetSize)   // pads trailing 0x00
                    else -> {
                        // choose: truncate or error — uncomment one:
                        // bytes.copyOf(targetSize) // TRUNCATE
                        error("Frame is ${bytes.size} bytes; exceeds $targetSize.")
                    }
                }

                Log.d(
                    TAG,
                    "sendFirmwareBlock controlTransfer message: ${
                        message.joinToString(" ") {
                            String.format(
                                "%02X",
                                it
                            )
                        }
                    }"
                )
                /**/
                if(usbEndpointOut != null){
                    Log.d(TAG, "sendFirmwareBlock: Using bulk transfer for OUT (have OUT endpoint)")
                    bytesWritten = usbConnection?.bulkTransfer(
                        usbEndpointOut,
                        message,
                        message.size,
                        firmwareData?.usbhidDataTimeout!!
                    ) ?: -1
                } else {
                    Log.d(TAG, "sendFirmwareBlock: Using controlTransfer for OUT (no OUT endpoint)")
                    bytesWritten = usbConnection?.controlTransfer(
                        requestTypeOut,
                        REQUEST_CODE,
                        REQUEST_VALUE_OUT,
                        usbInterface!!.id,
                        message,
                        message.size,
                        firmwareData?.usbhidDataTimeout!!
                    ) ?: -1
                }
                if (bytesWritten < 0) {
                    Log.e(TAG, "controlTransfer failed at offset $bytesWritten")
                    throw Exception("Error sending firmware block $bytesWritten")
                }
                val data = blockData.joinToString(" ") { String.format("%02X", it) }
                Log.d(
                    TAG,
                    "send block data: $data /n sendFirmwareBlock Bytes written (controlTransfer): $bytesWritten"
                )

                if (bytesWritten > 0) {
                    Log.d(
                        TAG,
                        "sendFirmwareBlock Bytes written (controlTransfer) bytesWritten: $bytesWritten"
                    )
                    val startTime = System.currentTimeMillis()
                    while (System.currentTimeMillis() - startTime < firmwareData.usbhidDataTimeout) {
                        val remaining =
                            firmwareData.usbhidDataTimeout - (System.currentTimeMillis() - startTime)
                        Log.d(TAG, "[sendData] read[$cnt] in $remaining (ms)")

                        val res = readDataAsString(remaining.toInt())
                        if (!res.isNullOrBlank()) {
                            val response = res.uppercase()
                            Log.d(TAG, "[sendData] recv[$cnt]: $response")

                            if (result == RESULT_ETX) {
                                when {
                                    ackString?.let { response.contains(it) } == true -> return RESULT_ACK
                                    nakString?.let { response.contains(it) } == true -> if (++iNAK > 2) return RESULT_NACK
                                }
                            } else {
                                when {
                                    response.contains(etxString + ackString) -> return RESULT_ACK
                                    response.contains(etxString + nakString) -> if (++iNAK > 2) return RESULT_NACK
                                    etxString?.let { response.contains(it) } == true -> result =
                                        RESULT_ETX
                                }
                            }
                        } else {
                            Log.d(TAG, "[sendData] recv[$cnt]: TIMEOUT")
                        }
                    }
                }
            }
            return RESULT_TIMEOUT

        } catch (e: Exception) {
            Log.e(TAG, "Error sending firmware block $blockNumber", e)
            throw e
        }
    }

    /**
     * Parse acknowledgment response
     */
    private fun parseAckResponse(response: ByteArray): AckStatus {
        try {
            if (response.size >= 2) {
                val opcode = response[1].toInt() and 0xFF
                return when (opcode) {
                    ACK -> AckStatus.ACK
                    NACK -> AckStatus.NACK
                    else -> AckStatus.ERROR
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing ACK response", e)
        }
        return AckStatus.ERROR
    }

    /**
     * Acknowledgment status enum
     */
    private enum class AckStatus {
        ACK, NACK, ERROR
    }

    /**
     * Send end command to device
     */
    private fun sendEndCommand(): Boolean {
        try {
            repeat(firmwareData.usbhidEndAttempt) { attempt ->
                Log.d(TAG, "sendEndCommand: Using controlTransfer for OUT (no OUT endpoint)")
                val requestTypeOut =
                    UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
                val bytesWritten = usbConnection?.controlTransfer(
                    requestTypeOut, REQUEST_CODE, REQUEST_VALUE_OUT,
                    usbInterface!!.id, END, END.size, firmwareData.usbhidEndTimeout
                ) ?: -1
                if (bytesWritten > 0) {
                    return true
                }
                // 2. Read the response (IN) using the interrupt IN endpoint
                Thread.sleep(10) // Optional: give device time to respond
                val responseBuffer = ByteArray(64)
                val bytesRead = usbConnection!!.bulkTransfer(
                    usbEndpointIn,
                    responseBuffer,
                    responseBuffer.size,
                    firmwareData.usbhidEndTimeout
                )
                Log.d(TAG, "sendEndCommand Bytes read: $bytesRead")

                Thread.sleep(firmwareData.usbhidEndTimeout.toLong())
            }

            Log.e(TAG, "Failed to send end command after ${firmwareData.usbhidEndAttempt} attempts")
            return false

        } catch (e: Exception) {
            Log.e(TAG, "Error sending end command", e)
            return false
        }
    }

    /**
     * Parse end response
     */
    private fun parseEndResponse(response: ByteArray): EndStatus {
        try {
            if (response.size >= 2) {
                val opcode = response[1].toInt() and 0xFF
                return when (opcode) {
                    ACK -> EndStatus.SUCCESS
                    else -> EndStatus.ERROR
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing end response", e)
        }
        return EndStatus.ERROR
    }

    /**
     * End status enum
     */
    private enum class EndStatus {
        SUCCESS, ERROR
    }

    /**
     * Join device using block-based protocol
     * This is equivalent to the Java joinBlock function
     */
    fun joinBlock(id: String, timeoutMs: Int, attempts: Int): String? {
        try {
            if (usbConnection == null) {
                Log.e(TAG, "[joinBlock] ERROR: usbConnection is null")
                return null
            }

            // Ensure device is open
            if (usbEndpointIn == null) {
                Log.e(TAG, "[joinBlock] ERROR: USB endpoints not available")
                return null
            }

            // Remove 0x prefix if present
            val cleanId = if (id.startsWith("0x")) id.substring(2) else id

            Log.d(TAG, "[joinBlock] id string: $cleanId")

            // Create join block command with ID
            val joinBlockCommand = JOIN_BLOCK.clone()
            if (cleanId.length >= 2) {
                joinBlockCommand[2] = cleanId.substring(0, 2).toInt(16).toByte()
            }

            repeat(attempts) { attempt ->
                if (isStopped.get()) {
                    Log.d(TAG, "[joinBlock] STOP by user")
                    return null
                }

                Log.d(
                    TAG,
                    "[joinBlock] send[$attempt]: ${
                        joinBlockCommand.joinToString(", ") {
                            "0x%02X".format(it)
                        }
                    }"
                )
                var bytesWritten = -1
                /*if (usbEndpointOut != null) {
                    // Use bulkTransfer for OUT endpoint
                    Log.d(TAG, "sendJoinCommand: Using bulkTransfer for OUT endpoint")
                    bytesWritten = usbConnection?.bulkTransfer(
                        usbEndpointOut,
                        joinBlockCommand,
                        joinBlockCommand.size,
                        10000
                    ) ?: -1
                } else {*/
                val requestTypeOut =
                    UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
                bytesWritten = usbConnection?.controlTransfer(
                    requestTypeOut, REQUEST_CODE, REQUEST_VALUE_FEATURE,
                    usbInterface!!.id, joinBlockCommand, joinBlockCommand.size, timeoutMs
                ) ?: -1
                //}
                if (bytesWritten > 0) {
                    val response = readDataAsString(timeoutMs)
                    Log.d(TAG, "[joinBlock] recv[$attempt]: $response")

                    if (!response.isNullOrEmpty()) {
                        Log.d(TAG, "[joinBlock] return: $response")
                        return response
                    }
                }

                Thread.sleep(timeoutMs.toLong())
            }

            Log.d(TAG, "[joinBlock] return: null")
            return null

        } catch (e: Exception) {
            Log.e(TAG, "Error in joinBlock", e)
            return null
        }
    }

    /**
     * Read data from device and return as hex string
     */
    private fun readDataAsString(timeoutMs: Int): String? {
        try {
            if (usbConnection == null) {
                Log.e(TAG, "[readDataAsString] ERROR: usbConnection is null")
                throw Exception("Error reading data")
            }

            if (usbEndpointIn == null) {
                Log.e(TAG, "[readDataAsString] ERROR: usbEndpointIn is null")
                throw Exception("Error reading data")
            }

            val data = ByteArray(64)
            val bytesRead =
                usbConnection?.bulkTransfer(usbEndpointIn, data, data.size, timeoutMs) ?: -1

            return when {
                bytesRead > 0 -> {
                    val hexString = data.take(bytesRead).joinToString("") { "%02X".format(it) }
                    Log.d(TAG, "[readDataAsString] $hexString")
                    hexString
                }

                bytesRead == 0 -> {
                    Log.d(TAG, "[readDataAsString] TIMEOUT")
                    throw Exception("Error reading data: $bytesRead")
                }

                else -> {
                    Log.e(TAG, "[readDataAsString] ERROR: $bytesRead")
                    throw Exception("Error reading data: $bytesRead")
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error reading data as string", e)
            throw e
        }
    }

    /**
     * Send host end command (block-based protocol)
     * This is equivalent to the Java host_end function
     */
    private fun hostEnd(timeoutMs: Int, attempts: Int): String? {
        try {
            Log.d(TAG, "[host_end] TIMEOUT = $timeoutMs (ms); ATTEMPT = $attempts")

            repeat(attempts) { attempt ->
                Log.d(
                    TAG,
                    "[host_end] send[$attempt]: ${END.joinToString(", ") { "0x%02X".format(it) }}"
                )
                val requestTypeOut =
                    UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
                val bytesWritten = usbConnection?.controlTransfer(
                    requestTypeOut, REQUEST_CODE, REQUEST_VALUE_FEATURE,
                    usbInterface!!.id, END, END.size, firmwareData.usbhidEndTimeout
                ) ?: -1
                Log.d(TAG, "hostEnd Bytes written: $bytesWritten")

                if (bytesWritten > 0) {
                    val data = ByteArray(64)
                    val bytesRead =
                        usbConnection?.bulkTransfer(usbEndpointIn, data, data.size, timeoutMs) ?: -1
                    return when {
                        bytesRead > 0 -> {
                            val hexString =
                                data.take(bytesRead).joinToString("") { "%02X".format(it) }
                            Log.d(TAG, "[readDataAsString] $hexString")
                            hexString
                        }

                        bytesRead == 0 -> {
                            Log.d(TAG, "[readDataAsString] TIMEOUT")
                            null
                        }

                        else -> {
                            Log.e(TAG, "[readDataAsString] ERROR: $bytesRead")
                            null
                        }
                    }
                }
                Thread.sleep(500)
            }
            return ""
        } catch (e: Exception) {
            Log.e(TAG, "Error in hostEnd", e)
            return ""
        }
    }

    /**
     * Get version ID for specific PID (block-based protocol)
     * This is equivalent to the Java getVersionIdPid function
     */
    private fun getVersionIdPid(id: String, timeoutMs: Int, attempts: Int): ByteArray? {
        try {
            Log.d(TAG, "[getVersionIdPid] id: $id")
            if (usbConnection == null) {
                Log.e(TAG, "[getVersionIdPid] ERROR: usbConnection is null")
                return null
            }

            if (usbEndpointIn == null) {
                Log.e(TAG, "[getVersionIdPid] ERROR: USB endpoints not available")
                return null
            }

            // Remove 0x prefix if present
            val cleanId = if (id.startsWith("0x")) id.substring(2) else id

            // Create version command with ID
            val versionCommand = VERSION.clone()
            if (cleanId.length >= 2) {
                versionCommand[2] = cleanId.substring(0, 2).toInt(16).toByte()
            }

            Log.d(TAG, "[getVersionIdPid] TIMEOUT = $timeoutMs (ms); ATTEMPT = $attempts")

            repeat(attempts) { attempt ->
                if (isStopped.get()) {
                    Log.d(TAG, "[getVersionIdPid] STOP by user")
                    return null
                }

                Log.d(
                    TAG,
                    "[getVersionIdPid] send[$attempt]: ${
                        versionCommand.joinToString(", ") {
                            "0x%02X".format(it)
                        }
                    }"
                )

                val requestTypeOut =
                    UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
                val bytesWritten = usbConnection?.controlTransfer(
                    requestTypeOut,
                    REQUEST_CODE,
                    REQUEST_VALUE_FEATURE,
                    usbInterface!!.id,
                    versionCommand,
                    versionCommand.size,
                    firmwareData.usbhidEndTimeout
                ) ?: -1
                Log.d(TAG, "getVersionIdPid: $bytesWritten")

                if (bytesWritten > 0) {
                    val data = ByteArray(64)
                    val bytesRead =
                        usbConnection?.bulkTransfer(usbEndpointIn, data, data.size, timeoutMs) ?: -1
                    val result = data.joinToString(", ") {
                        "0x%02X".format(it)
                    }
                    if (bytesRead > 0) {
                        Log.d(TAG, "[getVersionIdPid] recv[]: $result")
                        return data
                    } else {
                        Log.d(TAG, "[getVersionIdPid] recv[] - ERROR:")
                    }
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error in getVersionIdPid", e)
        }
        return null
    }


    @Throws(Exception::class)
    fun waitInstallation1D11(): Boolean {
        Log.d(TAG, "upgradeLinearHID_1D11 waitInstallation1D11")
        val FLASH_WR_START = FLASH_WRITE_START.toString(16)
        val INSTALLING = INSTALLING_RESPONSE.toString(16)

        var deviceAnswer: String
        var opcode: String
        var isSuccess = true
        var bStop = false

        while (!bStop) {
            deviceAnswer =
                hostEnd(firmwareData.usbhidEndTimeout, firmwareData.usbhidEndAttempt).toString()
            opcode = if (deviceAnswer.isNotEmpty()) {
                deviceAnswer.substring(2, 4)
            } else {
                Log.d(TAG, "No response from device, stopping.")
                return false
            }

            Log.d(TAG, "[waitInstallation1D11] answer: 0x$opcode")

            when (opcode) {
                FLASH_WR_START -> {
                    Log.d(TAG, "[waitInstallation1D11] phase: FLASH_WR_START ...")
                }

                INSTALLING -> {
                    val percentCompleted = deviceAnswer.substring(4, 6).toInt(16)
                    Log.d(TAG, "[waitInstallation1D11] INSTALLING... progress: $percentCompleted%")
                }

                RESTART -> {
                    Log.d(TAG, "[waitInstallation1D11] RESTART")
                    handleRestart()
                    completeStatus = RESTART
                }

                FLASH_WR_END -> {
                    Log.d(TAG, "[waitInstallation1D11] Upgrade Completed!")
                    bStop = true
                    completeStatus = FLASH_WR_END
                }

                else -> {
                    val msg = "Installation failed, stopping."
                    Log.d(TAG, msg)
                    isSuccess = false
                    bStop = true
                }
            }
        }
        return isSuccess
    }

    private fun handleRestart(){
        Thread.sleep(500)
        val tempResult = DeviceHidForFWU.detectHIDDeviceWithTimeout(context, 60, 1000)
        DeviceHidForFWU.startScanPidHID(1000, 10)
        repeat(5) {
            if (DeviceHidForFWU.usbConnection != null
                && DeviceHidForFWU.usbInterface != null
                && DeviceHidForFWU.usbEndpointIn != null
            ) {
                setUsbConnection(
                    DeviceHidForFWU.usbConnection,
                    DeviceHidForFWU.usbInterface,
                    DeviceHidForFWU.usbEndpointIn,
                    DeviceHidForFWU.usbEndpointOut
                )
            }
            Thread.sleep(200)
        }
    }

    private fun upgradeBlock(usb: Boolean, ethernet: Boolean, progressCallback: (Int) -> Unit, isUpgradeBoot: Boolean) {
        Log.d(TAG, "upgradeBlock")
        try {
            when (firmwareData.protocol) {
                PROTOCOL_1D10, PROTOCOL_1D101 -> {
                    if (firmwareData.protocol!!.startsWith("1D")) {
                        if (usb) {
                            upgradeLinearHID(progressCallback, isUpgradeBoot)
                        } else {
                            upgradeLinear(ethernet, progressCallback, isUpgradeBoot)
                        }
                    } else {
                        //upgrade2D()
                        false
                    }
                }

                PROTOCOL_1D11, PROTOCOL_1D12 -> {
                    validateFirmwarePages1D11()
                    if (usb) {
                        upgradeLinearHID_1D11(progressCallback, isUpgradeBoot)
                    } else {
                        upgradeLinear_1D11(progressCallback, isUpgradeBoot)
                    }
                }

                else -> {
                    Log.d(
                        TAG,
                        "Protocol ${firmwareData.protocol} is under construction."
                    )
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error in checking the protocol: ${e.message}")
        }
    }

    private fun upgradeLinear_1D11(progressCallback: (Int) -> Unit, isUpgradeBoot: Boolean): Boolean {
        try {
            Log.d(TAG, "start upgradeLinear 1.1: $firmwareData")
            print("start upgradeLinear 1.1: $firmwareData")

            joinDeviceExtended()
            upgradeLinearDownload(progressCallback, isUpgradeBoot)

            waitInstallation1D11()

            return true

        } catch (x: Exception) {
            Log.d(TAG, "upgradeLinear_1D11 ${x.message} ?: \"Unknown error\"")
            x.printStackTrace()
        }

        return false
    }

    private fun upgradeLinearHID_1D11(progressCallback: (Int) -> Unit, isUpgradeBoot: Boolean): Boolean {
        try {
            // progressMonitor = ProgressUtil.createModalProgressMonitor(jFrameMain, true, false)
            joinDeviceExtended()

            // upgradeLinearDownload includes the management of the firmware sending with the new protocol protocol="1D-1.1"
            upgradeLinearDownload(progressCallback, isUpgradeBoot)

            // progressMonitor = ProgressUtil.createModalProgressMonitor(jFrameMain, true, false)
            Log.d(TAG, "upgradeLinearHID_1D11 UPGRADE_LOAD_WAIT_FLASH_WRITE")

            // installation phase
            waitInstallation1D11()
            return false
        } catch (x: Exception) {
            Log.d(TAG, "${x.message} ?: \"Unknown error\"")
            x.printStackTrace()
        }
        return false
    }

    @Throws(Exception::class)
    fun joinDeviceExtended() {
        var ok = true

        // Join host to desk, cradle or gun mobile.
        joinDevice()

        val fwCtrl = FirmwareVersionController(firmwareData)
        if (!fwCtrl.checkPages()) {
            ok = false
            Log.d(
                TAG,
                "[joinDeviceExtended] Invalid DFW Pages. Multiple version strings for given (ComponentID, ProductID) tuple."
            )
        }
        var restart = false
        Log.d(
            TAG,
            "[joinDeviceExtended] fwCtrl.numberOfFirmwarePages(): ${fwCtrl.numberOfFirmwarePages()}"
        )
        Log.d(
            TAG,
            "[joinDeviceExtended] firmwareData.mApplicationPages.size: ${firmwareData.mApplicationPages.size + firmwareData.mBootPages.size}"
        )
        var index = 0
        while (index < totalPages && ok) {
            var fp: FirmwarePage?
            if(index < firmwareData.mApplicationPages.size){
                fp = firmwareData.mApplicationPages[index]
            } else {
                fp = firmwareData.mBootPages[index - firmwareData.mApplicationPages.size]
            }
            Log.d(TAG, "[joinDeviceExtended] fp($index): $fp")
            Log.d(TAG, "[joinDeviceExtended] fpage[$index], pid:${fp.pid}, id:${fp.id}, fp.isSelected: ${fp.isSelected}")

            if (fp == null) {
                Log.d(TAG, "[joinDeviceExtended] fp not available.")
                ok = false
                continue
            }

            if (fp.processed) {
                Log.d(
                    TAG,
                    "[joinDeviceExtended] fp[${fp.index}] id:${fp.id} . Id already processed."
                )
                continue
            }

            if (fp.isSelected) {
                val answer = joinBlock(fp)
                when (answer.opcode) {
                    CAnswer.RESTART -> {
                        Log.d(TAG, "[joinDeviceExtended] JOIN_BLOCK answer = RESTART")

                        val b1 = answer.field.substring(0, 2)
                        val b2 = answer.field.substring(2, 4)
                        val iDelayTime = (b1.toInt(16) shl 8) + b2.toInt(16)

                        Log.d(TAG, "[joinDeviceExtended] discovery device in $iDelayTime ms.")

                        // Use CountDownLatch to wait for device re-attachment
                        DatalogicDeviceManager.deviceAttachLatch = CountDownLatch(1)
                        Log.d(TAG, "[joinDeviceExtended] Waiting for device to re-attach...")

                        try {
                            // Wait for the device to re-attach, with a timeout
                            val awaitResult = DatalogicDeviceManager.deviceAttachLatch?.await(
                                iDelayTime + 5000L, TimeUnit.MILLISECONDS
                            )
                            if (awaitResult == true) {
                                Log.d(TAG, "[joinDeviceExtended] Device re-attached successfully.")
                                handleRestartJoin()
                            } else {
                                Log.e(
                                    TAG,
                                    "[joinDeviceExtended] Timed out waiting for device to re-attach."
                                )
                                ok = false
                                continue // Exit the loop
                            }
                        } finally {
                            // Clean up the latch
                            DatalogicDeviceManager.deviceAttachLatch = null
                        }
                        fwCtrl.resetPages()
                        restart = true
                    }

                    CAnswer.ACK -> {
                        Log.d(TAG, "[joinDeviceExtended] JOIN_BLOCK answer = ACK")
                        val rxBytes: ByteArray? = when (firmwareData.protocol) {
                            PROTOCOL_1D11 -> getVersionIdPid(
                                fp.id,
                                firmwareData.usbhidVersionTimeout,
                                firmwareData.usbhidVersionAttempt
                            )

                            PROTOCOL_1D12 -> getVersionIdPid12(
                                fp.id,
                                fp.blockVersion12,
                                firmwareData.usbhidVersionTimeout,
                                firmwareData.usbhidVersionAttempt
                            )

                            else -> {
                                ok = false
                                Log.d(TAG, "[joinDeviceExtended] version - wrong protocol.")
                                null
                            }
                        }

                        if (rxBytes == null) {
                            ok = false
                        } else {
                            val rxId = "0x%02x".format(rxBytes[2])
                            val rxPid = "0x%02x%02x".format(rxBytes[3], rxBytes[4])
                            var rxVersion = ""
                            try {
                                rxVersion = when (firmwareData.protocol) {
                                    PROTOCOL_1D11 -> {
                                        rxBytes.copyOfRange(5, 21).takeWhile { it != 0x00.toByte() }
                                            .joinToString("") { it.toInt().toChar().toString() }
                                    }

                                    PROTOCOL_1D12 -> {
                                        rxBytes.copyOfRange(7, rxBytes.size)
                                            .takeWhile { it != 0x00.toByte() }
                                            .joinToString("") { it.toInt().toChar().toString() }
                                    }

                                    else -> ""
                                }
                            } catch (e: IllegalFormatCodePointException) {
                                e.printStackTrace()
                                val tempCheck = rxBytes.copyOfRange(7, 23)
                                val ignoreCheck = ByteArray(16) { -1 }
                                if (tempCheck.contentEquals(ignoreCheck) && !firmwareData.versionControl) {
                                    "INVALID"
                                } else {
                                    throw e
                                }
                            }

                            Log.d(TAG, "[joinDeviceExtended] version - id:$rxId")
                            Log.d(TAG, "[joinDeviceExtended] version - pid:$rxPid")
                            Log.d(TAG, "[joinDeviceExtended] version - version:$rxVersion")
                            Log.d(TAG, "[joinDeviceExtended] version - SAP:${fp.sapNumber}")
                            val componentIdNum = Integer.decode(rxId)
                            val pageIdNum = Integer.decode(fp.id)
                            if (componentIdNum == pageIdNum) {
                                if (firmwareData.protocol == PROTOCOL_1D12) {
                                    val rxPidMask = "0x%02x%02x".format(rxBytes[5], rxBytes[6])
                                    Log.d(TAG, "[joinDeviceExtended] version - pid mask:$rxPidMask")
                                    fwCtrl.acceptPages12(rxId, rxPid, rxPidMask, rxVersion)
                                } else {
                                    fwCtrl.acceptPages(rxId, rxPid, rxVersion)
                                }
                            } else {
                                ok = false
                                Log.d(TAG, "[joinDeviceExtended] version - wrong id received.")
                            }
                        }
                    }

                    CAnswer.NACK -> {
                        Log.d(TAG, "[joinDeviceExtended] JOIN_BLOCK answer = NACK")
                        ok = false
                        fwCtrl.discardPages(fp.id)
                    }

                    CAnswer.SKIP -> {
                        Log.d(TAG, "[joinDeviceExtended] JOIN_BLOCK answer = SKIP")
                        fwCtrl.discardPages(fp.id)
                    }

                    CAnswer.FORCE -> {
                        Log.d(TAG, "[joinDeviceExtended] JOIN_BLOCK answer = FORCE")
                        // Try to read ID/PID/version exactly as in the ACK case
                        fwCtrl.acceptPages(fp.id)
                    }

                    else -> {
                        Log.d(TAG, "[joinDeviceExtended] JOIN_BLOCK answer = ERROR")
                    }
                }
            }

            if (!restart) {
                index++
            } else {
                index = 0
                restart = false
            }
        }
    }

    private fun validateFirmwarePages1D11(): Boolean {
        /*if (isDeveloperMode) {
            bCheckPid = upgradeConfigItems["configItem_checkPid_$id"]?.isInputElementChecked() ?: false
            firmwareData.versionControl = getElementCheck("inputFWUCheckVERSION_$id")
        } else {
            bCheckPid = true
            firmwareData.versionControl = true
        }*/

        firmwareData.checkPid = true
        firmwareData.upgradeFwViaRadio = false

        firmwareData.mApplicationPages.forEachIndexed { index, page ->
            page.checkPID = true
            page.isSelected = when {
                page.developerOnly.equals("true", ignoreCase = true) -> false
                else -> true
            }
        }

        firmwareData.mBootPages.forEachIndexed { index, page ->
            page.checkPID = true
            page.isSelected = when {
                page.developerOnly.equals("true", ignoreCase = true) && isUpgradeBoot -> true
                else -> false
            }
        }

        return true
    }

    private fun upgradeLinear(ethernet: Boolean, progressCallback: (Int) -> Unit, isUpgradeBoot: Boolean): Boolean {
        /*firmwareData.sendApplication = mIsAppUpgraded
        firmwareData.sendBoot = isBootUpgraded
        firmwareData.sendImageBin = isEthAppUpgraded
        firmwareData.sendBackupImageBin = isEthBackupUpgraded
        firmwareData.checkPid = bCheckPid*/
        var endSent = false

        Log.d(TAG, "start upgradeLinear: $firmwareData")

        try {
            //var pid = resetDevice(tabMonitor, skipAutodetect, withReset)

            joinDevice(ethernet)

            upgradeLinearDownload(progressCallback, isUpgradeBoot)

            Log.d(TAG, "UPGRADE_LOAD_WAIT_FLASH_WRITE")
            endSent = true

            //val result = waitInstallation1D10()
            return when ("0") {
                WRITE_FLASH_OK -> true
                WRITE_FLASH_STOP_BY_USER -> false
                WRITE_FLASH_TIMEOUT -> false
                else -> false
            }
        } catch (x: Exception) {
            if (!endSent) {
                try {
                    //waitInstallation1D10()
                } catch (ex: Exception) {
                    ex.printStackTrace()
                }
            }
            Log.d(TAG, "Error in upgradeLinear: ${x.message}")
            x.printStackTrace()
        }

        return false
    }

    @Throws(Exception::class)
    fun joinDevice(ethernet: Boolean) {
        Log.d(TAG, "debug: Begin joinDevice with check pid : ${firmwareData.checkPid}")

        if (!firmwareData.byCradle) {
            /*if (firmwareData.checkPid) {
                val devPid = DevicePid(pid)
                if (!devPid.isSupportedIn(fwData.pid, fwData.protocol)) {
                    stopUpgrade(monitor, "${LRes.getString("UPGRADE_ERROR_FIRMWARE_LABEL")} - ${LRes.getString("PID_LABEL")} $pid")
                }
            }*/
        } else {
            var ok = !firmwareData.checkPid
            /*val devPid = DevicePid(pid)
            for (validPid in fwData.validPidCradle) {
                if (devPid.isSupportedIn(validPid, fwData.protocol)) {
                    ok = true
                    break
                }
            }

            if (!ok) {
                stopUpgrade(monitor, "${LRes.getString("UPGRADE_INVALID_CRADLE_LABEL")} - ${LRes.getString("PID_LABEL")} $pid")
            }*/

            if (ethernet) {
                Thread.sleep(2000)
            }

            ok = false
            val startTime = System.currentTimeMillis()
            val timeout = 1000L * 60 * 60 // 1 hour

            while (System.currentTimeMillis() - startTime < timeout) {
                joinDevice()
            }
        }
    }

    private fun isLinear(): Boolean {
        return firmwareData.protocol == PROTOCOL_1D21
    }

    private fun upgradeLinearHID(progressCallback: (Int) -> Unit, isUpgradeBoot: Boolean): Boolean {
        return try {
            joinDevice()
            // firmware data upload
            // progressMonitor = ProgressUtil.createModalProgressMonitor(jFrameMain, numBlock + 1, false, 0, true, false)
            upgradeLinearDownload(progressCallback, isUpgradeBoot)
            // data installation
            waitInstallation1D10()
            true
        } catch (x: Exception) {
            Log.e(TAG, "upgradeLinearHID Error ${x.message}")
            x.printStackTrace()
            false
        }
    }

    fun upgradeLinearDownload(progressCallback: (Int) -> Unit, isUpgradeBoot: Boolean) {
        Log.d(TAG, "start upgradeLinearDownload")
        if (firmwareData.protocol == PROTOCOL_1D11
            || firmwareData.protocol == PROTOCOL_1D12
        ) {
            totalPages =
                if (isUpgradeBoot)
                    firmwareData.mApplicationPages.size + firmwareData.mBootPages.size
                else firmwareData.mApplicationPages.size
            Log.d(TAG, "totalPages: $totalPages")
            val sendPages = ArrayList<FirmwarePage>()

            for (dfwIndex in 0 until totalPages) {
                var fp: FirmwarePage? = null
                if(dfwIndex < firmwareData.mApplicationPages.size){
                    fp = firmwareData.mApplicationPages[dfwIndex]
                } else {
                    fp = firmwareData.mBootPages[dfwIndex - firmwareData.mApplicationPages.size]
                }
                Log.d(TAG, "upgradeLinearDownload fp: $fp")
                fp?.let {
                    Log.d(TAG, "upgradeLinearDownload fp.toBeUpgraded: ${fp.toBeUpgraded}" +
                            " fp.processed: ${fp.processed} fp.isSelected: ${fp.isSelected} fp.toBeUpgraded: ${fp.toBeUpgraded}")
                    var sendBlock = it.isSelected
                    if ((firmwareData.versionControl || firmwareData.checkPid) && sendBlock) {
                        if (it.processed) {
                            sendBlock = it.toBeUpgraded
                        }
                    }
                    Log.d(TAG, "upgradeLinearDownload fp: ${fp.id} sendBlock $sendBlock")
                    if (sendBlock) {
                        sendPages.add(it)
                        val blockName = "${it.labelBlock} (id: ${it.id}, pid: ${it.pid})"
                        val text = String.format(
                            "UPGRADE_OK_FIRMWARE_DEVELOPER_MODE_LABEL_PASS",
                            blockName
                        )
                        firmwareData.blockUpgradeFinalStatus.add(text)
                    } else if (it.isSelected) {
                        val blockName = "${it.labelBlock} (id: ${it.id}, pid: ${it.pid})"
                        val text = it.discardReason.ifEmpty {
                            String.format(
                                "UPGRADE_OK_FIRMWARE_DEVELOPER_MODE_LABEL_FAIL_APPLICATION_ERROR",
                                blockName
                            )
                        }
                        firmwareData.blockUpgradeFinalStatus.add(text)
                    } else {
                        Log.d(TAG, "upgradeLinearDownload fp: ${fp.id} sendBlock: $sendBlock")
                    }
                }
            }
            // 2) Build bin files once to compute a reliable total size
            Log.d(TAG, "upgradeLinearDownload filesByAllPages size: ${filesByAllPages.size}")
            Log.d(TAG, "upgradeLinearDownload sendPages size: ${sendPages.size}")
            var totalSize = 0L
            val filesByPage = mutableListOf<Pair<FirmwarePage, File>>()
            for (page in sendPages) {
                Log.d(TAG, "upgradeLinearDownload sendPages id: ${page.id}")
                filesByAllPages.firstOrNull { it.first == page }?.let {
                    filesByPage += it
                    totalSize += it.second.length()
                }
            }
            if (totalSize <= 0L || filesByPage.isEmpty()) {
                Log.d(
                    TAG,
                    "Nothing to send (totalSize=$totalSize, pages=${filesByPage.size})"
                )
                return
            }
            val global = GlobalProgress(totalSize, progressCallback)

            Log.d(TAG, "Total firmware size: $totalSize bytes")

            // 3) Stream pages sequentially
            var sent = 0L
            for ((page, binFile) in filesByPage) {
                Log.d(
                    TAG,
                    "Sending page label=${page.labelBlock}, id=${page.id}, pid=${page.pid}"
                )
                selectBlock(page)
                if(firmwareData.protocol == PROTOCOL_1D12) {
                    val fwCtrl = FirmwareVersionController(firmwareData)
                    var ok = true
                    val rxBytes = getVersionIdPid12(
                        page.id,
                        page.blockVersion12,
                        firmwareData.usbhidVersionTimeout,
                        firmwareData.usbhidVersionAttempt
                    )

                    if (rxBytes == null) {
                        ok = false
                    } else {
                        val rxId = String.format("0x%02x", rxBytes[2])
                        val rxPid = String.format("0x%02x%02x", rxBytes[3], rxBytes[4])
                        val rxPidMask = String.format("0x%02x%02x", rxBytes[5], rxBytes[6])
                        var rxVersion = ""

                        try {
                            for (i in 7 until 23) {
                                if (rxBytes[i] == 0x00.toByte()) break
                                rxVersion += String.format("%c", rxBytes[i])
                            }
                        } catch (e: IllegalFormatCodePointException) {
                            val tempCheck = rxBytes.copyOfRange(7, 23)
                            val ignoreCheck = ByteArray(16) { -1 }
                            if (tempCheck.contentEquals(ignoreCheck) && !firmwareData.versionControl) {
                                rxVersion = "INVALID"
                            } else {
                                throw e
                            }
                        }

                        Log.d(TAG, "[sendBlock] version - id:$rxId")
                        Log.d(TAG, "[sendBlock] version - pid:$rxPid")
                        Log.d(TAG, "[sendBlock] version - pid mask:$rxPidMask")
                        Log.d(TAG, "[sendBlock] version - version:$rxVersion")
                        Log.d(TAG, "[sendBlock] version - SAP:${page.sapNumber}")

                        if (!page.id.equals(rxId, ignoreCase = true)) {
                            ok = false
                            Log.d(TAG, "[sendBlock] version - wrong id received.")
                        }
                    }

                    if (!ok) {
                        continue
                    }
                }
                val blockSize = firmwareData.pktSize
                val baseAddrStr = page.offset.removePrefix("0x")
                sendFirmwareFromFile(
                    binFile,
                    blockSize,
                    baseAddrStr
                ) { blockIdx, data, addr ->
                    // Compute absolute address for this block
                    val base = addr.removePrefix("0x").toLongOrNull(16) ?: 0L
                    val absolute = base + blockIdx.toLong() * blockSize.toLong()
                    val padded = String.format(Locale.US, "%08X", absolute)
                    val blockAddress =
                        SmartUtil.bigEndian(padded) // verify endianness vs spec!

                    sendFirmwareBlock(blockIdx, data, blockAddress)

                    sent += data.size
                    global.add(data.size.toLong())

                    true // continue
                }

                // Clean up
                binFile.delete()
            }

            // Make sure we end at 100%
            //progressCallback(100)
        } else {
            upgradeFirmware(firmwareData, isUpgradeBoot, progressCallback)
        }
    }

    class GlobalProgress(
        private val totalBytes: Long,
        private val cb: (Int) -> Unit
    ) {
        private val sent = AtomicLong(0)
        private val lastPct = AtomicInteger(-1) // nothing emitted yet

        fun add(bytes: Long) {
            if (totalBytes <= 0L) return

            val now = sent.addAndGet(bytes.coerceAtLeast(0))
            val pct = ((now * 100L) / totalBytes).coerceIn(0L, 100L).toInt()

            val prev = lastPct.getAndUpdate { old -> max(old, pct) }
            if (pct > prev) cb(pct)
        }
    }

    @Throws(Exception::class)
    fun sendVersion101(blockVersion: String, xtimeout: Int, iattempt: Int): String? {
        for (i in blockVersion.indices) {
            val index = 3 + i
            VERSION101[index] = (48 + blockVersion.substring(i, i + 1).toInt()).toByte()
        }

        var cnt = 0
        Log.d(TAG, "[block_version] TIMEOUT = $xtimeout (ms); ATTEMPT = $iattempt")

        while (cnt < iattempt) {
            val requestTypeOut =
                UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
            val totalByteSent = usbConnection!!.controlTransfer(
                requestTypeOut,
                REQUEST_CODE,
                REQUEST_VALUE_OUT,
                usbInterface!!.id,
                VERSION101,
                VERSION101.size,
                firmwareData.usbhidVersionTimeout
            )
            Log.d(TAG, "[sendVersion101] totalByteSent = $totalByteSent")

            val res = readDataAsString(firmwareData.usbhidVersionTimeout)

            if (res != null) {
                Log.d(TAG, "[sendVersion101] recv[$cnt]: $res")
                return res
            } else {
                Log.d(TAG, "[sendVersion101] recv[$cnt] - ERROR:")
            }
            cnt++
        }

        return null
    }

    private fun totalBlocksOf(pages: List<FirmwarePage>): Int {
        var total = 0
        for (fp in pages) {
            for (hp in fp.getHPages()) {
                total += hp.numBlock
            }
        }
        return total
    }

    private fun sendPageGroup(
        groupName: String,
        pages: List<FirmwarePage>,
        firmwareData: FirmwareData,
        totalBlocks: Int,
        sentBlocksStart: Int,
        progressCallback: (Int) -> Unit
    ): Int {
        var sentBlocks = sentBlocksStart

        for (fp in pages) {
            // Send VERSION once per FirmwarePage (same behavior as your original code)
            if (firmwareData.protocol == PROTOCOL_1D101) {
                Log.d(TAG, "[$groupName] sending the VERSION message")
                val rx = sendVersion101(
                    fp.blockVersion101,
                    firmwareData.usbhidDataTimeout,
                    firmwareData.usbhidDataAttempt
                )
                Log.d(TAG, "[$groupName] Block_Version_Return: $rx")

                val answer = rx
                    ?.takeIf { it.length >= 4 }
                    ?.substring(2, 4)
                    ?.toIntOrNull(16)
                    ?.toByte()

                if (answer != ACK.toByte()) {
                    Log.d(TAG, "[$groupName] Block_Version_Return: ERROR_RESPONSE. Stop Firmware Upgrade")
                    return -1 // signal failure
                } else {
                    Log.d(TAG, "[$groupName] Block_Version_Return: ACK_RESPONSE")
                }
            }

            for (hp in fp.getHPages()) {
                Log.d(TAG, "[$groupName] sending block $sentBlocks of $totalBlocks.")
                sendHexPage(fp, hp, sentBlocks, totalBlocks, progressCallback)
                sentBlocks += hp.numBlock
            }
        }

        return sentBlocks
    }

    // Usage
    fun upgradeFirmware(
        firmwareData: FirmwareData,
        isUpgradeBoot: Boolean,
        progressCallback: (Int) -> Unit
    ) {
        val appPages = firmwareData.mApplicationPages
        val bootPages = if (isUpgradeBoot) firmwareData.mBootPages else emptyList()

        val totalBlocks = totalBlocksOf(appPages) + totalBlocksOf(bootPages)

        var sentBlocks = 0

        // Send Application
        val afterApp = sendPageGroup(
            groupName = "sendApp",
            pages = appPages,
            firmwareData = firmwareData,
            totalBlocks = totalBlocks,
            sentBlocksStart = sentBlocks,
            progressCallback = progressCallback
        )
        if (afterApp < 0) return
        sentBlocks = afterApp

        // Send Boot (optional)
        if (isUpgradeBoot) {
            val afterBoot = sendPageGroup(
                groupName = "sendBoot",
                pages = bootPages,
                firmwareData = firmwareData,
                totalBlocks = totalBlocks,
                sentBlocksStart = sentBlocks,
                progressCallback = progressCallback
            )
            if (afterBoot < 0) return
            sentBlocks = afterBoot
        }

        // Ensure progress ends at 100% (in case of rounding inside callbacks)
        progressCallback.invoke(100)
    }

    @Throws(Exception::class)
        fun waitInstallation1D10(): String {
            val FLASH_WR_START = "24"
            val FLASH_WR_END = "25"

            var opcode = ""
            val deviceAnswer = hostEnd(firmwareData.usbhidEndTimeout, firmwareData.usbhidEndAttempt)

            if (!deviceAnswer.isNullOrEmpty()) {
                opcode = deviceAnswer.substring(2, 4)
                when (opcode) {
                    FLASH_WR_START -> Log.d(TAG, "[waitInstallation1D10] FLASH_WR_START ...")
                    FLASH_WR_END -> {
                        Log.d(TAG, "[waitInstallation1D10] Upgrade is completed!")
                        completeStatus = FLASH_WR_END
                        return WRITE_FLASH_OK
                    }
                }
            } else {
                val msg = "No response from device, installation is stopping."
                Log.d(TAG, "[waitInstallation1D10] $msg")
                return WRITE_FLASH_TIMEOUT
            }

            val updateTimeout = firmwareData.usbhidFlashUpdateTimeout.toLong()
            val installationTimeout = 3600 * 1000
            val installStart = System.currentTimeMillis()

            Log.d(TAG, "[waitInstallation1D10] installation timeout: $installationTimeout (ms)")
            Log.d(TAG, "UPGRADE_LOAD_WAIT_FLASH_WRITE")

            while (System.currentTimeMillis() - installStart < installationTimeout) {
                try {
                    val rx = readDataAsString(1000)
                    Log.d(TAG, "[waitInstallation1D10] receiveEnd: $rx")

                    if (!rx.isNullOrBlank()) {
                        val isFlashEnd = rx.substring(2, 4) == FLASH_WR_END
                        if (isFlashEnd) {
                            Log.d(
                                TAG,
                                "[waitInstallation1D10] waiting flash update in $updateTimeout (ms)"
                            )
                            Thread.sleep(updateTimeout)
                            Log.d(TAG, "[waitInstallation1D10] Upgrade is completed!")
                            completeStatus = WRITE_FLASH_OK
                            return WRITE_FLASH_OK
                        }
                    }
                } catch (ex: Exception) {
                    Log.d(TAG, "[waitInstallation1D10] Stopped by EXCEPTION! ${ex.message}")
                    completeStatus = WRITE_FLASH_OK
                    return WRITE_FLASH_OK
                }
            }

            Log.d(TAG, "[waitInstallation1D10] Upgrade is timeout!")
            return WRITE_FLASH_TIMEOUT
        }


        @Throws(Exception::class)
        fun selectBlock(fp: FirmwarePage) {
            Log.d(TAG, "selectBlock: fp.id=${fp.id}, fp.pid=${fp.pid}")
            val answer = joinBlock(fp)
            when (answer.opcode) {
                CAnswer.ACK -> Log.d(TAG, "selectBlock: ACK")
                CAnswer.FORCE -> Log.d(TAG, "selectBlock: FORCE")
                CAnswer.RESTART -> {
                    Log.d(TAG, "selectBlock: RESTART")
                    Thread.sleep(10000)
                    //if (awaitResult == true) {
                    Log.d(TAG, "[selectBlock] Device re-attached successfully.")
                    handleRestart()
                    usbConnection?.let {
                        joinDeviceExtended()
                    }
                }
                else -> {
                    Log.d(TAG, "selectBlock: ERROR: ${answer.field}")
                }
            }
        }

        @Throws(Exception::class)
        private fun joinBlock(fp: FirmwarePage): CAnswer {
            val answer = CAnswer()
            Log.d(
                TAG,
                "[joinBlock] JOIN_TIMEOUT = ${firmwareData.usbhidJoinBlockTimeout}(ms); ATTEMPT = ${firmwareData.usbhidJoinBlockAttempt}"
            )

            val rx = joinBlock(
                fp.id,
                firmwareData.usbhidJoinBlockTimeout,
                firmwareData.usbhidJoinBlockAttempt
            )
            Log.d(TAG, "[joinBlock] JOINBLOCK_Return: $rx")

            if (rx.isNullOrEmpty()) {
                answer.opcode = 0xFF.toByte()
                return answer
            }

            answer.opcode = Integer.parseInt(rx.substring(2, 4), 16).toByte()
            Log.d(TAG, "[joinBlock] JOINBLOCK_opcode = ${answer.opcode}")

            answer.field = when (answer.opcode) {
                CAnswer.RESTART -> rx.substring(4, 8)
                else -> ""
            }

            return answer
        }

        @Throws(Exception::class)
        private fun sendHexPage(
            fp: FirmwarePage,
            hPage: HexPage,
            calBlocks: Int,
            totalBlocks: Int,
            progressCallback: (Int) -> Unit
        ) {
            val data = hPage.getStringData()
            var hBlock: HexBlock?

            var oldPercentage = 0
            do {
                hBlock = data?.let { hPage.getNextHexBlock(it) }
                val currentBlock = hBlock?.numBlock?.plus(calBlocks)
                val perc = ((currentBlock?.times(100.0))?.div(totalBlocks))?.toInt()

                if (oldPercentage != perc) {
                    perc?.let {
                        oldPercentage = it
                        progressCallback(oldPercentage)
                    }
                }

                val result = hBlock?.address?.let {
                    sendFirmwareBlock(currentBlock?: 0, SmartUtil.hexStringToByteArray(hBlock.data.toString()), it)
                }

                if (result != RESULT_ACK) {
                    Log.d(
                        TAG,
                        "[sendHexPage] stop firmware upgrade by result $result not equal to ACK"
                    )
                }
            } while (!hBlock?.last!!)
        }

        @Synchronized
        @Throws(Exception::class)
        fun getVersionIdPid12(
            idInput: String,
            blockVersion: String,
            xtimeout: Int,
            iattempt: Int
        ): ByteArray? {
            var id = idInput
            if (id.startsWith("0x")) {
                id = id.substring(2)
            }

            VERSION101[2] = Integer.parseInt(id.substring(0, 2), 16).toByte()

            for (i in blockVersion.indices) {
                val index = 3 + i
                VERSION101[index] = blockVersion[i].code.toByte()
            }

            Log.d(TAG, "[getVersionIdPid] TIMEOUT = $xtimeout (ms); ATTEMPT = $iattempt")

            var cnt = 0
            while (cnt < iattempt) {
                Log.d(TAG, "[getVersionIdPid] send[$cnt]: ${SmartUtil.printBytesToHex(VERSION101)}")

                val requestTypeOut =
                    UsbConstants.USB_DIR_OUT or UsbConstants.USB_TYPE_CLASS or UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
                val totalByteSent = usbConnection!!.controlTransfer(
                    requestTypeOut,
                    REQUEST_CODE,
                    REQUEST_VALUE_FEATURE,
                    usbInterface!!.id,
                    VERSION101,
                    VERSION101.size,
                    firmwareData.usbhidVersionTimeout
                )
                Log.d(TAG, "[getVersionIdPid] totalByteSent = $totalByteSent")

                if (totalByteSent > 0) {
                    val data = ByteArray(64)
                    val bytesRead =
                        usbConnection?.bulkTransfer(usbEndpointIn, data, data.size, xtimeout) ?: -1
                    val result = data.joinToString(", ") {
                        "0x%02X".format(it)
                    }
                    if (bytesRead > 0) {
                        Log.d(TAG, "[getVersionIdPid] recv[]: $result")
                        return data
                    } else {
                        Log.d(TAG, "[getVersionIdPid] recv[] - ERROR:")
                    }
                }
            }
            return null
        }

        fun intelHexToBinFile(
            hexLines: Sequence<String>,
            outputBin: File,
            pageBaseAddr: Long = 0L
        ) {
            val raf = RandomAccessFile(outputBin, "rw")
            raf.setLength(0)
            var upperAddress = 0
            for (line in hexLines) {
                if (!line.startsWith(":")) continue
                val len = line.substring(1, 3).toInt(16)
                val address = line.substring(3, 7).toInt(16)
                val type = line.substring(7, 9).toInt(16)
                when (type) {
                    0x00 -> {
                        // data record
                        val absAddr = (upperAddress shl 16) + address
                        val fileOffset = absAddr.toLong() - pageBaseAddr
                        if (fileOffset >= 0) {
                            raf.seek(fileOffset)
                            for (i in 0 until len) {
                                val byteHex = line.substring(9 + i * 2, 11 + i * 2)
                                val byteVal = byteHex.toInt(16).toByte()
                                raf.write(byteVal.toInt())
                            }
                        }
                    }

                    0x04 -> {
                        // extended linear address
                        upperAddress = line.substring(9, 13).toInt(16)
                    }

                    0x01 -> break
                    // other types are ignored
                }
            }
            raf.close()
        }

        private fun sendFirmwareFromFile(
            binFile: File, blockSize: Int, address: String,
            sendBlock: (blockIdx: Int, data: ByteArray, address: String) -> Boolean
        ) {
            val raf = RandomAccessFile(binFile, "r")
            var blockIdx = 0
            val buf = ByteArray(blockSize)
            raf.seek(0)
            while (raf.filePointer < raf.length()) {
                val bytesRead = raf.read(buf)
                val sendBuf = if (bytesRead == blockSize) buf else buf.copyOf(bytesRead)
                if (!sendBlock(blockIdx, sendBuf, address)) {
                    raf.close()
                    throw Exception("Block send failed at $blockIdx")
                }
                blockIdx++
            }
            raf.close()
        }

        private class CAnswer {
            var opcode: Byte = 0x00
            var field: String = ""

            companion object {
                // Constants
                const val ACK: Byte = 0x06
                const val NACK: Byte = 0x15
                const val SKIP: Byte = 0x28
                const val RESTART: Byte = 0x31
                const val FORCE: Byte = 0x34
            }
        }

        class FirmwareVersionController(private val firmwareData: FirmwareData) {

            init {
                resetPages()
            }

            fun numberOfFirmwarePages(): Int {
                return firmwareData.mApplicationPages.size + firmwareData.mBootPages.size
            }

            fun getFirmwarePage(index: Int): FirmwarePage? {
                // Check application pages
                /*for (page in firmwareData.mApplicationPages) {
                if (page.index == index) {
                    return page
                }
            }*/
                return if(index < firmwareData.mApplicationPages.size){
                    firmwareData.mApplicationPages.getOrNull(index)
                } else {
                    firmwareData.mBootPages[index - firmwareData.mApplicationPages.size]
                }
            }


            private fun markAsNotProcessed(fp: FirmwarePage) {
                fp.processed = false
                fp.toBeUpgraded = false
            }

            private fun markAsAccepted(fp: FirmwarePage) {
                Log.d(
                    TAG,
                    "[MarkAsAccepted] ctrl.version: accept fp[${fp.index}] .pid=${fp.pid}, .id=${fp.id}"
                )
                fp.processed = true
                fp.toBeUpgraded = true
            }

            private fun markAsDiscarded(fp: FirmwarePage) {
                Log.d(
                    TAG,
                    "[MarkAsDiscarded] ctrl.version: discard fp[${fp.index}] .pid=${fp.pid}, .id=${fp.id}"
                )
                fp.processed = true
                fp.toBeUpgraded = false
            }

            fun resetPages(): Boolean {
                for (i in 0 until numberOfFirmwarePages()) {
                    getFirmwarePage(i)?.let { markAsNotProcessed(it) }
                }
                return true
            }

            fun acceptPages(componentId: String, productId: String, rxVersion: String) {
                val devPid = DevicePid(productId)

                for (i in 0 until numberOfFirmwarePages()) {
                    val fp = getFirmwarePage(i) ?: continue
                    val idMatches = try {
                        Integer.decode(fp.id) == Integer.decode(componentId)
                    } catch (_: Exception) {
                        fp.id.equals(componentId, ignoreCase = true)
                    }

                    if (idMatches) {
                        if (devPid.isSupportedIn(
                                fp.pid,
                                firmwareData.protocol!!
                            ) || !firmwareData.checkPid
                        ) {
                            if (fp.sapNumber == rxVersion) {
                                markAsDiscarded(fp)
                                val blockName = "${fp.labelBlock} (id: ${fp.id}, pid: ${fp.pid})"
                            } else {
                                markAsAccepted(fp)
                            }
                        } else {
                            markAsDiscarded(fp)
                            val blockName = "${fp.labelBlock} (id: ${fp.id}, pid: ${fp.pid})"
                        }
                    }
                }
            }

            fun acceptPages12(
                componentId: String,
                productId: String,
                pidMask: String,
                rxVersion: String
            ) {
                val devPid = DevicePid(productId)

                for (i in 0 until numberOfFirmwarePages()) {
                    val fp = getFirmwarePage(i) ?: continue
                    val idMatches = try {
                        Integer.decode(fp.id) == Integer.decode(componentId)
                    } catch (_: Exception) {
                        fp.id.equals(componentId, ignoreCase = true)
                    }
                    if (idMatches) {
                        if (devPid.isSupportedIn12(
                                fp.pid,
                                firmwareData.protocol!!,
                                pidMask
                            ) || !firmwareData.checkPid
                        ) {
                            if (fp.sapNumber == rxVersion) {
                                markAsDiscarded(fp)
                                val blockName = "${fp.labelBlock} (id: ${fp.id}, pid: ${fp.pid})"
                            } else {
                                markAsAccepted(fp)
                            }
                        } else {
                            markAsDiscarded(fp)
                            val blockName = "${fp.labelBlock} (id: ${fp.id}, pid: ${fp.pid})"
                        }
                    }
                }
            }

            fun acceptPages(componentId: String): Boolean {
                var result = false

                for (i in 0 until numberOfFirmwarePages()) {
                    val fp = getFirmwarePage(i) as? FirmwarePage ?: continue

                    if (fp.id.equals(componentId, ignoreCase = true)) {
                        markAsAccepted(fp)
                        result = true
                    }
                }

                return result
            }

            fun discardPages(componentId: String): Boolean {
                var result = false

                for (i in 0 until numberOfFirmwarePages()) {
                    val fp = getFirmwarePage(i) as? FirmwarePage ?: continue
                    val idMatches = try {
                        Integer.decode(fp.id) == Integer.decode(componentId)
                    } catch (_: Exception) {
                        fp.id.equals(componentId, ignoreCase = true)
                    }
                    if (idMatches) {
                        markAsDiscarded(fp)
                        result = true
                    }
                }

                return result
            }

            fun checkPages(): Boolean {
                Log.d(TAG, "checkPages(): numberOfFirmwarePages: ${numberOfFirmwarePages()}")
                for (id1 in 0 until numberOfFirmwarePages()) {
                    Log.d(TAG, "getFirmwarePage[$id1]: ${getFirmwarePage(id1)}")
                    val fp1 = getFirmwarePage(id1) ?: return false

                    for (id2 in id1 until numberOfFirmwarePages()) {
                        Log.d(TAG, "getFirmwarePage[$id2]: ${getFirmwarePage(id2)}")
                        val fp2 = getFirmwarePage(id2) ?: return false

                        if (fp1.id == fp2.id && fp1.pid == fp2.pid) {
                            if (fp1.sapNumber != fp2.sapNumber) return false
                        }
                    }
                }
                return true
            }
        }
}

package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils

import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import kotlin.math.abs

class ImageCaptureHHS {
    // Image state and data

    private var TAG: String = ImageCaptureHHS::class.java.simpleName

    // Image configuration
    var q = "0"
    var bbContrastValue = "00" // contrast value
    var ccBrightnessDirection = "00" // brightness direction
    var ddContrastDirection = "00" // contrast direction
    var aaBrightnessValue = "00" // brightness value

    companion object {
        // Protocol commands
        const val SENSOR_ID = "x0"
        const val IMAGE_FORMAT = "01"
        const val HOST_CMD_CAPTURE = "00"
        const val HOST_CMD_CAPTURE_WITH_PREVIEW = "07"
        const val HOST_CMD_MULTIPLE_CAPTURE_ON_TRIGGER = "11"
        const val HOST_CMD_MULTIPLE_CAPTURE_ON_DECODE = "21"
        const val HOST_CMD_CAPTURE_SEQUENCE = "25"
        const val HOST_CMD_IMG_TX = "30"
        const val HOST_CMD_ABORT_IMAGE_CAPTURE = "40"

        const val IMG_RDY_MSG = "\$i"

        // Image formats
        const val IMGE_JPG = "1"
        const val IMGE_BMP = "0"
    }

    fun imageCaptureAuto(
        serviceSerial: ServiceSerial,
        currentBrightness: Int,
        currentContrast: Int
    ): ByteArray {
        try {
            setContrastAndBrightness(currentBrightness,currentContrast)

            // Step 1: Send the abort capture command.
            serviceSerial.sendReceive(formatMsg(HOST_CMD_ABORT_IMAGE_CAPTURE).toByteArray(),2000, 500)

            // Step 2: Wait for the scanner to send the "image ready" message.
            val response = serviceSerial.sendReceive(formatMsg(HOST_CMD_CAPTURE).toByteArray(),12000, 500)
            val responseString = response!!.toString(Charsets.UTF_8)
            if (!responseString.contains(IMG_RDY_MSG)) {
                // Handle the case where the ready message isn't received.
                // For example, you might log a message or return early.
                return ByteArray(0)
            }

            // Step 3: The "image ready" message is received.
            // Parse the image size and prepare the image data buffer.
            val imgSize = parseImageSize(responseString)
            Log.d(TAG, "Image: requied size = $imgSize")

            // Step 6: Receive image data from the scanner.
            val imgData: ByteArray? = serviceSerial.sendReceiveImage(formatMsg(HOST_CMD_IMG_TX).toByteArray(), imgSize,12000,1000)
            if (imgData != null) {
                val tempSize = imgData.size
                Log.d(TAG, "Image: current size = $tempSize")

                val differ = abs(imgSize - tempSize)
                if (differ > 0) {
                    Log.d(TAG, "Image bytes lost: $differ")
                }
            }

            // Step 7: Process the received bytes.
            // Exit the loop once the full image is processed.
            return imgData ?: ByteArray(0)

        } catch (ex: Exception) {
            ex.printStackTrace()
        }
        return ByteArray(0)
    }

    // Parse image size from response
    private fun parseImageSize(response: String): Int {
        // Extract size bytes (positions 4-11) and convert from hex
        val sizeBytes = response.substring(4, 12)
        return Integer.decode("0x$sizeBytes")
    }

    private fun sendMsg(serviceSerial: ServiceSerial, captureMode: String) {
        serviceSerial.send(formatMsg(captureMode).toByteArray())

    }

    private fun formatMsg(captureMode: String): String {
        val msg = SENSOR_ID + captureMode + q + aaBrightnessValue + bbContrastValue + ccBrightnessDirection + ddContrastDirection + "\r"
        return msg
    }


    fun setContrastAndBrightness(brightness: Int, contrast: Int) {
        q = "0"
        aaBrightnessValue     = "00"
        bbContrastValue       = "00"
        ccBrightnessDirection = "00"
        ddContrastDirection   = "00"

        if (contrast != 0 || brightness != 0) {
            q = "1"

            var contrastValue = contrast
            if (contrastValue < 0) {
                contrastValue = -contrastValue
                ddContrastDirection = "01"
            }
            bbContrastValue = contrastValue
                .toString(16)
                .uppercase()
                .padStart(2, '0')

            var brightnessValue = brightness
            if (brightnessValue < 0) {
                brightnessValue = -brightnessValue
                ccBrightnessDirection = "01"
            }
            aaBrightnessValue = brightnessValue
                .toString(16)
                .uppercase()
                .padStart(2, '0')
        }
    }
}
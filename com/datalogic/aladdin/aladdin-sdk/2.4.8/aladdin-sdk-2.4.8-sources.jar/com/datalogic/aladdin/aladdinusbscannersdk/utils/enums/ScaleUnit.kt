package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class ScaleUnit {
    KG,
    LB,
    NONE
}
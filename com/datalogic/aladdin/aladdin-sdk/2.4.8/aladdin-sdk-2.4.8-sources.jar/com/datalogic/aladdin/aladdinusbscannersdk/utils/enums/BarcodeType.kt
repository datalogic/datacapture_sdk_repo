package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class BarcodeType(val hexValue: String, private val label: String) {
    EAN_JAN_13("0x16", "EAN/JAN-13"),
    EAN_JAN_8("0x0C", "EAN/JAN-8"),
    UPC_A("0x0D", "UPC-A"),
    UPC_E("0x0A", "UPC-E"),
    UPC_D1("0x0011", "UPC-D1"),
    UPC_D2("0x0012", "UPC-D2"),
    UPC_D3("0x0014", "UPC-D3"),
    UPC_D4("0x0017", "UPC-D4"),
    UPC_D5("0x001D", "UPC-D5"),
    UPC_A_2("0x00160B", "UPC-A+2"),
    UPC_A_5("0x00110B", "UPC-A+5"),
    UPC_E_2("0x00120B", "UPC-E+2"),
    UPC_E_5("0x00140B", "UPC-E+5"),
    EAN_JAN_8_2("0x00170B", "EAN/JAN-8+2"),
    EAN_JAN_8_5("0x001D0B", "EAN/JAN-8+5"),
    EAN_JAN_13_2("0x00130B", "EAN/JAN-13+2"),
    EAN_JAN_13_5("0x00150B", "EAN/JAN-13+5"),
    STANDARD_2_OF_5("0x000C0B", "Standard (Discrete) 2 of 5"),
    INTERLEAVED_2_OF_5("0x000D0B", "Interleaved 2 of 5"),
    CODE39("0x000A0B", "Code39"),
    CODE128("0x00180B", "Code128"),
    CODABAR("0x000E0B", "Codabar"),
    CODE93("0x00190B", "Code 93"),
    UCC_EAN_128("0x00250B", "UCC/EAN-128"),
    UPC_A_CODE128_SUPPLEMENTAL("0x00200B", "UPC-A w/Code 128 Supplemental"),
    UPC_E_CODE128_SUPPLEMENTAL("0x00210B", "UPC-E w/Code 128 Supplemental"),
    EAN_JAN_8_CODE128_SUPPLEMENTAL("0x00220B", "EAN/JAN-8 w/Code 128 Supplemental"),
    EAN_JAN_13_CODE128_SUPPLEMENTAL("0x00230B", "EAN/JAN-13 w/Code 128 Supplemental"),
    GS1_DATABAR("0x002A0B", "GS1 DataBar/GS1 DataBar Limited/GS1 DataBar Stacked"),
    GS1_DATABAR_EXPANDED("0x002B0B", "GS1 DataBar Expanded"),
    PDF417("0x002E0B", "PDF417"),
    MICROPDF("0x00380B", "MicroPDF"),
    MAXICODE("0x002F0B", "Maxicode"),
    OCR_A("0x00300B", "OCR-A"),
    OCR_B("0x00310B", "OCR-B"),
    DATAMATRIX("0x00320B", "DataMatrix"),
    GS1_DATAMATRIX("0x00360B", "GS1 DataMatrix"),
    QR_CODE("0x00330B", "QR Code"),
    GS1_QR_CODE("0x00370B", "GS1 QR Code"),
    AZTEC_CODE("0x00340B", "Aztec Code"),
    CODE49("0x00350B", "Code 49"),
    MICRO_QR_CODE("0x00390B", "Micro QR Code"),
    HAN_XIN_CODE("0x003E0B", "Han Xin"),
    DOT_CODE("0x003B0B", "Dot Code"),
    CODE32("0x003D0B", "Code 32"),
    UNKNOWN("0x00FF0B", "Unknown");

    companion object {
        private val map = values().associateBy(BarcodeType::hexValue)
        fun fromHexValue(hexValue: String) = map[hexValue]
    }

    fun getKeyValueString(): String {
        return label
    }
}

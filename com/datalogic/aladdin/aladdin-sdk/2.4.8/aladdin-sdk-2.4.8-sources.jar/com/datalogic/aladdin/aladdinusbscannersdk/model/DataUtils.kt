package com.datalogic.aladdin.aladdinusbscannersdk.model

object DataUtils {
    fun stripComment(ule: String): String {
        val sb = StringBuilder()
        var inComment = false
        var inString = false

        for (i in ule.indices) {
            val c = ule[i]
            if (!inString) {
                if (c == ';' || c == '#') {
                    inComment = true
                } else if (c == '\n' || c == '\r') {
                    inComment = false
                }
            }

            if (!inComment) {
                if (c != '\r' && c != '\t') {
                    if (c == '"') {
                        inString = !inString
                    }
                    if (c != ' ' || inString) {
                        sb.append(c)
                    }
                }
            }
        }

        return sb.toString()
    }

    private fun adjustLen(maxlen: Int): Int {
        return when {
            maxlen == 4 -> 0
            maxlen < 4 -> 4 - maxlen
            maxlen < 8 -> 8 - maxlen
            else -> {
                val mod4 = maxlen % 4
                if (mod4 != 0) 4 - mod4 else 0
            }
        }
    }

    private fun getUleCmd(uleInput: String?, addr: Int, maxlenInput: Int): String {
        if (uleInput.isNullOrBlank()) return ""

        var ule = uleInput
        var maxlen = maxlenInput
        var cmd = "\$U"

        if (ule.length < maxlen) {
            maxlen = ule.length
        }
        if (maxlen == 0) return ""

        val adjLen = adjustLen(maxlen)
        repeat(adjLen) {
            ule += '\u000A' // Equivalent to ap0A (line feed character)
        }
        maxlen += adjLen

        cmd += addr.toString(16).padStart(4, '0').uppercase()
        cmd += maxlen.toString(16).padStart(4, '0').uppercase()

        for (i in 0 until maxlen) {
            val c = ule[i]
            val h = c.code.toString(16).padStart(2, '0').uppercase()
            cmd += h
        }

        return cmd
    }

    fun getUleCmdList(uleStr: String): List<String> {
        val ule = stripComment(uleStr)
        val cmdList = mutableListOf<String>()
        val lenUle = ule.length
        val adjLen = lenUle + adjustLen(lenUle)
        var lenS = (adjLen + 2).toString(16).padStart(4, '0').uppercase()
        val cmdStart = "\$U00000008554C4532${lenS}0A0A"
        cmdList.add(cmdStart)

        var remainingUle = ule
        var addr = 8
        val len = 16

        if (remainingUle.length > 0) {
            while (true) {
                val cmd = getUleCmd(remainingUle, addr, len)
                if (cmd.isNotBlank()) {
                    cmdList.add(cmd)
                }
                addr += len
                if (remainingUle.length > len) {
                    remainingUle = remainingUle.substring(len)
                } else {
                    break
                }
            }
        }

        return cmdList
    }

    fun stripComment(string: String?, comment: String): String? {
        if (string == null) {
            return null
        }
        val index = string.indexOf(comment)
        return when {
            index == -1 -> string.trim()
            index > 0 -> string.substring(0, index).trim()
            else -> null
        }
    }

}
package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils

import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.model.Configuration
import com.datalogic.aladdin.aladdinusbscannersdk.model.DataRowCCF
import com.datalogic.aladdin.aladdinusbscannersdk.model.DataUtils.stripComment
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.byteArrayToHexString
import java.nio.ByteBuffer


class CharsUtil {
    /**Method to replace the input string with the same string where each charachter is replaced with the HEX related code */
    fun replaceHexTextString(streamBuffer: ByteArray, offest: Int, len: Int): String {
        val stringBuffer = StringBuilder()
        for (i in offest..<len) {
            val ch = streamBuffer[i].toInt() and 0xFF
            stringBuffer.append(getView(ch))
        } //for

        return stringBuffer.toString()
    }

    /**Exe is the string array contains the charachters to replace and show into the terminal. */
    private val exe = arrayOfNulls<String>(0xFF + 1)

    /**Constructor */
    init {
        val val0021 = arrayOf(
            "NUL", "SOH", "STX", "ETX", "EOT", "ENQ", "ACK", "BEL", "BS", "HT", "LF", "VT",
            "FF", "CR", "SO", "SI", "DLE", "DC1", "DC2", "DC3", "DC4", "NACK", "SYN", "ETB",
            "CAN", "EM", "SUB", "ESC", "FS", "GS", "RS", "US", "SPACE"
        )
        val val839B = arrayOf(
            "ENTER", "ENT", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9",
            "F10", "F11", "F12", "HOME", "END", "PG_UP", "PG_DOWN", "UP", "DOWN",
            "LEFT", "RIGHT", "ESC", "CTRL", "EURO"
        )
        val val9CFD = arrayOf(
            "oe",
            "",
            "ž",
            "Ÿ",
            "NBSP",
            "¡",
            "¢",
            "£",
            "¤",
            "¥",
            "¦",
            "§",
            "¨",
            "©",
            "ª",
            "«",
            "¬",
            "-",
            "®",
            "¯",
            "°",
            "±",
            "²",
            "³",
            "´",
            "µ",
            "¶",
            "·",
            "¸",
            "¹",
            "º",
            "»",
            "¼",
            "½",
            "¾",
            "¿",
            "À",
            "Á",
            "Â",
            "Ã",
            "Ä",
            "Å",
            "Æ",
            "Ç",
            "È",
            "É",
            "Ê",
            "Ë",
            "Ì",
            "Í",
            "Î",
            "Ï",
            "Ð",
            "Ñ",
            "Ò",
            "Ó",
            "Ô",
            "Õ",
            "Ö",
            "×",
            "Ø",
            "Ù",
            "Ú",
            "Û",
            "Ü",
            "Ý",
            "Þ",
            "ß",
            "à",
            "á",
            "â",
            "ã",
            "ä",
            "å",
            "æ",
            "ç",
            "è",
            "é",
            "ê",
            "ë",
            "ì",
            "í",
            "î",
            "ï",
            "ð",
            "ñ",
            "ò",
            "ó",
            "ô",
            "õ",
            "ö",
            "÷",
            "ø",
            "ù",
            "ú",
            "û",
            "ü",
            "ý"
        )

        for (i in val0021.indices) {
            exe[i] = "[" + val0021[i] + "]"
        }
        for (i in 0x21..0x7e) {
            exe[i] = java.lang.String("" + i.toChar()) as String
        }

        exe[0x7f] = "[DEL]"
        exe[0x80] = null //non deve essere visualizzato
        exe[0x81] = null //non deve essere visualizzato
        exe[0x82] = null //non deve essere visualizzato
        exe[0x9b] = "€"

        for (i in val839B.indices) {
            exe[0x83 + i] = "[" + val839B[i] + "]"
        }
        for (i in val9CFD.indices) {
            exe[0x9C + i] = val9CFD[i]
        }

        exe[0xfe] = "[0xfe]"
        exe[0xff] = "--"
    }

    /**Method that returns the related string to the int code as input */
    private fun getView(codeInt: Int): String? {
        return exe[codeInt]
    }

    companion object {
        fun asciiStringToHexString(s: String): String {
            val chars = s.toCharArray()
            val hex = StringBuffer()
            for (i in chars.indices) {
                hex.append(Integer.toHexString(chars[i].code))
            }
            return hex.toString()
        }

        fun hexStringToAscii(s: String): String {
            val output = StringBuilder()
            var i = 0
            while (i < s.length) {
                val str = s.substring(i, i + 2)
                output.append(str.toInt(16).toChar())
                i += 2
            }
            return output.toString()
        }

        @Throws(Exception::class)
        fun makeScriptFromCmds(uleCmd: String?): String {
            if (uleCmd == null || uleCmd.length < 18) {
                return ""
            }

            val uleCmd = uleCmd.substring(16)
            val sb = StringBuilder()

            var j = 0
            while (j < uleCmd.length - 1) {
                val ch = uleCmd.substring(j, j + 2)
                if (ch.equals("FF", ignoreCase = true)) {
                    break
                }
                val ci = ch.toInt(16)
                val cs = ci.toChar()
                sb.append(cs)
                j += 2
            }

            return sb.toString()
        }


        fun getCmdList(tex: String?): List<DataRowCCF> {
            val cmdList = mutableListOf<DataRowCCF>()
            if (!tex.isNullOrBlank()) {
                val trimmedText = tex.trim()
                val lines = trimmedText.split(Regex("\\r?\\n|\\r"))
                for ((index, line) in lines.withIndex()) {
                    var cmd = stripComment(line, ";")
                    cmd = stripComment(cmd, "#")
                    if (!cmd.isNullOrBlank()) {
                        cmdList.add(DataRowCCF(index + 1, cmd))
                    }
                }
            }
            return cmdList
        }

        fun formatLine(one: String?, two: String): String {
            return String.format("%-30s # %s\r\n", one, two)
        }

        fun formatLine(one: String, two: String, three: String): String {
            return String.format("%-30s # %-40s : %10s\r\n", one, two, three)
        }

        fun addChecksum(s: String): String? {
            val bytes = SmartUtil.hexStringToByteArray(s)
            var chkSum: Byte = 0 // Use var as it's reassigned
            for (b in bytes) {
                chkSum = (chkSum + b).toByte() // Ensure result is a Byte
            }
            chkSum = (0 - chkSum).toByte() // Ensure result of negation is a Byte

            // Add checksum byte to the array
            // In Kotlin, ByteArrays don't have a direct 'add' method like some mutable lists.
            // You typically create a new array.
            val bytesWithChecksum = bytes + chkSum // Using Kotlin's + operator for convenience

            return SmartUtil.byteArrayToHexString(bytesWithChecksum)
        }

        fun parseScannerResponse(response: ByteArray, command: String = ""): Map<String, Any> {
            if (response.isEmpty()) throw IllegalArgumentException("Empty response")

            val firstByte = response[0]

            return when (firstByte) {
                0x06.toByte(), 0x15.toByte(), 0x18.toByte() -> mapOf(
                    "type" to "single-byte",
                    "code" to firstByte,
                    "meaning" to when (firstByte) {
                        0x06.toByte() -> "ACK"
                        0x15.toByte() -> "NAK"
                        0x18.toByte() -> "CAN"
                        else -> "Unknown"
                    }
                )

                0x02.toByte() -> { // Short response
                    val length = response[1].toUByte().toInt()
                    val expectedSize = 2 + length
                    if (response.size != expectedSize)
                        throw IllegalArgumentException("Expected $expectedSize bytes, got ${response.size}")

                    val data = response.sliceArray(2 until response.size - 1)
                    val checksum = response.last()

                    val sum = response.slice(0 until response.size - 1).sumOf { it.toUByte().toInt() }
                    val expectedChecksum = ((-sum) and 0xFF).toByte()
                    if (checksum != expectedChecksum)
                        throw IllegalArgumentException("Invalid checksum")

                    mapOf(
                        "type" to "short",
                        "length" to length,
                        "data" to data,
                        "checksum" to checksum
                    )
                }

                0x82.toByte() -> { // Extended response
                    if (response.size < 6)
                        throw IllegalArgumentException("Too short for extended response")

                    val length = ByteBuffer.wrap(response, 1, 4).int
                    val expectedSize = 5 + length
                    if (response.size != expectedSize)
                        throw IllegalArgumentException("Expected $expectedSize bytes, got ${response.size}")

                    val data = response.sliceArray(5 until response.size - 1)
                    val checksum = response.last()

                    val sum = response.slice(0 until response.size - 1).sumOf { it.toUByte().toInt() }
                    val expectedChecksum = ((-sum) and 0xFF).toByte()
                    if (checksum != expectedChecksum)
                        throw IllegalArgumentException("Invalid checksum")

                    mapOf(
                        "type" to "extended",
                        "length" to length,
                        "data" to data,
                        "checksum" to checksum
                    )
                }

                else -> {
                    Log.d("SDK", "[parseScannerResponse] command: $command => response: ${byteArrayToHexString(response)}")
                    throw IllegalArgumentException("Unknown response start byte: 0x${"%02X".format(firstByte)} - command: $command => response: ${byteArrayToHexString(response)}")
                }
            }
        }

        fun generateConfigFile(config: Configuration): String?{
            val tagItem = "${config.tagName}${config.value}"
            return addChecksum(tagItem)
        }
        fun frsCCFExtractCmds(cmdList: List<DataRowCCF>): List<DataRowCCF>? {
            var start = -1
            var end = -1

            for (i in cmdList.indices) {
                when (cmdList[i].rowData) {
                    "&" -> start = i
                    "$" -> end = i
                }
            }

            return if (start != -1 && end != -1 && end > start) {
                cmdList.subList(start + 1, end)
            } else {
                null
            }
        }

        fun ByteArray.containsSequence(sequence: ByteArray): Boolean {
             if (sequence.isEmpty() || this.size < sequence.size) return false

             outer@ for (i in 0..this.size - sequence.size) {
                 for (j in sequence.indices) {
                 if (this[i + j] != sequence[j]) continue@outer
                 }
                 return true
                 }
             return false
        }

        fun processPayload(data: ByteArray?): String {
            val resultStr = data?.let { String(it) } ?: ""

            try {
                if (data != null && data.size >= 7 && (data[5].toInt() and 0xFF) == 1) {
                    val byte6 = data[6].toInt() and 0xFF
                    if (byte6 == 2 || byte6 == 4) {
                        val result = StringBuilder()

                        var i = 0
                        while (i < data.size) {
                            val end = minOf(i + 64, data.size)

                            val blockStart = i + 5
                            if (blockStart < end) {
                                var lastNonZero = end - 1
                                while (lastNonZero >= blockStart && data[lastNonZero].toInt() == 0) {
                                    lastNonZero--
                                }

                                for (j in blockStart..lastNonZero) {
                                    result.append((data[j].toInt() and 0xFF).toChar())
                                }
                            }

                            i += 64
                        }

                        return result.toString()
                    }
                }
            } catch (e: Exception) {
                Log.e("CharsUtil", "Cannot processPayload ${e.message}")
            }

            return resultStr
        }

        const val PROTOCOL_1D10 = "1D-1.0"
        const val PROTOCOL_1D101 = "1D-1.0.1"
        const val PROTOCOL_1D11 = "1D-1.1"
        const val PROTOCOL_1D12 = "1D-1.2"
        const val PROTOCOL_1D21 = "1D-2.1"
    }
}
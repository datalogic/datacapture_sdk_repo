package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.s37

import java.io.File

/**
 * Kotlin implementation of S37FirmwareData for handling S37 firmware files
 *
 * @author RCase (original Java version)
 * @author Kotlin conversion
 */
class S37FirmwareData(
    var checkPid: Boolean = true,
    var fileS37: File? = null,
    var pid: String? = null,
    var release: String? = null,
    private var configId: String? = null,
    var frsSwid: String? = null,
    var hhsSwid: String? = null,
    var hhsPassthroughPid: String? = null
) {
    /**
     * Extracts header data from the lines based on the data name
     *
     * @param lines List of header lines to search
     * @param dataName Name of the data to extract
     * @return The extracted data value or null if not found
     */
    protected fun getHeaderData(lines: List<String>, dataName: String): String? {
        val searchString = " $dataName="

        for (line in lines) {
            if (line.contains(searchString)) {
                val startIndex = line.indexOf(searchString) + searchString.length
                val endIndex = line.indexOf(' ', startIndex).let {
                    if (it == -1) line.length else it
                }
                val out = line.substring(startIndex, endIndex)
                return if (out == "\"\"") "" else out
            }
        }
        return null
    }

    /**
     * Extracts HHS SWID from the lines
     *
     * @param lines List of header lines to search
     * @return The HHS SWID or null if not found
     */
    protected fun getHhsSwid(lines: List<String>): String? {
        val searchString = "S006000004" // S0 <length> <address> 04

        for (line in lines) {
            if (line.startsWith(searchString) && line.length == 16) {
                return line.substring(10, 14)
            }
        }
        return null
    }

    /**
     * Extracts HHS Passthrough PID from the lines
     *
     * @param lines List of header lines to search
     * @return The HHS Passthrough PID or null if not found
     */
    protected fun getHHSPassthroughPid(lines: List<String>): String? {
        if (lines.getOrNull(1)?.contains("APID") == true) {
            // The second line of any HHS Passthrough S37 will contain APID
            // Find first line that starts with REM, and look for PID from there, otherwise will return FRS PID
            val startingLine = lines.indexOfFirst { it.contains("REM") }

            if (startingLine >= 0) {
                val remLines = lines.subList(startingLine, lines.size)
                return getHeaderData(remLines, "PID")
            }
        }
        return null
    }

    /**
     * Gets the configuration ID
     *
     * @return The configuration ID
     */
    fun getConfigId(): String? = configId

    /**
     * Sets the configuration ID
     *
     * @param configId The configuration ID to set
     */
    fun setConfigId(configId: String?) {
        this.configId = configId
    }

    /**
     * Override toString for better debugging
     */
    override fun toString(): String {
        return "S37FirmwareData(" +
                "checkPid=$checkPid, " +
                "fileS37=${fileS37?.name}, " +
                "pid=$pid, " +
                "release=$release, " +
                "configId=$configId, " +
                "frsSwid=$frsSwid, " +
                "hhsSwid=$hhsSwid, " +
                "hhsPassthroughPid=$hhsPassthroughPid" +
                ")"
    }
}
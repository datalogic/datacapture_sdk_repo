package com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners

import android.hardware.usb.UsbDevice

/**
 * Interface of the lister for device attached and detached.
 */
interface UsbListener {

    /**
     * Function called when a device is attached.
     */
    fun onDeviceAttachedListener(device: UsbDevice)

    /**
     * Function called when a device is detached.
     */
    fun onDeviceDetachedListener(device: UsbDevice)

}
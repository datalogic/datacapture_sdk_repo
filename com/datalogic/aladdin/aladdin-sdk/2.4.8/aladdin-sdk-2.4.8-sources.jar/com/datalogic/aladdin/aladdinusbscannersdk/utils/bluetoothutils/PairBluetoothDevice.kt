package com.datalogic.aladdin.aladdinusbscannersdk.utils.bluetoothutils

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.MacAddress
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.annotation.RequiresPermission
import androidx.core.app.ActivityCompat
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.BluetoothConstants
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.BluetoothConstants.Companion.DATALOGIC_MAC_PREFIX
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.BluetoothConstants.Companion.DYNAMIC_PAIRING_CONSTANT
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.REQUEST_CODE_BT
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.BluetoothPairingStatus
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.BluetoothProfile
import com.datalogic.quickpairingapp.utils.SharedPreferenceUtil
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

class PairBluetoothDevice {
    private var TAG: String = PairBluetoothDevice::class.java.simpleName

    var isFinished = false
    private var message = ""
    var statusPairing = BluetoothPairingStatus.Unsuccessful

    lateinit var bluetoothAdapter: BluetoothAdapter
    var mCurrentBluetoothDevice: BluetoothDevice? = null
    var deviceName = ""
    private val protectionLock = ReentrantLock(true)
    var isPairing = false

    var isScanning = false
    var isBTReceiverRegistered = false
    var isBTHidReceiverRegistered = false
    var isDiscoveryRegistered = false
    var isAlreadyBonded = false
    var bluetoothProfile = BluetoothProfile.SPP
    var rebondForProfileHID = false // If device bonded, forget it after connecting HID

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun ensureBluetoothReady(activity: Activity): Boolean {
        var ready = true

        // Bluetooth check
        val bluetoothManager = activity.getSystemService(BluetoothManager::class.java)
        val bluetoothAdapter = bluetoothManager?.adapter
        if (bluetoothAdapter?.isEnabled != true) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            activity.startActivity(enableBtIntent)
            ready = false
        }

        // Location check
        val locationManager = activity.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val isLocationEnabled =
            locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                    locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if (!isLocationEnabled) {
            val enableLocationIntent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            activity.startActivity(enableLocationIntent)   // mở settings Location
            ready = false
        }

        return ready
    }

    fun ensureBluetoothPermissions(activity: Activity): Boolean {
        val permissions = mutableListOf<String>()

        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        val missing = permissions.filter {
            ActivityCompat.checkSelfPermission(activity, it) != PackageManager.PERMISSION_GRANTED
        }

        Log.d(TAG, "[ensureBluetoothPermissions] Permission: $missing")
        if (missing.isNotEmpty()) {
            Log.d(TAG, "[ensureBluetoothPermissions] Request permission")
            ActivityCompat.requestPermissions(
                activity,
                missing.toTypedArray(),
                REQUEST_CODE_BT
            )
            return false
        }
        val readyCheck = ensureBluetoothReady(activity)
        return readyCheck
    }

    private fun initializeVariable() {
        statusPairing = BluetoothPairingStatus.Unsuccessful
        isFinished = false
        deviceName = ""
        isAlreadyBonded = false
        isPairing = false
        rebondForProfileHID = false
    }

    @SuppressLint("MissingPermission")
    fun scanBluetoothDevices(context: Activity) {
        Log.d(TAG, "[scanBluetoothDevices] Begin processing")
        initializeVariable()

        initBlueToothAdapter(context)
        if (!ensureBluetoothPermissions(context)) {
            onFinish("Permission denied")
            return
        } else {
            val locationManager: LocationManager =
                context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val isLocServiceEnabled =
                locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
                    LocationManager.NETWORK_PROVIDER
                )
            if (!isLocServiceEnabled) {
                Log.w(TAG, "Location service disabled.")
                onFinish("Location service disabled")
                return
            }
            Log.d(TAG, "Bluetooth permission granted before.")
            discoveryAndPairDevice(context)
        }
        Log.d(TAG, "[scanBluetoothDevices] Processing")
    }

    fun initBlueToothAdapter(context: Context) {
        if (!::bluetoothAdapter.isInitialized) {
            val bluetoothManager =
                context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            bluetoothAdapter = bluetoothManager.adapter
        }
    }

    private fun discoveryAndPairDevice(context: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && ActivityCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_SCAN
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.d(
                TAG,
                "can not start BT discovery, Bluetooth scan permission is not present."
            )
            return
        }
        Log.d(
            TAG,
            "isEnabled=${bluetoothAdapter.isEnabled}, isDiscovering=${bluetoothAdapter.isDiscovering}"
        )

        val scanGranted = ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.BLUETOOTH_SCAN
        ) == PackageManager.PERMISSION_GRANTED
        val locGranted = ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        Log.d(TAG, "scanGranted=$scanGranted, locGranted=$locGranted")

        protectionLock.withLock {
            registerDiscoveryReceiver(context)
            val isStarted = bluetoothAdapter.startDiscovery()
            isScanning = isStarted
            Log.d(TAG, "[scanBluetoothDevices] Starting Bluetooth discovery: $isStarted")
            if (!isStarted) {
                onFinish("Bluetooth discovery failed to start")
            }
        }
    }

    fun getDynamicPairingString(accessToken: String): String {
        return DYNAMIC_PAIRING_CONSTANT + accessToken
    }

    fun registerDiscoveryReceiver(context: Context) {
        val filter = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothDevice.ACTION_UUID)
        }
        context.registerReceiver(discoveryBroadcastReceiver, filter)
        isDiscoveryRegistered = true
    }

    private val discoveryBroadcastReceiver = object : BroadcastReceiver() {
        @RequiresPermission(Manifest.permission.BLUETOOTH)
        override fun onReceive(context: Context, intent: Intent) {
            if (BluetoothDevice.ACTION_FOUND == intent.action) {
                Log.d(TAG, "[discoveryBroadcastReceiver]  -------------  BluetoothDevice.ACTION_FOUND  ---------------")
                intent.extras?.keySet()?.forEach { key ->
                    if (key == BluetoothDevice.EXTRA_DEVICE || key == BluetoothDevice.EXTRA_NAME) {
                        Log.d(TAG, "[discoveryBroadcastReceiver] $key = ${intent.extras?.get(key)}")
                    }
                }
                val device =
                    intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                if (device != null) {
                    val address = device.address ?: return
                    if (checkDataLogicDevice(address)) {
                        invalidateDevice(device, context)
                    }
                }
            } else if (rebondForProfileHID && BluetoothAdapter.ACTION_DISCOVERY_FINISHED == intent.action) {
                rebondForProfileHID = false
                val activity = context as? Activity
                activity?.let {
                    Log.d(
                        ContentValues.TAG,
                        "[discoveryBroadcastReceiver] discoveryAndPairDevice again"
                    )
                    discoveryAndPairDevice(activity)
                }
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED == intent.action && !isPairing) {
                statusPairing = BluetoothPairingStatus.Timeout
                onFinish("Discovery finished by bluetooth")
            }
        }
    }

    private fun invalidateDevice(device: BluetoothDevice, context: Context) {
        Log.d(TAG, "[invalidateDevice] ============BEGIN============")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && ActivityCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.d(TAG, "[invalidateDevice] Permission denied => END")
            return
        }
        if (device.name != null && device.name.isNotEmpty()) {
            Log.d(TAG, "[invalidateDevice] found device.name =>" + device.name)
            Log.d(
                TAG, "[invalidateDevice] dynamic: ${SharedPreferenceUtil.getDynamicPairingStr()}"
            )
            if (device.name.equals(SharedPreferenceUtil.getDynamicPairingStr())) {

                deviceName = device.name
                Log.d(
                    TAG,
                    "[invalidateDevice] found dynamic pairing =>" + SharedPreferenceUtil.getDynamicPairingStr()
                )
                managePairing(device, context)
            }
        }
        Log.d(TAG, "[invalidateDevice] ======= END =====")
    }


    private fun stopBluetoothDiscovery(context: Context): Boolean {
        Log.d(TAG, "stopBluetoothDiscovery, isScanning: $isScanning")
        if (isScanning) {
            isScanning = false
            unregisterDiscoveryReceiver(context)
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && ActivityCompat.checkSelfPermission(
                    context, Manifest.permission.BLUETOOTH_SCAN
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                bluetoothAdapter.cancelDiscovery()
            } else {
                bluetoothAdapter.cancelDiscovery()
            }
        }
        return false
    }

    private val bluetoothBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action
            Log.d(TAG, "bluetoothBroadcastReceiver, action: $action")
            if (action == BluetoothDevice.ACTION_BOND_STATE_CHANGED) {
                val bluetoothDevice: BluetoothDevice? =
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

                Log.d(
                    TAG,
                    "[bluetoothBroadcastReceiver] device address: ${bluetoothDevice?.address} " +
                            "--- mCurrentBluetoothDevice address: ${mCurrentBluetoothDevice?.address}"
                )
                if (bluetoothDevice?.address == mCurrentBluetoothDevice?.address) {
                    val currentState =
                        intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR)
                    Log.d(TAG, "bluetoothBroadcastReceiver, bond state: $currentState")
                    if (currentState == BluetoothDevice.BOND_BONDED) {
                        mCurrentBluetoothDevice?.let {
                            if (context != null) {
                                val permissionTemp = ActivityCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.BLUETOOTH_SCAN
                                )
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && permissionTemp != PackageManager.PERMISSION_GRANTED) {
                                    Log.d(TAG, "[bluetoothBroadcastReceiver] Permission denied")
                                    return
                                }
                            }
                            Log.d(TAG, "bonded successfully")
                            if (context != null) {
                                stopBluetoothDiscovery(context)
                            }
                            statusPairing = BluetoothPairingStatus.Successful
                            if (SharedPreferenceUtil.getBTProfile().equals(
                                    BluetoothConstants.SPP_BT_PROFILE
                                )
                            ) {
                                onFinish("Device paired successfully")
                            } else {
                                onFinish("Device connected successfully")
                            }
                        }
                    } else if (currentState == BluetoothDevice.BOND_NONE) {
                        Log.d(TAG, "bonded unbounded")
                        if (context != null) {
                            if (!rebondForProfileHID) {
                                handleBondingFailed(context)
                            }
                        }
                    }
                }
            }
        }
    }

    private val bluetoothHidBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d(TAG, "onReceive bluetoothHidBroadcastReceiver")
            val action = intent?.action
            Log.d(TAG, "action: $action")
            if (action == BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED || action == BluetoothDevice.ACTION_ACL_DISCONNECTED) {
                val currentState = intent.getIntExtra(
                    BluetoothAdapter.EXTRA_CONNECTION_STATE, BluetoothAdapter.STATE_DISCONNECTED
                )
                Log.d(TAG, "currentState: $currentState")
                if (currentState == BluetoothAdapter.STATE_DISCONNECTED) {
                    message = "Connection state: disconnected."
                } else if (currentState == BluetoothAdapter.STATE_CONNECTED) {
                    message = "Connection state: connected."
                    statusPairing = BluetoothPairingStatus.Successful
                }
            }
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private fun managePairing(bluetoothDevice: BluetoothDevice, context: Context) {
        isPairing = true
        removePairingBroadcastReceiver(context)
        val btProfile = SharedPreferenceUtil.getBTProfile()
        Log.d(TAG, "[managePairing] btProfile: $btProfile")

        if (btProfile.equals(BluetoothConstants.HID_BT_PROFILE)) {
            bluetoothProfile = BluetoothProfile.HID
            val filter = IntentFilter()
            filter.addAction(BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED)
            filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED)
            filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            context.registerReceiver(bluetoothHidBroadcastReceiver, filter)
            isBTHidReceiverRegistered = true
        } else if (btProfile.equals(BluetoothConstants.SPP_BT_PROFILE)) {
            unregisterBtHidReceiver(context)
            bluetoothProfile = BluetoothProfile.SPP
        }
        initiateBonding(bluetoothDevice, context)
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private fun initiateBonding(bluetoothDevice: BluetoothDevice, context: Context) {
        Log.d(TAG, "initiateBonding() mCurrentBluetoothDevice = current bluetoothDevice")
        mCurrentBluetoothDevice = bluetoothDevice

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.d(TAG, "BT connect not permitted")
            return
        }

        if (bluetoothDevice.bondState == BluetoothDevice.BOND_BONDED) {
            isAlreadyBonded = true
            if (SharedPreferenceUtil.getBTProfile().equals(
                    BluetoothConstants.SPP_BT_PROFILE
                )
            ) {
                Log.d(TAG, "device is already bonded: ${bluetoothDevice.bondState}")

                val dynamicPairingName = SharedPreferenceUtil.getDynamicPairingStr()
                if (bluetoothDevice.name?.equals(dynamicPairingName, ignoreCase = false) == true) {
                    stopBluetoothDiscovery(context)
                    Log.d(TAG, "found Mac Address => ${bluetoothDevice.address}")
                }
                statusPairing = BluetoothPairingStatus.Successful
                if (SharedPreferenceUtil.getBTProfile().equals(
                        BluetoothConstants.SPP_BT_PROFILE
                    )
                ) {
                    onFinish("Device paired successfully")
                }
            } else if (SharedPreferenceUtil.getBTProfile().equals(
                    BluetoothConstants.HID_BT_PROFILE
                )
            ) {
                Log.d(TAG, "initiateBonding, HID selected, remove bond")
                try {
                    val removeBondMethod =
                        mCurrentBluetoothDevice?.javaClass?.getMethod("removeBond")
                    val isCancelledBond = removeBondMethod?.invoke(mCurrentBluetoothDevice)
                    if (isCancelledBond != null) {
                        Log.d(
                            TAG,
                            "removed bond for current device: $isCancelledBond"
                        )
                        rebondForProfileHID = true
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "error while removing bond $e.printStackTrace()")
                }
                isAlreadyBonded = false
            }
        }

        if (!isAlreadyBonded) {
            initiateCreateBond(bluetoothDevice, context)
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private fun initiateCreateBond(bluetoothDevice: BluetoothDevice, context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && ActivityCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.d(TAG, "initiateCreateBond, BT connect not permitted")
            return
        }
        context.registerReceiver(
            bluetoothBroadcastReceiver, IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        )
        isBTReceiverRegistered = true
        Log.d(TAG, "creating bond")
        bluetoothDevice.createBond()
    }

    private fun handleBondingFailed(context: Context) {
        removePairingBroadcastReceiver(context)
        statusPairing = BluetoothPairingStatus.Unsuccessful
        onFinish("Bonding failed.")
    }

    fun unregisterDiscoveryReceiver(context: Context) {
        if (isDiscoveryRegistered) {
            try {
                Log.d(
                    TAG,
                    "[unregisterDiscoveryReceiver] unregisterReceiver(discoveryBroadcastReceiver)"
                )
                context.unregisterReceiver(discoveryBroadcastReceiver)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "[unregisterDiscoveryReceiver] Receiver not registered, ignoring")
            } finally {
                isDiscoveryRegistered = false
            }
        }
    }

    fun removePairingBroadcastReceiver(context: Context) {
        if (isBTReceiverRegistered) {
            try {
                Log.d(
                    TAG,
                    "[removePairingBroadcastReceiver] unregisterReceiver(bluetoothBroadcastReceiver)"
                )
                context.unregisterReceiver(bluetoothBroadcastReceiver)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "[removePairingBroadcastReceiver] Receiver not registered, ignoring")
            } finally {
                isBTReceiverRegistered = false
            }
        }
    }

    fun unregisterBtHidReceiver(context: Context) {
        if (isBTHidReceiverRegistered) {
            try {
                Log.d(
                    TAG,
                    "[unregisterBtHidReceiver] unregisterReceiver(bluetoothHidBroadcastReceiver)"
                )
                context.unregisterReceiver(bluetoothHidBroadcastReceiver)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "Receiver not registered, ignoring")
            } finally {
                isBTHidReceiverRegistered = false
            }
        }
    }

    fun clearConnection(context: Context) {
        mCurrentBluetoothDevice = null
        isAlreadyBonded = false
        unregisterBtHidReceiver(context)
        removePairingBroadcastReceiver(context)
        unregisterDiscoveryReceiver(context)
    }

    fun onFinish(msg: String) {
        Log.d(TAG, "[onFinish] message: $msg")
        isFinished = true
        message = msg
    }

    fun getMessage(): String {
        return message
    }

    fun checkDataLogicDevice(macAddress: String): Boolean {
        if (macAddress.startsWith(DATALOGIC_MAC_PREFIX, ignoreCase = true)) {
            Log.d(ContentValues.TAG, "[checkDataLogicDevice] Found Datalogic device")
            return true
        }
        return false
    }

    companion object
}

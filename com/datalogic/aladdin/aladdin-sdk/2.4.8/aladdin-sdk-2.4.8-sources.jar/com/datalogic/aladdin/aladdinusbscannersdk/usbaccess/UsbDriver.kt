package com.datalogic.aladdin.aladdinusbscannersdk.usbaccess

import android.content.Context
import android.hardware.usb.UsbManager
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.model.DatalogicDeviceManager.onStatusListener
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.CAN_NOT_FIND_DEVICE
import com.google.gson.JsonParser
import com.hoho.android.usbserial.driver.CdcAcmSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.IOException

class UsbDriver {
    private val _probeTable = UsbSerialProber.getDefaultProbeTable()
    private val TAG = "UsbDeviceDetection"

    fun findDriver(productIdString: String, vendorIdString: String, usbManager: UsbManager, context: Context): UsbSerialDriver? {
        // Add all drivers from the JSON file
        addDriver(productIdString, vendorIdString, context)

        // Find available drivers
        val prober = UsbSerialProber(_probeTable)
        val availableDrivers = prober.findAllDrivers(usbManager)

        if (availableDrivers.isEmpty()) {
            Log.e(TAG, "No available drivers found")
            onStatusListener?.onError(CAN_NOT_FIND_DEVICE)
            return null
        }

        Log.d(TAG, "Found ${availableDrivers.size} available drivers")

        val driver = findDriverByProductID(availableDrivers, productIdString)

        if (driver == null) {
            Log.e(TAG, "Could not find driver for product ID: $productIdString")
            onStatusListener?.onError(CAN_NOT_FIND_DEVICE)
            return null
        }

        Log.d(TAG, "Successfully found driver for product ID: $productIdString")
        return driver
    }

    fun addDriver(productIdString: String, vendorIdString: String, context: Context) {
        val vendorIdInt = Integer.parseInt(vendorIdString, 10)
        val productIdInt = Integer.parseInt(productIdString, 10)
        _probeTable.addProduct(vendorIdInt, productIdInt, CdcAcmSerialDriver::class.java)
    }

    /*
    fun addAllDrivers(context: Context) {
        try {
            context.assets.open("productDetails.json").use { inputStream ->
                val jsonString = inputStream.bufferedReader().use { it.readText() }
                val jsonObject = JsonParser.parseString(jsonString).asJsonObject

                val productEntries = jsonObject.getAsJsonArray("productEntries")
                if (productEntries.size() > 0) {
                    val products = productEntries.get(0).asJsonObject.getAsJsonArray("product")

                    // Count for logging
                    var comProductCount = 0

                    for (i in 0 until products.size()) {
                        val product = products.get(i).asJsonObject
                        val productId = product.get("productId").asString
                        val vendorId = product.get("vendorId").asString
                        val type = product.get("type").asString

                        // Only add COM type products
                        if (type == "COM") {
                            try {
                                val vendorIdInt = Integer.parseInt(vendorId, 10)
                                val productIdInt = Integer.parseInt(productId, 10)
                                _probeTable.addProduct(vendorIdInt, productIdInt, CdcAcmSerialDriver::class.java)
                                comProductCount++
                                Log.d(TAG, "Added COM product: vendorId=$vendorId, productId=$productId")
                            } catch (e: NumberFormatException) {
                                Log.e(TAG, "Invalid format for vendorId=$vendorId or productId=$productId: ${e.message}")
                            }
                        }
                    }

                    Log.d(TAG, "Added $comProductCount COM products from productDetails.json")
                } else {
                    Log.w(TAG, "No product entries found in productDetails.json")
                }
            }
        } catch (e: IOException) {
            Log.e(TAG, "IOException while reading productDetails.json: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Exception while processing productDetails.json: ${e.message}")
        }
    }
    */

    // Function to find a product by ID using find
    private fun findDriverByProductID(productList: List<UsbSerialDriver>, productId: String):
            UsbSerialDriver? {
        return productList.find { it.device.productId.toString() == productId }
    }
}
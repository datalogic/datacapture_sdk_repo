package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.s37

import java.io.BufferedReader
import java.io.File
import java.io.FileReader

/**
 * Parser for S37 firmware files
 */
class S37FirmwareParser(private val file: File) {
    companion object {
        private const val RADIX = 16
    }

    data class S37Record(
        val recordType: Int,
        val address: Int,
        val data: ByteArray,
        val checksum: Byte
    )

    /**
     * Parse the S37 firmware file and return the firmware data
     */
    fun parse(file: File?): S37FirmwareData {
        val headerLines = mutableListOf<String>()
        val records = mutableListOf<S37Record>()
        
        BufferedReader(FileReader(file)).use { reader ->
            var line: String?
            
            // Read header section (lines starting with S0)
            while (reader.readLine().also { line = it } != null && line?.startsWith("S0") == true) {
                headerLines.add(line!!)
            }
            
            // Parse header information
            val pid = getHeaderData(headerLines, "PID")
            val release = getHeaderData(headerLines, "App")
            val configId = getHeaderData(headerLines, "Cfg")
            val frsSwid = getHeaderData(headerLines, "SWID")
            val hhsSwid = getHhsSwid(headerLines)
            val hhsPassthroughPid = getHHSPassthroughPid(headerLines)
            
            return S37FirmwareData(
                pid = pid,
                release = release,
                configId = configId,
                frsSwid = frsSwid,
                hhsSwid = hhsSwid,
                hhsPassthroughPid = hhsPassthroughPid
            )
        }
    }

    private fun getHeaderData(lines: List<String>, dataName: String): String? {
        val searchString = " $dataName="
        
        for (line in lines) {
            if (line.contains(searchString)) {
                val startIndex = line.indexOf(searchString) + searchString.length
                val endIndex = line.indexOf(' ', startIndex).let { if (it == -1) line.length else it }
                val out = line.substring(startIndex, endIndex)
                return if (out == "\"\"") "" else out
            }
        }
        return null
    }

    private fun getHhsSwid(lines: List<String>): String? {
        val searchString = "S006000004" // S0 <length> <address> 04
        
        for (line in lines) {
            if (line.startsWith(searchString) && line.length == 16) {
                return line.substring(10, 14)
            }
        }
        return null
    }

    private fun getHHSPassthroughPid(lines: List<String>): String? {
        if (lines.size > 1 && lines[1].contains("APID")) {
            // Find first line that starts with REM
            val startingLine = lines.indexOfFirst { it.contains("REM") }
            if (startingLine >= 0) {
                val remLines = lines.subList(startingLine, lines.size)
                return getHeaderData(remLines, "PID")
            }
        }
        return null
    }
} 
package com.datalogic.aladdin.aladdinusbscannersdk.model

data class FRSInterface(val name: String, val value: String) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is FRSInterface) return false
        return value == other.value
    }

    override fun hashCode(): Int {
        return value.hashCode()
    }
}

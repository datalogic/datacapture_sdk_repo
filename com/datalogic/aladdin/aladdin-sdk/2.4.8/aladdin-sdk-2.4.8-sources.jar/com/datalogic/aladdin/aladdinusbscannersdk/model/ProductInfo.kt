package com.datalogic.aladdin.aladdinusbscannersdk.model

data class Interface(
    val type: String,
    val productId: String
)

data class Product(
    val model: List<String>,
    val deviceType: String,
    val deviceInterface : List<Interface>,
    val vendorId: String
)

data class ProductEntry(
    val product: List<Product>
)

data class ProductResponse(
    val version: String,
    val productEntries: List<ProductEntry>
)


data class InformationItem(
    val key: String,
    val name: String,
    val value: String? = null,
    val mask: Int = 3,
    val type: Int? = null,
    val complexValue: Map<String, String>? = null,
    val complexIdentifier: Map<String, String>? = null
)

data class HealthItem(
    val key: String,
    val name: String,
    val value: String? = null,
    val mask: Int = 3,
    val complexIdentifier: Map<String, String>? = null
)

data class StatisticsItem(
    val key: String,
    val name: String,
    val value: String? = null,
    val mask: Int = 3,
    val type: Int? = null
)

data class Data(
    val Information: List<InformationItem>,
    val Health: List<HealthItem>,
    val Statistics: List<StatisticsItem>
)
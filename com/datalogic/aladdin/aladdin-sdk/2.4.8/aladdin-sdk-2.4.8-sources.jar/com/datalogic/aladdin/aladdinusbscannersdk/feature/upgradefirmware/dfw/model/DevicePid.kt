package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model

import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.PROTOCOL_1D11
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.PROTOCOL_1D12

class DevicePid(private val devPid: String) {

    fun isSupportedIn(pidDfw: String, protocol: String): Boolean {
        println("$devPid.isSupportedIn($pidDfw, $protocol)")

        return if (protocol == PROTOCOL_1D11 || protocol == PROTOCOL_1D12) {
            val valDevPid = Integer.decode(devPid) and 0x0000FFFF
            val valDfwPid = Integer.decode(pidDfw) and 0x0000FFFF
            baseOf(valDevPid) == baseOf(valDfwPid) && versionOf(valDevPid) <= versionOf(valDfwPid)
        } else {
            devPid.equals(pidDfw, ignoreCase = true)
        }
    }

    fun isSupportedIn12(pidDfw: String, protocol: String, pidMask: String): Boolean {
        println("$devPid.isSupportedIn($pidDfw, $protocol)")

        return if (protocol == PROTOCOL_1D12) {
            val valDevPid = Integer.decode(devPid) and 0x0000FFFF
            val valDfwPid = Integer.decode(pidDfw) and 0x0000FFFF
            val valPidMask = Integer.decode(pidMask) and 0x0000FFFF
            baseOf12(valDevPid, valPidMask) == baseOf12(valDfwPid, valPidMask) &&
                    versionOf(valDevPid) <= versionOf(valDfwPid)
        } else {
            false
        }
    }

    private fun baseOf(value: Int): Int {
        return value and 0x0000FFF8
    }

    private fun baseOf12(value: Int, pidMask: Int): Int {
        return value and pidMask
    }

    private fun versionOf(value: Int): Int {
        return value and 0x00000007
    }
}

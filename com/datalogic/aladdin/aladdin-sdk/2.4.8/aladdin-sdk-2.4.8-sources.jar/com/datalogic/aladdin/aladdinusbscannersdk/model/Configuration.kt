package com.datalogic.aladdin.aladdinusbscannersdk.model

data class Configuration(
    val tagName: String,
    val value: String
)
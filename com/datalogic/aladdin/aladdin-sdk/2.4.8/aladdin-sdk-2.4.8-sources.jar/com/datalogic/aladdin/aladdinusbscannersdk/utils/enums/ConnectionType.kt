package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class ConnectionType {
    USB_COM,
    USB_OEM,
    USB_COMSC
}

fun convertInterfaceFromJsonToEnum(jsonValue: String): ConnectionType {
    return ConnectionType.valueOf(jsonValue)
}

fun getArrayOfConnectionType(): Array<ConnectionType> {
    return ConnectionType.entries.toTypedArray()
}
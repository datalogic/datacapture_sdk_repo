package com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils

import com.datalogic.aladdin.aladdinusbscannersdk.model.Configuration
import java.util.Locale
import org.apache.commons.lang3.StringUtils

object SmartUtil {
    fun splitAndTrim(input: String?, delimiter: String = ","): ArrayList<String> {
        return input?.split(delimiter)
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.let { ArrayList(it) }
            ?: arrayListOf()
    }

    fun getHexInt(hex: String): Int {
        var hex = hex
        if (hex.startsWith("0x")) {
            hex = hex.substring(2)
        }
        return hex.toInt(16)
    }

    fun printArray(array: Array<Any?>?): String {
        return ("[" + StringUtils.join(array, ", ")).toString() + "]"
    }

    fun bytesToHex0X(data: ByteArray): String {
        val buf = StringBuffer()
        for (i in data.indices) {
            val result = Integer.toHexString(data[i].toInt()).uppercase(
                Locale.getDefault()
            ).customLeftPad(2, '0')
            buf.append(
                "0x$result"
            )
            buf.append(" ")
        }
        return buf.toString()
    }

    /**
     * Convert a byte[] array to hex string format.
     *
     * e.g. {0x00, 0x47} -> "0x0047"
     *
     * @return result String buffer in String format
     * @param data byte[] buffer to convert to string format
     */
    fun bytesToHex(data: ByteArray?): String {
        if (data == null) {
            return "null"
        }
        val buf = StringBuffer()
        buf.append("0x")
        for (i in data.indices) {
            buf.append(
                Integer.toHexString(data[i].toInt()).uppercase(
                    Locale.getDefault()).customLeftPad(2, '0')
            )
        }
        return buf.toString()
    }

    /**
     * Convert a byte[] array to hex string format.
     *
     * e.g. {0x00, 0x47} -> "00 47"
     *
     * @return result String buffer in String format
     * @param data byte[] buffer to convert to string format
     */
    fun printBytesToHex(data: ByteArray?): String {
        if (data == null) {
            return "null"
        }
        val buf = StringBuffer()
        for (i in data.indices) {
            buf.append(
                Integer.toHexString(data[i].toInt()).uppercase(
                    Locale.getDefault()).customLeftPad(2, '0')
            ).append(" ")
        }
        return buf.toString()
    }

    fun printBytesToHex(data: String): String {
        return printBytesToHex(data.toByteArray())
    }

    fun bigEndian(s: String): String {
        var s = s
        if (s.length % 2 != 0) {
            s = "0$s"
        }
        var be = ""
        var i = s.length - 2
        while (i >= 0) {
            be += s.substring(i, i + 2)
            i -= 2
        }
        return be
    }

    fun addHex(address: String, count: Long): String {
        var addressInt = address.toInt(16)
        addressInt += count.toInt()
        val hexString = Integer.toHexString(addressInt).uppercase(Locale.getDefault())
        return hexString.customLeftPad(address.length, '0')
    }

    fun removeComment(str: String?): String {
        var uncom = ""
        if (str != null) {
            uncom = str.replace("/\\*.*\\*/".toRegex(), "")
            uncom = uncom.replace("/\\*.*$".toRegex(), "")
            uncom = uncom.replace("^.*\\*/".toRegex(), "")
        }

        return uncom
    }

    fun hexStringToByteArray(s: String): ByteArray {
        val b = ByteArray(s.length / 2)
        for (i in b.indices) {
            val index = i * 2
            val v = s.substring(index, index + 2).toInt(16)
            b[i] = v.toByte()
        }
        return b
    }

    /**
     * Convert a byte[] array to hex string format.
     *
     * e.g. {0x00, 0x47} -> "0047"
     *
     * @return result String buffer in String format
     * @param data byte[] buffer to convert to string format
     */
    fun byteArrayToHexString(data: ByteArray?): String? {
        if (data == null) {
            return null
        }

        val sb = StringBuilder()
        for (b in data) {
            sb.append(String.format("%02X", b))
        }
        return sb.toString()
    }

    /**
     * Convert a byte[] array to hex string format.
     *
     * e.g. {0x00, 0x47} -> "00 47"
     *
     * @return result String buffer in String format
     * @param data byte[] buffer to convert to string format
     */
    fun byteArrayToHexStringWithSpaces(data: ByteArray?): String? {
        if (data == null) {
            return null
        }

        val sb = StringBuilder()
        for (b in data) {
            sb.append(String.format("%02X", b)).append(" ")
        }
        return sb.toString()
    }

    /**
     * Helper function to convert byte array to hex string for logging
     */
    fun byteArrayToHexStringForLog(data: ByteArray?): String {
        if (data == null || data.isEmpty()) return "[]"

        val sb = StringBuilder("[")
        for (i in data.indices) {
            sb.append(String.format("%02X", data[i]))
            if (i < data.size - 1) sb.append(" ")
        }
        sb.append("]")
        return sb.toString()
    }

    /**
     * Convert a byte[] array to an ascii string while preserving any bytes that
     * cannot be printed.
     *
     * @return result String buffer in String format
     * @param bytes byte[] buffer to convert to string format
     */
    fun makePrintableString(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            if ((b < 0x20) || (b > 0x7F)) {
                sb.append("{0x")
                sb.append(String.format("%02X", b))
                sb.append("}")
            } else {
                sb.append(Char(b.toUShort()))
            }
        }
        return sb.toString()
    }

    /**
     * Convert a byte[] array to an ascii string while preserving any bytes that
     * cannot be printed.
     *
     * @return result String buffer in String format
     * @param bytes byte[] buffer to convert to string format
     */
    fun convertAsciiInQuotes(cmdToSend: String): String {
        var cmdToSend = cmdToSend
        if (cmdToSend.contains("\"")) {
            var quotationIndices: MutableList<Int> = ArrayList()
            for (i in 0..<cmdToSend.length) {
                val c = cmdToSend[i]
                // record the position of the quote mark
                if (c == '\"') {
                    quotationIndices.add(i)
                }
            }
            // now check for balance.
            if (quotationIndices.size % 2 != 0) {
                throw java.lang.Exception("Quotation marks in message are unbalanced.")
            }
            // Now convert the quoted values from ascii to the equivalent hex format and replace in the string.
            val replacements = HashMap<String, String>()
            while (quotationIndices.size > 0) {
                val start = quotationIndices[0]
                val end = quotationIndices[1]
                quotationIndices = quotationIndices.subList(2, quotationIndices.size)
                val temp = cmdToSend.substring(start, end + 1)
                replacements[temp] =
                    CharsUtil.asciiStringToHexString(temp.substring(1, temp.length - 1))
            }
            for ((key, value) in replacements) {
                cmdToSend = cmdToSend.replace(key, value)
            }
        }
        return cmdToSend
    }

    fun getDifferencesFRSConfig(
        list1: List<Configuration>,
        list2: List<Configuration>
    ): List<Configuration> {
        return list1.filterNot { item1 ->
            list2.any { item2 ->
                item1.tagName == item2.tagName && item1.value == item2.value
            }
        }
    }

    fun String.customLeftPad(length: Int, padChar: Char = ' '): String {
        if (this.length >= length) {
            return this
        }
        val sb = StringBuilder(length)
        repeat(length - this.length) {
            sb.append(padChar)
        }
        sb.append(this)
        return sb.toString()
    }
}
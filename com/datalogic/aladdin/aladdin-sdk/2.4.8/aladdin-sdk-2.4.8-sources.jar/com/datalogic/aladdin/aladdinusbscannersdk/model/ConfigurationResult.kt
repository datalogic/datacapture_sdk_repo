package com.datalogic.aladdin.aladdinusbscannersdk.model

data class ConfigurationResult(
    val isSuccess: Boolean,
    val errorCommands: List<CommandError> = emptyList()
)

data class CommandError(
    val rowNumber: Int,
    val rowData: String,
    val errorMessage: String = ""
)

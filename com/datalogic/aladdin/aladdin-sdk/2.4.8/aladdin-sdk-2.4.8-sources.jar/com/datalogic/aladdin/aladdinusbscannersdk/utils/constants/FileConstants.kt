package com.datalogic.aladdin.aladdinusbscannersdk.utils.constants

class FileConstants {
    companion object {
        const val S37_FILE_TYPE = "S37"
        const val SWU_FILE_TYPE = "SWU"
        const val DFW_FILE_TYPE = "DFW"
    }
}
package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class BluetoothProfile {
    HID,
    SPP
}
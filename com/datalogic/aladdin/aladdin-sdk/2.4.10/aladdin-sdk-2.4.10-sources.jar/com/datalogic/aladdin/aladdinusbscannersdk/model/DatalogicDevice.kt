package com.datalogic.aladdin.aladdinusbscannersdk.model

import ImageCaptureFRS
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.FirmwareUpdater
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.DeviceHidForFWU
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.UpgradeDFW
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.s37.FirmwareS37FRSUpdater
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.s37.FirmwareS37HHSUpdater
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.swu.FirmwareSWUUpdater
import com.datalogic.aladdin.aladdinusbscannersdk.model.DatalogicDeviceManager.onStatusListener
import com.datalogic.aladdin.aladdinusbscannersdk.model.DatalogicDeviceManager.openUsbDevice
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.REPORT_SCALE_CONFIG
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.RESET_DEVICE_CMD
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.SCALE_STATUS_CMD
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.STATUS_NOT_READY
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.STATUS_OVER_CAPACITY
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.STATUS_STABLE_NON_ZERO
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.STATUS_STABLE_ZERO
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.STATUS_UNDER_ZERO
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.STATUS_UNSTABLE
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.WEIGHT_REQUEST_CMD
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.WEIGHT_REQUEST_CMD_OEM_ENGLISH_WEIGHT
import com.datalogic.aladdin.aladdinusbscannersdk.model.ScaleData.Companion.WEIGHT_REQUEST_CMD_OEM_METRIC_WEIGHT
import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.HostOem
import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import com.datalogic.aladdin.aladdinusbscannersdk.utils.LabelParsing
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.addChecksum
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.formatLine
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.parseScannerResponse
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.CopyToLevel
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSDevice
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSScannerTypes
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.HHSDevice
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.IFType
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.ImageCaptureHHS
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.dioString
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.findKeyInHealthList
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.findKeyInInformationList
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.findKeyInStatisticsList
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.byteArrayToHexString
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.byteArrayToHexStringForLog
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.byteArrayToHexStringWithSpaces
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.convertAsciiInQuotes
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.hexStringToByteArray
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.makePrintableString
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.UsbUtils
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.UsbUtils.Companion.addKeyValueIfAbsent
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.CLAIM_FAILURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.COMPANY_NAME
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.CONFIG_ERR_FAILURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.DFW
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.ERR_TIMEOUT
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.FAILURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.OPEN_FAILURE
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.S37
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.SUCCESS
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.SWU
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.USB_PERMISSION_DENIED
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.VERSION_SDK
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants.READ_IDENTIFICATION
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.FRSContants.READ_VERSION
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.ACTION_USB_PERMISSION
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.BYTE_DATA_00
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.BYTE_DATA_0B
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.BYTE_DATA_10
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.HEX_FORMAT
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.NUMERIC_4
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.NUMERIC_DATA_LENGTH_64
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.BarcodeType
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.ConfigurationFeature
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.ConnectionType
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DIOCmdValue
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DeviceConnectType
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DeviceStatus
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DeviceType
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.ScaleUnit
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.getArrayOfConnectionType
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.CradleListener
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.UsbDioListener
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.UsbScaleListener
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.UsbScanListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean


enum class LabelCodeType(val code: String) {
    USA("USA"),
    EU("EU"),
    COMSC("COMSC"),
    NONE("NONE");
}

enum class LabelIDControl(val code: String) {
    DISABLE("DISABLE"),
    PREFIX("PREFIX"),
    SUFFIX("SUFFIX");
}

class DatalogicDevice(
    val usbManager: UsbManager, val usbDevice: UsbDevice,
    val deviceType: DeviceType, var connectionType: ConnectionType
) {
    companion object {
        const val DEVICE_NOT_SUPPORT = "Device Not Support"
    }

    var status: MutableState<DeviceStatus> = mutableStateOf(DeviceStatus.CLOSED)
        private set // Make the setter private if only ViewModel should change it via a method

    val id: String = usbDevice.deviceName
    private val DisableTransmissionOfMessagesOverCDCControlEndpoint =
        byteArrayOf(0x00, 0x10, 0x07, 0x4B, 0x00)
    private val applyConfigToCurrentInterface = "\$As,r02\r".toByteArray()
    private val HandHeldResetDevice = "\$R\r".toByteArray()
    private val S_MODE = "\$S\r".toByteArray()
    private val EXIT_S_MODE = "\$s\r".toByteArray()
    private val RESET_HID = "\$i\r".toByteArray()
    private var TAG: String = DatalogicDevice::class.java.simpleName
    var displayName: String =
        "${usbDevice.productName}-${usbDevice.productId}-${deviceType}-${connectionType}"

    private var jobReadingStatus: AtomicBoolean = AtomicBoolean(true)
    private var onUsbScanListener: UsbScanListener? = null
    private var onUsbDioListener: UsbDioListener? = null
    private var onUsbScaleListener: UsbScaleListener? = null
    private var onCradleListener: CradleListener? = null

    // The DeviceManager is the single source of truth for device status
    private val serviceSerial: ServiceSerial = ServiceSerial()
    private val hostOem: HostOem = HostOem()
    private val frsDevice: FRSDevice = FRSDevice()
    private val imageCaptureHHS: ImageCaptureHHS = ImageCaptureHHS()
    private val imageCaptureFRS: ImageCaptureFRS = ImageCaptureFRS("${usbDevice.productId}")

    private var startScale = AtomicBoolean(false)
    private var unitScale: ScaleUnit = ScaleUnit.NONE
    private var enableScale: Boolean = false

    private var isScaleAvailable: Boolean = false

    private val codeIdentifier = "AE"
    private val copyToLevel = CopyToLevel.COPY_TO_USER.toString()
    private var firmwareUpdater: FirmwareUpdater? = null
    private var isEnglishWeighMode: Boolean = false
    private var labelCodeType: LabelCodeType = LabelCodeType.NONE
    private var labelIDControl: LabelIDControl = LabelIDControl.DISABLE
    private var checkingInterface: Boolean = false
    private var supportCheckDocking: Boolean = false
    private var timerCheckDocking = 2000
    private var autoCheckDocking = AtomicBoolean(false)
    private var isLinked: Boolean = false
    private var isDocked: Boolean = false

    var connectType: DeviceConnectType = DeviceConnectType.USB

    /**
     * Safely release and close a device connection
     */

    fun startScale(): Boolean {
        startScale.set(true)
        return true
    }

    fun stopScale(): Boolean {
        startScale.set(false)
        return true
    }

    fun isScaleAvailable(): Boolean {
        return isScaleAvailable
    }

    /**
     * Helper method to determine if received data is from scale
     * based on the protocol format (S14 prefix)
     */
    private fun isScaleData(data: ByteArray): Boolean {
        val str = String(data, StandardCharsets.UTF_8).trim()
        return str.startsWith("S14")
    }

    // Public methods for UI access
    /**
     * Get the current label code type setting
     * @return Current LabelCodeType value
     */
    fun getCurrentLabelCodeType(): LabelCodeType {
        return labelCodeType
    }

    /**
     * Set the label code type for barcode parsing
     * @param labelCodeType The LabelCodeType to use for parsing
     */
    fun setCurrentLabelCodeType(labelCodeType: LabelCodeType) {
        this.labelCodeType = labelCodeType
        Log.d(TAG, "Label code type set to: ${labelCodeType.code}")
    }

    /**
     * Get the current label ID control setting
     * @return Current LabelIDControl value
     */
    fun getCurrentLabelIDControl(): LabelIDControl {
        return labelIDControl
    }

    /**
     * Set the label ID control for barcode parsing
     * @param labelIDControl The LabelIDControl to use for parsing
     */
    fun setCurrentLabelIDControl(labelIDControl: LabelIDControl) {
        this.labelIDControl = labelIDControl
        Log.d(TAG, "Label ID control set to: ${labelIDControl.code}")
    }

    fun releaseAndCloseQuietly() {
        try {
            releaseUsbInterface()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing interface", e)
        }

        try {
            closeUsbConnection()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing connection", e)
        }
    }

    /**
     * Request permission to access the USB device
     */
    fun requestPermissionForDevice(device: UsbDevice, context: Context) {
        val permissionIntent = PendingIntent.getBroadcast(
            context, 0, Intent(ACTION_USB_PERMISSION).setPackage(context.packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        usbManager.requestPermission(device, permissionIntent)
    }

    /**
     * Open a USB connection to the given device
     * This is the first step in the complete device opening sequence
     */
    fun openUsbConnection(context: Context): Int {
        // Set openUsbDevice to get the permission event
        openUsbDevice = this
        // Check if permission is granted to communicate with the device
        if (usbManager.hasPermission(usbDevice)) {
            // Open a connection to the device using HHRSerialManager
            tryToOpenUsbConnection(context)
            if (usbDevice.productName != null && connectionType != ConnectionType.USB_OEM &&
                usbDevice.productName?.contains("Magellan 9800i") == true) {
                val result = checkActualConnectionType(context)
                if (result == FAILURE) {
                    Log.e(TAG, "Failed to determine actual connection type")
                    onStatusListener?.onError(OPEN_FAILURE)
                    return FAILURE
                }
                displayName = "${usbDevice.productName}-${usbDevice.productId}-${deviceType}-${connectionType}"
                Log.d(TAG, "Connection opened to device: $displayName")
            }

            if ((connectionType == ConnectionType.USB_COM && serviceSerial.usbDeviceServiceConnection != null) ||
                (connectionType == ConnectionType.USB_OEM && hostOem.usbDeviceConnection != null)
            ) {

                Log.d(TAG, "Connection opened to device: $this")
                return SUCCESS
            } else if (connectionType == ConnectionType.USB_COMSC && deviceType == DeviceType.FRS && serviceSerial.usbDeviceServiceConnection != null) {
                // Disable transmission of messages over the CDC Control endpoint to avoid cannot receive data from SC_COM host
                val fullCmd = frsDevice.createFullFRSCommand(
                    DisableTransmissionOfMessagesOverCDCControlEndpoint
                )
                val disableCDCControlResult = serviceSerial.sendReceive(fullCmd, 1000, 1000)
                Log.d(
                    TAG,
                    "Disable CDC Control Endpoint Result: ${disableCDCControlResult?.contentToString()}"
                )
                return SUCCESS
            } else {
                onStatusListener?.onError(OPEN_FAILURE)
                Log.e(TAG, "Failed to open connection to device: $this")
                return FAILURE
            }
        } else {
            Log.e(TAG, "Permission not granted to open connection to device: $this")
            requestPermissionForDevice(usbDevice, context)
            return USB_PERMISSION_DENIED
        }
    }

    private fun tryToOpenUsbConnection(context: Context): Int {
        try {
            if (connectionType == ConnectionType.USB_COM || connectionType == ConnectionType.USB_COMSC) {
                if (!serviceSerial.open(
                        usbManager,
                        usbDevice.productId.toString(),
                        usbDevice.vendorId.toString(),
                        context
                    )
                ) {
                    // Clean up failed connection
                    serviceSerial.usbDeviceServiceConnection?.close()
                    serviceSerial.usbDeviceServiceConnection = null
                    serviceSerial.usbDeviceHostConnection?.close()
                    serviceSerial.usbDeviceHostConnection = null
                }
                return SUCCESS
            } else {
                // For OEM devices
                hostOem.usbDeviceConnection = usbManager.openDevice(usbDevice)
                return SUCCESS
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception opening USB connection", e)
            onStatusListener?.onError(OPEN_FAILURE)
            FAILURE
        }
        return FAILURE
    }

    private fun checkActualConnectionType(
        context: Context
    ): Int {
        var identificationInfo = ""
        var currentInterface: String? = null
        val triedConnectionTypes = mutableSetOf<ConnectionType>()
        val avalableConnectionTypes: Array<ConnectionType> = getArrayOfConnectionType()

        checkingInterface = true
        while (currentInterface == null) {
            identificationInfo = dioCommand(DIOCmdValue.IDENTIFICATION, "", context)
            if (identificationInfo == "" || identificationInfo.equals("Command Executed Successfully")) {
                Log.w(TAG, "No identification response received, retrying...")

                // Find next untried connection type
                val nextConnectionType =
                    avalableConnectionTypes.firstOrNull { availableConnectionType ->
                        availableConnectionType !in triedConnectionTypes
                    }

                if (nextConnectionType == null) {
                    Log.e(TAG, "All connection types exhausted, unable to establish connection")
                    return FAILURE // Return immediately when all types are exhausted
                }

                connectionType = nextConnectionType

                triedConnectionTypes.add(connectionType)

                Log.d(
                    TAG,
                    "Retrying to open USB connection with new connection type: $connectionType"
                )
                tryToOpenUsbConnection(context)
                continue
            }

            currentInterface = extractInterface(identificationInfo, context)
        }

        checkingInterface = false

        return SUCCESS
    }

    private fun extractInterface(result: String, context: Context): String? {
        if (result.isEmpty()) {
            return null
        }
        // Parse the DIO identification response to find the Interface field
        // Response format: "key+value {name:value}, key+value {name:value}, ..."
        // For Interface field: "I47 {Interface:USB-COM}"

        val segments = result.split(", ")

        for (segment in segments) {
            // Look for segments that contain "Interface:" in the description part
            if (segment.contains("{Interface:")) {
                // Extract the interface value from the format "I47 {Interface:USB-COM}"
                val interfaceMatch = Regex("\\{Interface:([^}]+)\\}").find(segment)
                if (interfaceMatch != null) {
                    val interfaceValue = interfaceMatch.groupValues[1]
                    Log.d(TAG, "Extracted interface value: $interfaceValue")
                    return interfaceValue
                }
            }
        }
        Log.w(TAG, "Interface field not found in DIO response: $result")
        return null
    }

    /**
     * Full device open operation - opens, claims, and enables the device
     */
    fun openDevice(context: Context): Int {
        val deviceId = usbDevice.productId.toString()
        Log.i(TAG, "Opening device: $deviceId")

        try {
            // Close device first to ensure clean state
            if (status.value != DeviceStatus.CLOSED) {
                closeDevice(context)
            }

            // Step 1: Open USB connection
            val openResult = openUsbConnection(context)
            if (openResult != SUCCESS) {
                Log.e(TAG, "Failed to open connection")
                return FAILURE
            }

            // Step 2: Claim interface
            val claimResult = claimUsbInterface(context)
            if (claimResult != SUCCESS) {
                Log.e(TAG, "Failed to claim interface")
                closeUsbConnection()
                return FAILURE
            }

            // Step 3: Turn on scale flag to display Scale section on UI
            if (deviceType == DeviceType.FRS && (connectionType == ConnectionType.USB_COMSC || connectionType == ConnectionType.USB_OEM)) {
                checkScale()
            }

            // Set isScaleAvailable based on unitScale
            if (unitScale != ScaleUnit.NONE) {
                isScaleAvailable = true
            } else {
                isScaleAvailable = false
            }

            jobReadingStatus.set(true)
            isDeviceSupportCheckDocking()
            usbReadingCoroutine()

            // Successfully opened
            status.value = DeviceStatus.OPENED
            onStatusListener?.onStatus(deviceId, DeviceStatus.OPENED, usbDevice.deviceName)
            // Enable device
            dioCommand(DIOCmdValue.ENABLE_SCANNER, "", context)

            // Step 4: Read Identification to read error reset (FRS Service Port)
            if (deviceType == DeviceType.FRS && displayName.contains("ServicePort", true)) {
                val commandToSend = frsDevice.createFullFRSCommand(READ_IDENTIFICATION)
                val response = serviceSerial.sendReceive(commandToSend, 700, 700)
                if (response != null && response[0].toInt() == 22) {
                    Log.d(TAG, "Device has been error reset")
                }
            }
            return SUCCESS
        } catch (e: Exception) {
            Log.e(TAG, "Exception opening device", e)
            try {
                closeDevice(context)
            } catch (ex: Exception) {
                Log.e(TAG, "Error during cleanup", ex)
            }
            return FAILURE
        }
    }

    /**
     * Full device close operation - disables, releases, and closes the device
     */
    fun closeDevice(context: Context): Int {
        val deviceId = usbDevice.productId.toString()
        Log.i(TAG, "Closing device: $deviceId")

        try {
            // Cancel reading jobs
            jobReadingStatus.set(false)

            // Already closed
            if (status.value == DeviceStatus.CLOSED) {
                return SUCCESS
            }
            dioCommand(
                DIOCmdValue.DISABLE_SCANNER, "", context
            )
            // Step 2: Release interface
            val releaseResult = releaseUsbInterface()
            if (releaseResult != SUCCESS) {
                Log.w(TAG, "Warning: Failed to release interface")
            }

            // Step 3: Close connection
            val closeResult = closeUsbConnection()
            if (closeResult != SUCCESS) {
                Log.w(TAG, "Warning: Failed to close connection")
            }

            // Update status regardless of individual step results
            openUsbDevice = null
            status.value = DeviceStatus.CLOSED
            onStatusListener?.onStatus(deviceId, DeviceStatus.CLOSED, usbDevice.deviceName)
            supportCheckDocking = false
            return SUCCESS
        } catch (e: Exception) {
            Log.e(TAG, "Exception closing device", e)
            return FAILURE
        }
    }

    /**
     * Check if permission is granted to communicate with the device
     */
    fun checkUsbConnectionPermission(): Boolean {
        return (usbManager.hasPermission(usbDevice))
    }

    /**
     * Claim the interface of the USB device
     * This is the second step in the complete device opening sequence
     */
    private fun claimUsbInterface(context: Context): Int {
        if (connectionType == ConnectionType.USB_OEM) {
            // First claim the scanner interface (HID interface)
            hostOem.usbInterface = UsbUtils.getHIDInterface(usbDevice)
            Log.d(
                TAG,
                "USB Scanner Interface in claimUsbInterface ${hostOem.usbInterface.hashCode()}"
            )

            // Claim the scanner interface
            hostOem.usbInterface?.let { interfaceToClaim ->
                hostOem.usbDeviceConnection?.let { connection ->
                    if (connection.claimInterface(interfaceToClaim, true)) {
                        Log.i(TAG, "Scanner interface claimed: $interfaceToClaim")
                        setupConnectionForRead(connection)
                        return SUCCESS
                    } else {
                        Log.e(TAG, "Failed to claim interface: $interfaceToClaim")

                        if (retryClaimUsbInterface(usbDevice, context)) {
                            return SUCCESS
                        } else {
                            onStatusListener?.onError(CLAIM_FAILURE)
                        }
                    }
                }
            }
            onStatusListener?.onError(CLAIM_FAILURE)
        } else {
            // For COM devices, use hhrSerialManager
            if (serviceSerial.getUsbSerialPort() != null) {
                return SUCCESS
            } else {
                Log.e(TAG, "Failed to claim interface for COM device")
                onStatusListener?.onError(CLAIM_FAILURE)
            }
        }
        return FAILURE
    }

    /**
     * Retry claiming the interface
     */
    private fun retryClaimUsbInterface(
        device: UsbDevice,
        context: Context,
        maxRetries: Int = 5
    ): Boolean {
        repeat(maxRetries) { attempt ->
            handleDeviceDisconnection(device)
            if (openUsbConnection(context) == 0) {
                val response = claimUsbInterface(context)
                if (response == SUCCESS) {
                    return true
                }
            }
            Log.d(TAG, "Retrying to claim interface (attempt ${attempt + 1} of $maxRetries)")
        }
        return false
    }

    /**
     * Release the claimed interface
     */
    fun releaseUsbInterface(): Int {
        if (connectionType == ConnectionType.USB_OEM) {
            // Release scale interface if it exists
            hostOem.scaleInterface?.let { scaleInterface ->
                hostOem.usbDeviceConnection?.let { connection ->
                    try {
                        if (connection.releaseInterface(scaleInterface)) {
                            Log.i(TAG, "Scale interface released: $scaleInterface")
                        } else {
                            Log.e(TAG, "Failed to release scale interface: $scaleInterface")
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error releasing scale interface", e)
                    }
                    hostOem.scaleInterface = null
                    hostOem.scaleEndpoint = null
                }
            }

            // Release scanner interface
            if (hostOem.usbInterface != null) {
                hostOem.usbInterface?.let { interfaceToRelease ->
                    hostOem.usbDeviceConnection?.let { connection ->
                        if (connection.releaseInterface(interfaceToRelease)) {
                            Log.i(TAG, "Interface released: $interfaceToRelease")
                            hostOem.usbInterface = null
                            return SUCCESS
                        } else {
                            Log.e(TAG, "Failed to release interface: $interfaceToRelease")
                        }
                    }
                }
            } else {
                // If we couldn't find the device, just return success
                return SUCCESS
            }
        } else if (connectionType == ConnectionType.USB_COM || connectionType == ConnectionType.USB_COMSC) {
            return SUCCESS
        }
        return FAILURE
    }

    /**
     * Handles device disconnection
     */
    fun handleDeviceDisconnection(device: UsbDevice) {
        try {
            // Cancel reading jobs
            jobReadingStatus.set(false)

            // Reset interface reference
            if (connectionType == ConnectionType.USB_OEM) {
                hostOem.usbInterface = null
            }

            closeUsbConnection()

            // Update status to CLOSED
            openUsbDevice = null
            status.value = DeviceStatus.CLOSED
            onStatusListener?.onStatus(device.productId.toString(), DeviceStatus.CLOSED, usbDevice.deviceName)
            supportCheckDocking = false
            Log.i(TAG, "Device disconnected: $device")
        } catch (e: Exception) {
            Log.e(TAG, "Error handling device disconnection", e)
        }
    }

    /**
     * Close USB connection
     */
    fun closeUsbConnection(): Int {
        try {
            // Reset connection objects in descriptor
            if (connectionType == ConnectionType.USB_OEM) {
                hostOem.usbDeviceConnection = null
            } else if (connectionType == ConnectionType.USB_COM || connectionType == ConnectionType.USB_COMSC) {
                serviceSerial.close(usbDevice)
                serviceSerial.usbDeviceServiceConnection = null
                serviceSerial.usbServiceSerialPort = null
                serviceSerial.usbDeviceHostConnection = null
                serviceSerial.usbHostSerialPort = null
            } else {
                return FAILURE
            }

            Log.i(TAG, "Connection closed for device: $usbDevice")

            isScaleAvailable = false

            return SUCCESS
        } catch (e: Exception) {
            Log.e(TAG, "Error closing USB connection", e)
            return FAILURE
        }
    }

    /**
     * Setup connection for reading
     */
    private fun setupConnectionForRead(connection: UsbDeviceConnection) {
        hostOem.usbEndpoint = hostOem.usbInterface?.let {
            Log.d(
                TAG,
                "Setting up connection for reading. USB Interface: ${hostOem.usbInterface.hashCode()}"
            )
            UsbUtils.getInEndpoint(it)
        }

        // Now find and claim the scale interface (interface 4)
        try {
            for (i in 0 until usbDevice.interfaceCount) {
                val iInterface = usbDevice.getInterface(i)
                val iInterfaceName = iInterface.name ?: "Unknown Interface $i"
                // Find the Scale interface - it's interface 4 in your device dump
                if (iInterfaceName.contains("Scale")) {
                    Log.d(TAG, "Found scale interface: $iInterface")
                    if (connection.claimInterface(iInterface, true)) {
                        hostOem.scaleInterface = iInterface
                        hostOem.scaleEndpoint = UsbUtils.getInEndpoint(iInterface)
                        Log.i(TAG, "Scale interface claimed successfully")
                    } else {
                        Log.e(TAG, "Failed to claim scale interface")
                    }
                    break
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error claiming scale interface", e)
        }
    }

    /**
     * Get device status
     */
    fun getDeviceStatus(): DeviceStatus {
        return status.value
    }

    /**
     * Registers or replaces the scan listener. This is now thread-safe.
     * It allows a new listener to be set even if one was already there.
     */
    @Synchronized // Ensures thread safety during assignment
    fun registerUsbScanListener(listener: UsbScanListener): Int {
        // Always allow setting/replacing the listener.
        // The @Synchronized annotation prevents race conditions.
        onUsbScanListener = listener
        Log.d(TAG, "UsbScanListener has been registered/updated.")
        return SUCCESS
    }

    /**
     * Unregisters the scan listener only if it's the currently active one.
     */
    @Synchronized // Ensures thread safety during assignment
    fun unregisterUsbScanListener(listener: UsbScanListener): Int {
        // Only remove the listener if it's the one currently registered.
        // This prevents a stale listener from accidentally nullifying a new one.
        return if (listener == onUsbScanListener) {
            onUsbScanListener = null
            Log.d(TAG, "UsbScanListener has been unregistered.")
            SUCCESS
        } else {
            // This is not an error, it just means a new listener was already set.
            Log.w(TAG, "Attempted to unregister a stale or different UsbScanListener.")
            AladdinConstants.LISTENER_NOT_REGISTERED_ERROR
        }
    }

    // Apply the same robust, thread-safe logic to your other listeners

    @Synchronized
    fun registerUsbDioListener(listener: UsbDioListener): Int {
        onUsbDioListener = listener
        return SUCCESS
    }

    @Synchronized
    fun unregisterUsbDioListener(listener: UsbDioListener): Int {
        return if (listener == onUsbDioListener) {
            onUsbDioListener = null
            SUCCESS
        } else {
            AladdinConstants.LISTENER_NOT_REGISTERED_ERROR
        }
    }

    @Synchronized
    fun registerUsbScaleListener(listener: UsbScaleListener): Int {
        onUsbScaleListener = listener
        return SUCCESS
    }

    @Synchronized
    fun unregisterUsbScaleListener(listener: UsbScaleListener): Int {
        return if (listener == onUsbScaleListener) {
            onUsbScaleListener = null
            SUCCESS
        } else {
            AladdinConstants.LISTENER_NOT_REGISTERED_ERROR
        }
    }

    fun registerCradleListener(listener: CradleListener): Int {
        return if (onCradleListener == null) {
            onCradleListener = listener
            SUCCESS
        } else {
            AladdinConstants.LISTENER_ALREADY_REGISTERED_ERROR
        }
    }

    fun unregisterCradleListener(listener: CradleListener? = onCradleListener): Int {
        return if (listener == onCradleListener) {
            onCradleListener = null
            SUCCESS
        } else {
            AladdinConstants.LISTENER_NOT_REGISTERED_ERROR
        }
    }

    private fun convertByteToHexString(byteArray: ByteArray): String {
        val buff = StringBuilder()
        for (byte in byteArray) {
            buff.append(String.format(HEX_FORMAT, byte))
        }
        return buff.toString()
    }

    private fun getLabelType(label: String): String? {
        val barcodeType = BarcodeType.fromHexValue("${USBConstants.HEX_VALUE_ZERO}$label")
        return barcodeType?.getKeyValueString()
    }

    /**
     * Format DIO response based on command type
     * - For standard commands (IDENTIFICATION, HEALTH, STATISTICS): use a common processing approach
     * - For custom OTHER commands: display both hex and ASCII representations
     * - Special handling for COM-SC with SOH/EOT frame separation across multiple frames
     */
    private fun formatDioResponse(
        buf: ByteArray,
        commandType: DIOCmdValue,
        context: Context
    ): String {
        // Get the DIO information data
        val data = dioString(context)

        // Handle empty response for commands that expect data
        if (buf.isEmpty()) {
            return when (commandType) {
                DIOCmdValue.IDENTIFICATION -> {
                    onUsbDioListener?.fireDioErrorEvent(
                        ERR_TIMEOUT,
                        "Unable to get identification information timeout exception."
                    )
                    ""
                }

                DIOCmdValue.HEALTH -> {
                    onUsbDioListener?.fireDioErrorEvent(
                        ERR_TIMEOUT,
                        "Error retrieving Health via DirectIO because of timeout exception."
                    )
                    ""
                }

                DIOCmdValue.STATISTICS -> {
                    onUsbDioListener?.fireDioErrorEvent(
                        ERR_TIMEOUT,
                        "Error retrieving Statistical data via DirectIO because of timeout exception."
                    )
                    ""
                }

                DIOCmdValue.ENABLE_SCANNER, DIOCmdValue.DISABLE_SCANNER, DIOCmdValue.OTHER -> {
                    "Command Executed Successfully"
                }

                else -> {
                    "Command Executed Successfully"
                }
            }
        }

        // Special handling for COM-SC responses with SOH/EOT framing
        if (connectionType == ConnectionType.USB_COMSC &&
            (commandType == DIOCmdValue.IDENTIFICATION ||
                    commandType == DIOCmdValue.HEALTH ||
                    commandType == DIOCmdValue.STATISTICS)
        ) {

            return processComScResponse(buf, commandType, data)
        }

        // Process standard responses
        return when (commandType) {
            DIOCmdValue.IDENTIFICATION, DIOCmdValue.HEALTH, DIOCmdValue.STATISTICS -> {
                processStandardResponse(buf, commandType, data)
            }

            DIOCmdValue.ENABLE_SCANNER, DIOCmdValue.DISABLE_SCANNER, DIOCmdValue.GOOD_BEEP,
            DIOCmdValue.TRIGGER_PRESS, DIOCmdValue.TRIGGER_RELEASE, DIOCmdValue.LOG_CLEARING-> {
                "Command Executed Successfully"
            }

            // For OTHER command types, format response to include both hex and ASCII
            DIOCmdValue.OTHER -> {
                // Format the response with both hex and ASCII representations
                val hexString = byteArrayToHexStringWithSpaces(buf)

                // Create ASCII representation for printable characters
                val asciiString = makePrintableString(buf)

                // Combine both formats in the response
                "Hex: $hexString\nASCII: $asciiString"
            }

            DIOCmdValue.LOG_RETRIEVAL -> {
                formatLogRetrievalResponse(buf)
            }

            DIOCmdValue.DOCKING -> {
                val asciiString = buf.toString(Charsets.UTF_8)
                return if (asciiString.contains("U")) {
                    "Device Undocking"
                } else if ((asciiString.contains("D"))) {
                    "Device Docking"
                } else {
                    DEVICE_NOT_SUPPORT
                }
            }

//            DIOCmdValue.LINKING -> {
//                val asciiString = buf.toString(Charsets.UTF_8)
//                val hexStr = byteArrayToHexString(buf)
//                Log.d(TAG, "hexStr: $hexStr -- asciiString: $asciiString")
//                return if (asciiString.contains("Crad_IsInserted", true)) {
//                    "Device Linked"
//                } else if (!supportCheckDocking){
//                    "Device Not Support"
//                } else {
//                    "Device Unlinked"
//                }
//            }

            // For any other command types not specifically handled
            else -> {
                // Format the response as a hex string
                SmartUtil.bytesToHex0X(buf).trim()
            }
        }
    }

    fun parseCradleStatus(response: String): Boolean {
        val pattern = Regex("!Crad_IsInserted!([A-Z0-9]+)!([YN])")
        val match = pattern.find(response) ?: return false
        return match.groupValues[2] == "Y"
    }

    /**
     * Process standard response with STX/ETX framing for IDENTIFICATION, HEALTH, and STATISTICS
     */
    private fun processStandardResponse(
        buf: ByteArray,
        commandType: DIOCmdValue,
        data: Data
    ): String {
        val separator = "[\u0003\u0001]" // ETX character
        val prefix = when (commandType) {
            DIOCmdValue.IDENTIFICATION -> "Sp<"
            DIOCmdValue.HEALTH -> "Sp="
            DIOCmdValue.STATISTICS -> "Sp>"
            else -> ""
        }

        val strInfoString = String(buf)
        Log.d(TAG, "[processStandardResponse] buf: ${byteArrayToHexStringWithSpaces(buf)}")
        Log.d(TAG, "[processStandardResponse] strInfoString: $strInfoString")
        val segments = strInfoString.split(separator.toRegex()).map { it.trim() }.filter { it.isNotEmpty() }
        val resultMap: MutableMap<String, String> = linkedMapOf()

        for (segment in segments) {
            val truncated = segment.replace("\\p{Cntrl}".toRegex(), "")
            if (truncated.startsWith("!")) {
                val parts = truncated.split("!")
                if (parts.size >= 4) {
                     val key = parts[1]
                     val value = CharsUtil.processPayload(parts[3].toByteArray())
                     resultMap.putIfAbsent(key, "$truncated {$key:$value}")
                }
            } else {
                val truncated2 = truncated.replace(prefix.toRegex(), "")
                if (truncated2.isNotEmpty()) {
                    val keyChar = truncated2.substring(0, 1)
                    val name = when (commandType) {
                        DIOCmdValue.IDENTIFICATION -> findKeyInInformationList(data.Information, keyChar)
                        DIOCmdValue.HEALTH -> findKeyInHealthList(data.Health, keyChar)
                        DIOCmdValue.STATISTICS -> findKeyInStatisticsList(data.Statistics, keyChar)
                        else -> null
                    }
                    if (name != null) {
                        val value = if (truncated2.length > 1) CharsUtil.processPayload(truncated2.substring(1).toByteArray()) else " "
                         resultMap.putIfAbsent(name, "$truncated2 {$name:$value}")
                    }
                }
            }
        }

        Log.d(TAG, "Response: ${resultMap.values.joinToString(separator = ", ")}")
        return resultMap.values.joinToString(separator = ", ")
    }

    /**
     * Process COM-SC response with SOH/EOT framing for IDENTIFICATION, HEALTH, and STATISTICS
     * Special case where multiple frames are separated by SOH (0x01) and EOT (0x04)
     */
    private fun processComScResponse(
        buf: ByteArray,
        commandType: DIOCmdValue,
        data: Data
    ): String {
        val resultMap = HashMap<String, String>()

        // Process each SOH/EOT frame in the response
        var currentPos = 0
        while (currentPos < buf.size) {
            // Find SOH character starting from currentPos
            var sohIndex = -1
            for (i in currentPos until buf.size) {
                if (buf[i].toInt() == 0x01) {
                    sohIndex = i
                    break
                }
            }

            if (sohIndex == -1 || sohIndex >= buf.size - 1) break

            // Find EOT character after SOH
            var eotIndex = -1
            for (i in sohIndex + 1 until buf.size) {
                if (buf[i].toInt() == 0x04) {
                    eotIndex = i
                    break
                }
            }

            if (eotIndex == -1) break

            // Extract frame between SOH and EOT
            val frameContent = String(buf.copyOfRange(sohIndex + 1, eotIndex))

            // Process frame based on command type
            processComScFrame(frameContent, commandType, data, resultMap)

            // Move to next position after EOT
            currentPos = eotIndex + 1
        }

        return resultMap.values.joinToString(separator = ", ")
    }

    /**
     * Process a single COM-SC frame based on command type
     */
    private fun processComScFrame(
        frameContent: String,
        commandType: DIOCmdValue,
        data: Data,
        resultMap: HashMap<String, String>
    ) {
        if (frameContent.isEmpty()) return

        // Extract key and value
        val key = frameContent.substring(0, 1)
        val value = if (frameContent.length > 1) frameContent.substring(1) else " "

        // Find name based on command type
        val name = when (commandType) {
            DIOCmdValue.IDENTIFICATION -> findKeyInInformationList(data.Information, key)
            DIOCmdValue.HEALTH -> findKeyInHealthList(data.Health, key)
            DIOCmdValue.STATISTICS -> findKeyInStatisticsList(data.Statistics, key)
            else -> null
        }

        // Add to result map if name was found
        if (name != null) {
            addKeyValueIfAbsent(resultMap, name, "$key$value {$name:$value}")
        }
    }

    /**
     * Format a raw Aladdin USB response that contains packet boundary markers.
     *
     * USB frames are 8 bytes each. When the device streams status fields and log
     * lines back-to-back, it injects one of these 2-byte boundary markers wherever
     * a new USB packet starts (potentially mid-word):
     *
     *   @P  (0x40 0x50) – start-of-stream / new packet after a full reset
     *   @M  (0x40 0x4D) – packet continuation
     *   )M  (0x29 0x4D) – packet continuation (alternate variant)
     *
     * The function:
     *  1. Strips all three marker sequences so that split words are rejoined.
     *  2. Splits on CR (0x0D) – every entry is CR-terminated in the wire format.
     *  3. Routes each line into one of two output sections:
     *       • Device Status  – short key/value rows  (e.g. "WHH  326", "LB   306")
     *       • Log Lines      – timestamped ScnApp messages
     *
     * Example input  : "@PWHH 326\rLB  306\r...@M4041 I P0A 00 00 ScnApp: Model: Gryphon-GD4600.\r"
     * Example output :
     *   === Device Status ===
     *   WHH   326
     *   LB    306
     *   ...
     *   === Log ===
     *   4041  ScnApp: Model: Gryphon-GD4600.
     *   ...
     */
    fun formatLogRetrievalResponse(buf: ByteArray): String {
        // 1. Convert bytes to string (ISO-8859-1 preserves all byte values 1:1)
        val raw = String(buf, Charsets.ISO_8859_1)
        Log.d(TAG, "[formatLogRetrievalResponse] raw length: ${raw.length}")

        var text = raw

        // 2. Remove packet markers (@P, @@, @M, )M, etc.)
        text = text.replace(Regex("""[@)\]]*[P@M]"""), " ")
        Log.d(TAG, "[formatLogRetrievalResponse] After marker removal: ${text.length} chars")

        // 3. Remove corruption patterns: question mark sequences and @ followed by ?
        text = text.replace(Regex("""\?{2,}"""), " ")
        text = text.replace(Regex("""@\?+"""), " ")
        Log.d(TAG, "[formatLogRetrievalResponse] After corruption removal: ${text.length} chars")

        // 4. Replace ALL control characters (0x00-0x1F) with space
        // This handles both CR, LF, ETX (0x03), STX (0x02), and other separators
        text = text.replace(Regex("""[\u0000-\u001F]"""), " ")
        Log.d(TAG, "[formatLogRetrievalResponse] After control byte removal: ${text.length} chars")

        // 5. Normalize spaces: collapse multiple spaces to single space
        text = text.replace(Regex("""\s+"""), " ").trim()
        Log.d(TAG, "[formatLogRetrievalResponse] After space normalization: ${text.length} chars")

        // 6. Split into tokens
        val tokens = text.split(" ").filter { it.isNotEmpty() }
        Log.d(TAG, "[formatLogRetrievalResponse] Total tokens: ${tokens.size}")

        // 7. Extract log entries by finding timestamp-prefixed lines
        val logLines = mutableListOf<String>()
        var i = 0
        
        while (i < tokens.size) {
            val token = tokens[i]
            
            // Check if token is a timestamp (1-7 digits only)
            if (Regex("""^\d{1,7}$""").matches(token)) {
                val timestamp = token
                val contentParts = mutableListOf<String>()
                i++
                
                // Collect tokens until next timestamp or end
                while (i < tokens.size && !Regex("""^\d{1,7}$""").matches(tokens[i])) {
                    contentParts.add(tokens[i])
                    i++
                }
                
                val content = contentParts.joinToString(" ").trim()
                if (content.isNotEmpty()) {
                    logLines.add("$timestamp  $content")
                }
            } else {
                i++
            }
        }

        Log.d(TAG, "[formatLogRetrievalResponse] Extracted ${logLines.size} log lines")
        if (logLines.isNotEmpty() && logLines.size <= 5) {
            logLines.forEachIndexed { idx, line ->
                Log.d(TAG, "[formatLogRetrievalResponse] Line $idx: ${line.take(80)}")
            }
        }

        // 8. Build result
        val result = logLines.joinToString("\n")
        Log.d(TAG, "[formatLogRetrievalResponse] FINAL: ${if (result.isEmpty()) "EMPTY" else "OK (${result.length} chars, ${logLines.size} lines)"}")
        return result
    }

    private fun isOEMCommandOnly(commandType: DIOCmdValue): Boolean {
        return when (commandType) {
            DIOCmdValue.TRIGGER_PRESS,
            DIOCmdValue.TRIGGER_RELEASE,
            DIOCmdValue.LOG_RETRIEVAL,
            DIOCmdValue.LOG_CLEARING -> true
            else -> false
        }
    }

    fun dioCommand(
        commandType: DIOCmdValue,
        cmd: String,
        context: Context
    ): String {
        var response: ByteArray? = null

        // Check if device connection is available
        if (getDeviceStatus() == DeviceStatus.OPENED || checkingInterface) {
            if(commandType == DIOCmdValue.DOCKING && !supportCheckDocking){
                return DEVICE_NOT_SUPPORT
            }
            if(connectionType != ConnectionType.USB_OEM && isOEMCommandOnly(commandType)){
                return DEVICE_NOT_SUPPORT
            }
            if (connectionType == ConnectionType.USB_COM) {
                if (deviceType == DeviceType.FRS) {
                    var commandToSend: ByteArray

                    if (commandType != DIOCmdValue.OTHER) {
                        // For predefined commands, use their byte values
                        commandToSend = commandType.comValue
                    } else {
                        var cmdToSend = convertAsciiInQuotes(cmd)
                        cmdToSend = cmdToSend.replace(Regex("\\s"), "") // remove whitespace
                        val byteCmd = hexStringToByteArray(cmdToSend)
                        commandToSend = frsDevice.createFullFRSCommand(byteCmd)
                    }

                    if (commandType != DIOCmdValue.OTHER) {
                        if (commandType == DIOCmdValue.GOOD_BEEP ||
                            commandType == DIOCmdValue.ENABLE_SCANNER ||
                            commandType == DIOCmdValue.DISABLE_SCANNER ||
                            commandType == DIOCmdValue.RESET_SCANNER
                        ) {
                            serviceSerial.sendHost(commandToSend)
                        } else if (commandType == DIOCmdValue.ERROR_BEEP) {
                            Log.d(TAG, "[dioCommand] sendHost Error beep")
                            serviceSerial.sendReceiveHost(commandToSend,700,700)
                            Thread.sleep(500)
                            Log.d(TAG, "[dioCommand] sendHost Error beep again")
                            response = serviceSerial.sendReceiveHost(commandToSend,700,700)
                        } else if (commandType == DIOCmdValue.DOCKING
//                            || commandType == DIOCmdValue.LINKING
                            ) {
                            return DEVICE_NOT_SUPPORT
                        } else {
                            response = serviceSerial.sendReceiveHost(
                                command = commandToSend,
                                startTimeout = 700,
                                endTimeout = 700
                            )
                        }
                    } else {
                        response = serviceSerial.sendReceive(
                            command = commandToSend,
                            startTimeout = 700,
                            endTimeout = 700
                        )
                    }
                } else {
                    // Prepare command bytes
                    var commandBytes: ByteArray = byteArrayOf()

                    // Determine command bytes based on the command type and input
                    if (commandType != DIOCmdValue.OTHER) {
                        // For predefined commands, use their byte values
                        commandBytes = commandType.comValue
                    } else {
                        // For custom commands, convert string to bytes
                        // If it's a single character or starts with $ (special command format)
                        commandBytes = if (cmd.startsWith("$") || cmd.length == 1) {
                            // Add carriage return for command strings
                            (cmd + "\r").toByteArray(Charsets.UTF_8)
                        } else if (cmd.contains("0x")) {
                            // Support existing hex format for backward compatibility
                            try {
                                cmd.split(",").map {
                                    Integer.parseInt(it.trim().replace("0x", ""), 16).toByte()
                                }.toByteArray()
                            } catch (e: NumberFormatException) {
                                return "Not a valid Command"
                            }
                        } else {
                            // Try to parse as decimal values
                            try {
                                cmd.split(",").map { it.trim().toInt().toByte() }.toByteArray()
                            } catch (e: NumberFormatException) {
                                // If not parseable, treat as plain string
                                cmd.toByteArray(Charsets.UTF_8)
                            }
                        }
                    }

                    // Execute the command
                    if (commandBytes.isNotEmpty()) {
                        // Special handling for GOOD_BEEP command which doesn't return a response
                        if (commandType == DIOCmdValue.GOOD_BEEP ||
                            commandType == DIOCmdValue.ENABLE_SCANNER ||
                            commandType == DIOCmdValue.DISABLE_SCANNER ||
                            commandType == DIOCmdValue.RESET_SCANNER
                        ) {
                            val result = serviceSerial.sendHost(commandBytes)
                            return if (result == SUCCESS) {
                                "Command Executed Successfully"
                            } else {
                                "Failed to send beep command"
                            }
                        } else if (commandType == DIOCmdValue.ERROR_BEEP) {
                            Log.d(TAG, "[dioCommand] sendHost Error beep: $commandBytes")
                            var timeSuccess = 0
                            var result = serviceSerial.sendHost(commandBytes)
                            if (result == SUCCESS) timeSuccess++
                            Thread.sleep(500)
                            Log.d(TAG, "[dioCommand] sendHost Error beep again")
                            result = serviceSerial.sendHost(commandBytes)
                            if (result == SUCCESS) timeSuccess++
                            return if (timeSuccess == 2) {
                                "Command Executed Successfully"
                            } else {
                                "Failed to send error beep command"
                            }
                        } else if (commandType == DIOCmdValue.OTHER) {
                            // For all other commands, send and wait for response
                            response = serviceSerial.sendReceive(
                                command = commandBytes,
                                startTimeout = 5000,
                                endTimeout = 700
                            )
                        } else {
                            response = serviceSerial.sendReceiveHost(
                                command = commandBytes,
                                startTimeout = 700,
                                endTimeout = 700
                            )
                        }
                    } else {
                        return "Command is empty"
                    }
                }
            } else if (connectionType == ConnectionType.USB_COMSC) {
                if (deviceType == DeviceType.FRS) {
                    val commandToSend: ByteArray
                    if (commandType == DIOCmdValue.HEALTH || commandType == DIOCmdValue.IDENTIFICATION || commandType == DIOCmdValue.STATISTICS) {
                        // For predefined commands, use their byte values
                        commandToSend = commandType.comSCValue
                        response = serviceSerial.sendReceiveHost(commandToSend, 700, 700)
                        if (response != null) {
                            formatDioResponse(response, commandType, context)
                        }
                    } else if (commandType == DIOCmdValue.ENABLE_SCANNER) {
                        // Enable scanner command for COM-SC: S01<CR>
                        val enableCommand = commandType.comSCValue
                        val result = serviceSerial.sendReceiveHost(enableCommand, 700, 700)
                        return if (result != null && result.contentEquals("S00\r".toByteArray())) {
                            "Command Executed Successfully"
                        } else {
                            "Failed to enable scanner"
                        }
                    } else if (commandType == DIOCmdValue.DISABLE_SCANNER) {
                        // Disable scanner command for COM-SC: S06<CR>
                        val disableCommand = commandType.comSCValue
                        val result = serviceSerial.sendReceiveHost(disableCommand, 700, 700)
                        return if (result != null && result.contentEquals("S00\r".toByteArray())) {
                            "Command Executed Successfully"
                        } else {
                            "Failed to disable scanner"
                        }
                    } else if (commandType == DIOCmdValue.RESET_SCANNER) {
                        // Reset scanner command for COM-SC
                        val resetCommand = commandType.comSCValue
                        serviceSerial.sendHost(resetCommand)
                        return "Command Executed Successfully"
                    } else if (commandType == DIOCmdValue.GOOD_BEEP) {
                        // Beep command for COM-SC: S334<CR>
                        val beepCommand = commandType.comSCValue
                        val result = serviceSerial.sendReceiveHost(beepCommand, 500, 300)
                        return "Command Executed Successfully"
                    } else if (commandType == DIOCmdValue.ERROR_BEEP) {
                        // Beep command for COM-SC: S334<CR>
                        val beepCommand = commandType.comSCValue
                        Log.d(TAG, "[dioCommand] sendReceiveHost Error beep: $beepCommand")
                        serviceSerial.sendReceiveHost(beepCommand, 500, 300)
                        Thread.sleep(500)
                        Log.d(TAG, "[dioCommand] sendReceiveHost Error beep again")
                        serviceSerial.sendReceiveHost(beepCommand, 500, 300)
                        return "Command Executed Successfully"
                    } else {
                        return "Command is currently not supported for FRS with Single Cable Interface"
                    }
                }
            } else { //connectionType == ConnectionType.USB_OEM
                if (commandType == DIOCmdValue.OTHER) {
                    return "This command are not supported on OEM connection"
                }

                // Prepare command bytes
                val commandBytes: ByteArray = commandType.oemValue
                if (commandType == DIOCmdValue.RESET_SCANNER) {
                    hostOem.send(commandBytes)
                } else if (commandType == DIOCmdValue.ERROR_BEEP) {
                    Log.d(TAG, "[dioCommand] hostOem sendReceive Error beep: $commandBytes")
                    hostOem.sendReceive(commandBytes)
                    Thread.sleep(300)
                    Log.d(TAG, "[dioCommand] hostOem sendReceive Error beep again")
                    hostOem.sendReceive(commandBytes)
                } else if (deviceType == DeviceType.FRS &&
                    (commandType == DIOCmdValue.DOCKING
//                            || commandType == DIOCmdValue.LINKING
                     )
                    ) {
                    return DEVICE_NOT_SUPPORT
                } else {
                    response = hostOem.sendReceive(commandBytes)
                }
            }

            // Format the response based on command type
            return if (response != null) {
                formatDioResponse(response, commandType, context)
            } else {
                "Command Executed Successfully"
            }

        }

        return ""
    }

    fun readConfig(): HashMap<ConfigurationFeature, String> {
        val configMap = HashMap<ConfigurationFeature, String>()
        Log.d("UsbConnection", "Reading config for device: ${displayName}")

        if (getDeviceStatus() == DeviceStatus.OPENED) {
            try {
                Log.d("UsbConnection", "Device specific type: $deviceType $connectionType")

                // Enter service mode before reading configuration
                if (connectionType == ConnectionType.USB_COM && deviceType == DeviceType.HHS) {
                    Log.d(TAG, "Entering service mode for readConfig")
                    enterServiceMode()
                }

                if (connectionType == ConnectionType.USB_OEM) {
                    // OEM protocol command - existing implementation
                    val command = byteArrayOf(0x7E, 0x00, 0x07, 0x01, 0x02, 0x00, 0x00, 0x09)
                    val response = serviceSerial.sendReceive(
                        command = command,
                        startTimeout = 700,
                        endTimeout = 700
                    )
                    if (response != null && response.isNotEmpty()) {
                        processOemConfigResponse(response, configMap)
                    }
                } else { //connectionType == ConnectionType.USB_COM
                    if (deviceType == DeviceType.FRS) {
                        //Magellan 1500i in COM port does not support Configuration service commands
                        if (usbDevice.productId.toString() == "16386") {
                            return HashMap<ConfigurationFeature, String>()
                        }
                        readFrsFeaturesIndividually(serviceSerial, configMap)
                    } else { //deviceType == DeviceType.HHS
                        // HHS protocol - use FETCH_ALL with $ prefix (existing implementation)
                        val command =
                            ("$" + ConfigurationFeature.FETCH_ALL.comFeatureId).toByteArray()
                        val response = serviceSerial.sendReceive(
                            command = command,
                            startTimeout = 700,
                            endTimeout = 700
                        )
                        if (response != null && response.isNotEmpty()) {
                            processComConfigResponse(response, configMap)
                        }
                    }
                }

                // Exit service mode after reading configuration
                if (connectionType == ConnectionType.USB_COM && deviceType == DeviceType.HHS) {
                    Log.d(TAG, "Exiting service mode for readConfig")
                    exitServiceMode()
                }
                configMap.entries.removeIf { it.value != "00" && it.value != "01" }
                Log.i("UsbConnection", "Read config result: $configMap")
            } catch (e: Exception) {
                Log.e("UsbConnection", "Error reading config: ${e.message}", e)

                // Exit service mode on error for HHS devices
                if (connectionType == ConnectionType.USB_COM && deviceType == DeviceType.HHS) {
                    Log.d(TAG, "Exiting service mode on error for readConfig")
                    exitServiceMode()
                }
            }
        }

        return configMap
    }

    /**
     * Read each FRS feature individually rather than using a single read-all command
     */
    private fun readFrsFeaturesIndividually(
        connection: ServiceSerial,
        configMap: HashMap<ConfigurationFeature, String>
    ) {
        // Process each feature that has a magellanfeatureId defined
        for (feature in ConfigurationFeature.values()) {
            if (feature != ConfigurationFeature.FETCH_ALL && feature.magellanfeatureId.isNotEmpty()) {
                try {
                    // Create command using READ_CONFIG_DATA (0x0011) + feature ID
                    val commandData = ByteArray(2 + feature.magellanfeatureId.size)
                    commandData[0] =
                        (FRSContants.READ_CONFIG_DATA shr 8).toByte()  // High byte (0x00)
                    commandData[1] =
                        FRSContants.READ_CONFIG_DATA.toByte()          // Low byte (0x11)

                    // Copy feature ID
                    System.arraycopy(
                        feature.magellanfeatureId,
                        0,
                        commandData,
                        2,
                        feature.magellanfeatureId.size
                    )

                    // Create full FRS command with proper framing
                    val command = frsDevice.createFullFRSCommand(commandData)

                    Log.d(
                        "UsbConnection",
                        "Reading FRS feature ${feature.featureName}: ${featureIdToHexString(feature.magellanfeatureId)}"
                    )

                    // Send command and get response for each configuration feature
                    val response = connection.sendReceive(
                        command = command,
                        startTimeout = 700,
                        endTimeout = 700
                    )

                    // Process response if valid
                    if (response != null && response.isNotEmpty()) {
                        // Extract actual data using FRSDevice parsing function
                        val parsedData = frsDevice.extractMagellanResponseData(response)

                        if (parsedData.isNotEmpty()) {
                            // The value is typically in the data after the command echo
                            // For most features, this should be at index 2
                            val valueIndex = if (parsedData.size > 2) 2 else 0

                            if (valueIndex < parsedData.size) {
                                val value = parsedData[valueIndex].toInt() and 0xFF
                                configMap[feature] = String.format("%02X", value)
                                Log.d(
                                    "UsbConnection",
                                    "Read FRS feature ${feature.featureName}: ${configMap[feature]}"
                                )
                            } else {
                                Log.d(
                                    "UsbConnection",
                                    "Parsed data too short for feature ${feature.featureName}"
                                )
                            }
                        } else {
                            Log.d(
                                "UsbConnection",
                                "No valid data extracted for feature ${feature.featureName}"
                            )
                        }
                    } else {
                        Log.d("UsbConnection", "No response for feature ${feature.featureName}")
                    }

                    // Small delay between commands
                    Thread.sleep(10)
                } catch (e: Exception) {
                    Log.e(
                        "UsbConnection",
                        "Error reading feature ${feature.featureName}: ${e.message}",
                        e
                    )
                }
            }
        }
    }

    /**
     * Convert feature ID bytes to a formatted hex string for comparison
     */
    private fun featureIdToHexString(featureId: ByteArray): String {
        return featureId.joinToString("") {
            String.format("%02X", it.toInt() and 0xFF)
        }
    }

    /**
     * Process configuration response for OEM devices
     */
    private fun processOemConfigResponse(
        response: ByteArray,
        configMap: HashMap<ConfigurationFeature, String>
    ) {
        // Skip header bytes (typically first 4 bytes in OEM responses)
        val startIndex = 4

        // Check if response is long enough
        if (response.size <= startIndex) {
            Log.e("UsbConnection", "OEM response too short: ${response.size} bytes")
            return
        }

        // Process each configuration feature
        for (feature in ConfigurationFeature.values()) {
            if (feature != ConfigurationFeature.FETCH_ALL && feature.magellanfeatureId.isNotEmpty()) {
                // For each feature, scan through response to find matching feature ID
                scanResponseForFeature(response, startIndex, feature, configMap)
            }
        }
    }

    /**
     * Scan through response data to find specific feature
     */
    private fun scanResponseForFeature(
        response: ByteArray,
        startIndex: Int,
        feature: ConfigurationFeature,
        configMap: HashMap<ConfigurationFeature, String>
    ) {
        val featureId = feature.magellanfeatureId

        // Skip if feature ID is empty
        if (featureId.isEmpty()) return

        // Scan through response data
        for (i in startIndex until response.size - featureId.size) {
            var matches = true

            // Check if feature ID matches
            for (j in featureId.indices) {
                if (response[i + j] != featureId[j]) {
                    matches = false
                    break
                }
            }

            // If feature ID found, get value
            if (matches && i + featureId.size < response.size) {
                val valueIndex = i + featureId.size
                val value = response[valueIndex].toInt() and 0xFF
                configMap[feature] = String.format("%02X", value)
                Log.d(
                    "UsbConnection",
                    "Found feature ${feature.featureName}: ${configMap[feature]}"
                )
                break
            }
        }
    }

    /**
     * Process configuration response for COM devices
     */
    private fun processComConfigResponse(
        response: ByteArray,
        configMap: HashMap<ConfigurationFeature, String>
    ) {
        val responseString = String(response)
        Log.d("UsbConnection", "Processing COM response: $responseString")

        // Handle the special format: "$>,>01,>01,>01,...\r"
        if (responseString.startsWith("$>,") && responseString.endsWith("\r")) {
            // Extract the middle part between "$>," and "%"
            val valuesSection = responseString.substring(3, responseString.length - 1)

            // Split by commas to get individual values
            val values = valuesSection.split(",")

            // Get features excluding FETCH_ALL (which is just for querying)
            val features = ConfigurationFeature.values().filter {
                it != ConfigurationFeature.FETCH_ALL && it.comFeatureId.isNotEmpty()
            }

            // Match values to features if counts match
            if (values.size == features.size) {
                for (i in features.indices) {
                    val value = values[i]
                    val feature = features[i]

                    // Parse ">01" or ">00" format
                    val enabled = value == ">01"
                    configMap[feature] = if (enabled) "01" else "00"

                    Log.d("UsbConnection", "Set ${feature.featureName} to ${configMap[feature]}")
                }
            } else {
                Log.e(
                    "UsbConnection",
                    "Feature count mismatch: ${features.size} features vs ${values.size} values"
                )

                // Still process what we can
                for (i in 0 until minOf(features.size, values.size)) {
                    val value = values[i]
                    val feature = features[i]

                    val enabled = value == ">01"
                    configMap[feature] = if (enabled) "01" else "00"
                }
            }
        } else {
            // Try the original format (key:value pairs)
            val keyValuePairs = responseString.split(",")
            for (pair in keyValuePairs) {
                val parts = pair.split(":")
                if (parts.size == 2) {
                    val featureId = parts[0].trim()
                    val value = parts[1].trim()

                    val feature = ConfigurationFeature.fromComFeatureId(featureId)
                    feature?.let {
                        configMap[it] = if (value == "1" || value == ">01") "01" else "00"
                    }
                }
            }
        }
    }

    /**
     * Writes configuration to the device
     */
    fun writeConfig(
        data: HashMap<ConfigurationFeature, String>
    ): HashMap<ConfigurationFeature, String> {
        val resultMap: HashMap<ConfigurationFeature, String> = HashMap()

        if (data.isEmpty() || connectionType == ConnectionType.USB_OEM) {
            return resultMap
        }

        if (deviceType == DeviceType.HHS) {
            val commandBytes = "\$S\r".toByteArray()
            val response = serviceSerial.sendReceive(
                command = commandBytes,
                startTimeout = 700,
                endTimeout = 700
            )
        }

        // Write each feature
        for ((feature, value) in data) {
            try {
                // Create command based on specific device type
                val commandBytes = createFeatureCommand(feature, value)

                if (commandBytes.isEmpty()) {
                    resultMap[feature] = "!"
                    continue
                }

                // Send command
                val response = serviceSerial.sendReceive(
                    command = commandBytes,
                    startTimeout = 700,
                    endTimeout = 700
                )

                // Validate response
                val success = validateConfigResponse(response)
                resultMap[feature] = if (success) ">" else "!"

                // Small delay between commands
                Thread.sleep(100)
            } catch (e: Exception) {
                resultMap[feature] = "!"
            }
        }

        // For HHS devices, save configuration after all changes
        if (deviceType == DeviceType.HHS) {
            val commandBytes = applyConfigToCurrentInterface
            val response = serviceSerial.sendReceive(
                command = commandBytes,
                startTimeout = 700,
                endTimeout = 700
            )
            // For FRS devices, save configuration after all changes
        } else if (deviceType == DeviceType.FRS) {
            try {
                // Use the SAVE_CONFIG constant from FRSContants for saving
                val saveCommandData = ByteArray(2)
                saveCommandData[0] = (FRSContants.SAVE_CONFIG shr 8).toByte()  // High byte
                saveCommandData[1] = FRSContants.SAVE_CONFIG.toByte()         // Low byte

                val saveCommand = frsDevice.createFullFRSCommand(saveCommandData)
                serviceSerial.sendReceive(
                    command = saveCommand,
                    startTimeout = 700,
                    endTimeout = 700
                )

                Log.d("UsbConnection", "FRS configuration saved")
            } catch (e: Exception) {
                Log.e("UsbConnection", "Error saving FRS config", e)
            }
        }

        return resultMap
    }

    /**
     * Create command bytes for a specific feature and value
     */
    private fun createFeatureCommand(
        feature: ConfigurationFeature,
        value: String
    ): ByteArray {
        if (connectionType == ConnectionType.USB_OEM) {
            // OEM protocol - existing implementation
            if (feature.magellanfeatureId.isEmpty()) {
                return byteArrayOf(0x7E, 0x00, 0x07, 0x01, 0x02, 0x00, 0x00, 0x09)
            } else {
                val featureBytes = feature.magellanfeatureId
                val valueInt = value.toIntOrNull(16) ?: 0

                // Create OEM command with existing logic
                val command = ByteArray(7 + featureBytes.size)
                command[0] = 0x7E.toByte()  // Start marker
                command[1] = 0x00.toByte()  // Reserved
                command[2] = (5 + featureBytes.size).toByte()  // Length
                command[3] = 0x02.toByte()  // Write command
                command[4] = 0x02.toByte()  // Config parameter
                System.arraycopy(featureBytes, 0, command, 5, featureBytes.size)
                command[5 + featureBytes.size] = valueInt.toByte()

                var checksum = 0
                for (i in 3 until 6 + featureBytes.size) {
                    checksum += command[i].toInt() and 0xFF
                }
                command[6 + featureBytes.size] = (checksum and 0xFF).toByte()

                return command
            }
        } else { //connectionType == ConnectionType.USB_COM
            if (deviceType == DeviceType.FRS) {
                // FRS/Magellan protocol for writing
                val featureBytes = feature.magellanfeatureId
                if (featureBytes.isEmpty()) {
                    return ByteArray(0)
                }

                val valueInt = value.toIntOrNull(16) ?: 0

                // Create command with WRITE_CONFIG_DATA (0x0010) + featureId + value
                // Example for Code 39 (0x008E) with value 01: 0010008E01
                val commandData = ByteArray(2 + featureBytes.size + 1)
                commandData[0] = 0x00.toByte()
                commandData[1] = 0x10.toByte()  // WRITE_CONFIG_DATA (0x0010)
                System.arraycopy(featureBytes, 0, commandData, 2, featureBytes.size)
                commandData[2 + featureBytes.size] = valueInt.toByte()

                Log.d(
                    "UsbConnection",
                    "Writing FRS feature ${feature.featureName}: ${byteArrayToHexString(commandData)}"
                )

                // Create full FRS command with proper framing
                return frsDevice.createFullFRSCommand(commandData)
            } else { //deviceType == DeviceType.HHS)
                // HHS device protocol with correct format
                val commandPart: String

                commandPart = "\$" + feature.comFeatureId + value + "\r"

                Log.d("UsbConnection", "HHS command: $commandPart")
                return commandPart.toByteArray()
            }
        }
    }

    /**
     * Validate configuration response based on device type
     */
    private fun validateConfigResponse(response: ByteArray?): Boolean {
        if (response == null || response.isEmpty()) {
            return false
        }

        if (connectionType == ConnectionType.USB_OEM) {
            return response[0] == 0x06.toByte() // ACK
        } else { //connectionType == ConnectionType.USB_COM
            if (deviceType == DeviceType.FRS) {
                // Extract data from the response using FRSDevice parser
                val parsedData = frsDevice.extractMagellanResponseData(response)

                // Check for ACK or success status
                return parsedData.isNotEmpty() && (
                        parsedData[0] == 0x06.toByte() || // ACK
                                (parsedData.size > 1 && parsedData[1] == 0x00.toByte()) // Success status
                        )
            } else { //deviceType == DeviceType.HHS
                // HHS/COM response validation
                val responseString = String(response)
                return response[0] == 0x06.toByte() ||
                        responseString.contains("OK") ||
                        responseString.startsWith("$>")
            }
        }
    }

    fun getDeviceModelName(): String {
        try {
            // Send the $! command with carriage return using our regular command handler
            val response =
                serviceSerial.sendReceive(
                    HHSDevice.DEVICE_NAME_AND_SW_RELEASE.toByteArray(Charsets.UTF_8),
                    1000,
                    700
                )

            if (response != null) {
                if (response.isNotEmpty()) {
                    // Process the response
                    val responseStr = response.toString(Charsets.UTF_8).trim()

                    if (responseStr.isNotEmpty() && !responseStr.startsWith("ERROR")) {
                        // Clean up response - remove control characters
                        val cleanResponse = responseStr.replace("\\p{Cntrl}".toRegex(), "").trim()

                        // Extract model name - it's typically before "SOFTWARE RELEASE" or similar text
                        val modelName = when {
                            cleanResponse.contains("SOFTWARE RELEASE") ->
                                cleanResponse.substringBefore("SOFTWARE RELEASE").trim()

                            cleanResponse.contains("SOFTWARE") ->
                                cleanResponse.substringBefore("SOFTWARE").trim()

                            else -> cleanResponse
                        }

                        Log.d(
                            TAG,
                            "Extracted device model: $modelName from response: $cleanResponse"
                        )
                        return modelName
                    }
                }
            }

            Log.w(TAG, "Invalid or empty response received")
            return ""
        } catch (e: Exception) {
            Log.e(TAG, "Error sending device info command", e)
            return ""
        }
    }

    /**
     * Reads version information from a Magellan device using the improved command handling
     *
     * @param device The Magellan device descriptor
     * @return The device name/model information as a string
     */
    fun readMagellanVersion(): String {
        // Create the service port command for READ_VERSION (0x011B)
        val byteArray = frsDevice.createFullFRSCommand(READ_VERSION)

        // Add a small delay before sending command to ensure device is ready
        Thread.sleep(200)

        // Send the command with the validator and get the response
        val response = serviceSerial.sendReceive(
            command = byteArray,
            startTimeout = 700,
            endTimeout = 700
        )

        // Parse the response
        return frsDevice.parseMagellanVersionResponse(response ?: ByteArray(0))
    }

    fun getConfigName(context: Context): String {
        var configName = ""
        val response = if (displayName.contains("ServicePort", true) && deviceType == DeviceType.FRS) {
            val commandToSend = frsDevice.createFullFRSCommand(READ_IDENTIFICATION)
            serviceSerial.sendReceive(commandToSend, 700, 700)
        } else if (connectionType == ConnectionType.USB_COMSC) {
            val command = DIOCmdValue.IDENTIFICATION
            serviceSerial.sendReceiveHost(command.comSCValue, 700, 700)
        } else {
            val command = DIOCmdValue.IDENTIFICATION
            serviceSerial.sendReceiveHost(command.comValue, 700, 700)
        }
        val data = dioString(context)
        if (response != null) {
            val result = processStandardResponse(response, DIOCmdValue.IDENTIFICATION, data)
            if (result.isBlank()) return configName //empty
            try {
                val regex = "\\{ConfigurationFileID:([^}]+)\\}".toRegex()
                configName = regex.find(result)?.groupValues?.get(1).toString()
                return configName
            } catch (e: Exception) {
                Log.e(TAG,"[getConfigName] get ConfigurationFileID error: $e")
            }
        }
        return configName //empty
    }

    fun imageCaptureAuto(currentBrightness: Int = 0, currentContrast: Int = 0): ByteArray {
        if (deviceType == DeviceType.HHS) {
            return imageCaptureHHS.imageCaptureAuto(
                serviceSerial,
                currentBrightness,
                currentContrast
            )
        } else
            return imageCaptureFRS.imageCaptureAuto(serviceSerial)
    }

    /**
     * Check if the device is in Scanner/Scale protocol mode. If not, this function
     * will return a message asking the user to switch modes.
     *
     * @param context The Android context
     * @return A pair containing (isScaleProtocolEnabled, message)
     *         If scale protocol is not enabled, message will contain instructions for the user
     */
    /*fun checkScaleProtocolEnabled(context: Context): Pair<Boolean, String> {
        if (status != DeviceStatus.OPENED) {
            return Pair(false, "Device not open")
        }

        // Only FRS devices (Magellan) support scale functionality
        if (deviceType != DeviceType.FRS) {
            return Pair(false, "Scale functionality only supported on FRS/Magellan devices")
        }

        try {
            val commandToSend = frsDevice.createFullFRSCommand(CHECK_SCALE_PROTOCOL_CMD)
            // Send command to check scale protocol
            val response = serviceSerial.sendReceive(
                command = commandToSend,
                startTimeout = 2000,
                endTimeout = 700
            )

            // Parse response - if scale protocol is enabled, the response will indicate that
            if (response != null && response.isNotEmpty()) {
                val parsedData = frsDevice.extractMagellanResponseData(response)

                // The expected response format depends on the specific device model
                // Generally, we're looking for a positive acknowledgment that scale protocol is active

                return if (parsedData[0].toInt() == 0x00) {
                    Pair(true, "Scale protocol is enabled")
                } else {
                    Pair(
                        false, "Scale protocol is disabled. Would you like to enable it? " +
                                "(Device reset required)"
                    )
                }
            }

            return Pair(false, "Unable to determine scale protocol status")
        } catch (e: Exception) {
            Log.e(TAG, "Error checking scale protocol status", e)
            return Pair(false, "Error checking scale protocol status: ${e.message}")
        }
    }*/

    /**
     * Enable Scanner/Scale protocol on the device.
     * This requires a device reset to take effect.
     *
     * @param context The Android context
     * @return Success or failure status
     */
    /*fun enableScaleProtocol(context: Context): Int {
        var commandToSend: ByteArray

        if (status != DeviceStatus.OPENED) {
            return FAILURE
        }

        try {
            commandToSend = frsDevice.createFullFRSCommand(ENABLE_SCALE_PROTOCOL_CMD)
            // Send command to enable Scale Protocol
            var response = serviceSerial.sendReceive(
                command = commandToSend,
                startTimeout = 2000,
                endTimeout = 700
            )

            if (response == null || response.isEmpty()) {
                return FAILURE
            }

            commandToSend = frsDevice.createFullFRSCommand(RESET_DEVICE_CMD)
            // Send reset command to apply changes
            response = serviceSerial.sendReceive(
                command = commandToSend,
                startTimeout = 2000,
                endTimeout = 700
            )

            // Device will reset, so close the connection and let the user know they need to reconnect
            closeDevice()

            return SUCCESS
        } catch (e: Exception) {
            Log.e(TAG, "Error enabling scale protocol", e)
            return FAILURE
        }
    }*/

    /**
     * Gets the current weight from the scale.
     *
     * @return A ScaleData object containing the scale status and formatted weight (if available)
     */
    private fun sendWeightRequest(): Int {
        if (status.value != DeviceStatus.OPENED) {
            return FAILURE
        }

        try {
            if (connectionType == ConnectionType.USB_COMSC) {
                // Send through the host port for COM devices
                return serviceSerial.sendHost(WEIGHT_REQUEST_CMD)
            } else if (connectionType == ConnectionType.USB_OEM) {
                // For OEM devices, check if we have the scale interface
                if (hostOem.scaleInterface == null) {
                    Log.e(TAG, "Scale interface not available")
                    return FAILURE
                }

                if (isEnglishWeighMode) {
                    hostOem.sendScaleCommand(WEIGHT_REQUEST_CMD_OEM_ENGLISH_WEIGHT)
                } else {
                    hostOem.sendScaleCommand(WEIGHT_REQUEST_CMD_OEM_METRIC_WEIGHT)
                }
                return SUCCESS
            } else {
                return FAILURE
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting weight", e)
            return FAILURE
        }
        return SUCCESS
    }

    /**
     * Parse scale response according to the protocol documents
     * Formats expected:
     * - Zero weight: "S143"
     * - Non-zero weight: "S1440123" where 0123 represents weight (01.23 lb)
     */
    private fun parseScaleResponseCOMSC(response: ByteArray): ScaleData {
        val responseString = String(response, StandardCharsets.UTF_8).trim()
        Log.d(TAG, "Scale Raw Response: $responseString")

        // Check for valid scale response format (must start with S14)
        if (!responseString.startsWith("S14")) {
            return ScaleData("ERROR", "Invalid response format", unitScale)
        }

        // Extract status character (position 3)
        if (responseString.length < 4) {
            return ScaleData("ERROR", "Response too short", unitScale)
        }

        val statusChar = responseString[3]

        // Parse status and weight
        return when (statusChar) {
            STATUS_NOT_READY -> ScaleData("NOT_READY", "NONE", unitScale)
            STATUS_UNSTABLE -> ScaleData("UNSTABLE", "NONE", unitScale)
            STATUS_OVER_CAPACITY -> ScaleData("OVER_CAPACITY", "NONE", unitScale)
            STATUS_STABLE_ZERO -> ScaleData("STABLE_ZERO", "0.00", unitScale)
            STATUS_STABLE_NON_ZERO -> {
                // Extract and format weight digits
                if (responseString.length < 5) {
                    ScaleData("STABLE", "NONE", unitScale) // Not enough digits
                } else {
                    if (unitScale == ScaleUnit.LB) {
                        val weightDigits = responseString.takeLast(4)
                        if (weightDigits.isNotEmpty()) {
                            // Format as XX.XX lb - assuming 4 digits (2 integer, 2 decimal)
                            // The number of digits may vary based on specific scale configuration
                            val formattedWeight = if (weightDigits.length > 2) {
                                val integerPart = weightDigits.substring(0, weightDigits.length - 2)
                                val decimalPart = weightDigits.substring(weightDigits.length - 2)
                                "$integerPart.$decimalPart"
                            } else {
                                "0.$weightDigits" // Handle case with fewer digits
                            }
                            ScaleData("STABLE", formattedWeight, unitScale)
                        } else {
                            ScaleData("STABLE", "NONE", unitScale)
                        }
                    } else {
                        val weightDigits = responseString.substring(4)
                        if (weightDigits.isNotEmpty()) {
                            // Format as XX.XXX kg - assuming 5 digits (2 integer, 3 decimal)
                            // The number of digits may vary based on specific scale configuration
                            val formattedWeight = if (weightDigits.length > 3) {
                                val integerPart = weightDigits.substring(0, weightDigits.length - 3)
                                val decimalPart = weightDigits.substring(weightDigits.length - 3)
                                "$integerPart.$decimalPart"
                            } else {
                                "0.$weightDigits" // Handle case with fewer digits
                            }
                            ScaleData("STABLE", formattedWeight, unitScale)
                        } else {
                            ScaleData("STABLE", "NONE", unitScale)
                        }
                    }
                }
            }

            STATUS_UNDER_ZERO -> ScaleData("UNDER_ZERO", "NONE", unitScale)
            else -> ScaleData("UNKNOWN (${statusChar.code})", "NONE", unitScale)
        }
    }

    // Receive barcode and scale data
    private fun usbReadingCoroutine() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                var startTime = System.currentTimeMillis()
                while (jobReadingStatus.get()) {
                    if (connectionType == ConnectionType.USB_COM || connectionType == ConnectionType.USB_COMSC) {
                        if (serviceSerial.usbServiceSerialPort != null ||
                            serviceSerial.usbHostSerialPort != null
                        ) {

                            //Send weight request if enable
                            if (startScale.get()) {
                                if (enableScale == true) {
                                    val result = sendWeightRequest()
                                } else {
                                    // Notify scale listener
                                    onUsbScaleListener?.onScale(
                                        ScaleData(
                                            "ERROR",
                                            "Scale is being disable",
                                            ScaleUnit.NONE
                                        )
                                    )
                                }
                            }

                            var data: ByteArray?
                            if (serviceSerial.usbHostSerialPort != null) {
                                data = serviceSerial.receiveWithTimeoutHost(100, 100)
                            } else {
                                data = serviceSerial.receiveWithTimeout(100, 100)
                            }

                            if (data != null && data.isNotEmpty()) {
                                processReceivedData(data)
                            }
                            if (supportCheckDocking && System.currentTimeMillis() - startTime > timerCheckDocking) {
                                checkDockAndLink()
                                startTime = System.currentTimeMillis()
                            }
                        } else {
                            jobReadingStatus.set(false)
                        }
                    } else if (connectionType == ConnectionType.USB_OEM) {
                        if (hostOem.usbDeviceConnection != null) {
                            if (startScale.get()) {
                                sendWeightRequest()
                                val (scaleData, barcodeData) = hostOem.receiveBothScaleAndBarcodeWithTimeout(
                                    100,
                                    100,
                                    startScale.get()
                                )
                                if (scaleData != null) {
                                    handleScaleDataReceivedOEM(scaleData)
                                }
                                if (barcodeData != null) {
                                    handleBarcodeDataReceivedOEM(barcodeData)
                                }
                            } else {
                                val data = hostOem.receiveOnDeviceInterfaceWithTimeout(100, 100)
                                if (data != null) {
                                    Log.d(TAG, "Received data: ${byteArrayToHexString(data)}")
                                    handleBarcodeDataReceivedOEM(data)
                                }
                                if (supportCheckDocking && System.currentTimeMillis() - startTime > timerCheckDocking) {
                                    checkDockAndLink()
                                    startTime = System.currentTimeMillis()
                                }
                            }
                        } else {
                            jobReadingStatus.set(false)
                        }
                    }

                    Thread.sleep(100)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Usb reading coroutine errors.", e)
            }
        }

        Log.d(TAG, "Exiting from reading daemon")
    }

    fun startAutoCheckDocking() {
        autoCheckDocking.set(true)
        if (supportCheckDocking) checkDockAndLink()
    }
    fun stopAutoCheckDocking() {
        autoCheckDocking.set(false)
    }
    fun isSupportCheckDocking() : Boolean {
        return supportCheckDocking
    }
    fun isDeviceSupportCheckDocking() : Boolean{
        if (deviceType == DeviceType.HHS) {
            val response = when (connectionType) {
                ConnectionType.USB_COM -> serviceSerial.sendReceive(DIOCmdValue.DOCKING.comValue,700,700)
                ConnectionType.USB_OEM -> hostOem.sendReceive(DIOCmdValue.DOCKING.oemValue)
                else -> null
            }
            if (response != null) {
                supportCheckDocking = true
            }
        }
        return supportCheckDocking
    }

    fun setTimerCheckDocking(time: Int) {
        timerCheckDocking = if (time < 1000) {
            1000
        } else {
            time
        }
    }

    fun splitDockResponseAndBarcode(
        source: ByteArray?,
        startArray: ByteArray
    ): Pair<ByteArray?, ByteArray?> {
        if (source == null) return null to null
        if (source.size < startArray.size + 2) return byteArrayOf() to source

        val end = byteArrayOf(3, 4)

        val startIndex = (0..source.size - startArray.size).firstOrNull { idx ->
            startArray.indices.all { startArray[it] == source[idx + it] }
        } ?: return byteArrayOf() to source

        val endIndex = (startIndex + startArray.size until source.size - 1).firstOrNull { i ->
            source[i] == end[0] && source[i + 1] == end[1]
        }?.plus(2) ?: return byteArrayOf() to source

        val response = source.copyOfRange(startIndex, endIndex)
        var barcode = ByteArray(source.size - response.size)
        var k = 0
        for (i in source.indices) {
            if (i < startIndex || i >= endIndex) barcode[k++] = source[i]
        }

        if (barcode.all { it == 0.toByte() }) {
            barcode = byteArrayOf()
        }

        return response to barcode
    }

    fun checkDockAndLink() {
        if (!autoCheckDocking.get()) {
            return
        }
        // Check Dock
        checkDocking()
        // Check Link
//        checkLinking()
    }
    private fun checkDocking() {
        val responseDock = when (connectionType) {
            ConnectionType.USB_COM -> serviceSerial.sendReceive(DIOCmdValue.DOCKING.comValue,700,700)
            ConnectionType.USB_OEM -> hostOem.sendReceive(DIOCmdValue.DOCKING.oemValue)
            else -> null
        }
        val comStartArray = byteArrayOf(1, 2)
        val oemStartArray = byteArrayOf(10, 80, 3, 8, 0, 1, 2)
        val (res, barcode) =
            if (connectionType == ConnectionType.USB_COM) splitDockResponseAndBarcode(responseDock, comStartArray)
            else splitDockResponseAndBarcode(responseDock, oemStartArray)
        if (res != null && res.isNotEmpty()) {
            val responseDockStr = res.toString(Charsets.UTF_8)
            val dock = responseDockStr.contains("D")
            if (isDocked != dock) {
                isDocked = dock
                Log.d(TAG, "[checkDocking] $displayName isDocked: $isDocked")
            }
            onCradleListener?.onDockListener(isDocked)
        }
        if (barcode != null && barcode.isNotEmpty()) {
            Log.d(TAG, "[checkDocking] processReceivedData barcode after send DOCKING: ${byteArrayToHexString(barcode)}")
            if (connectionType == ConnectionType.USB_COM) {
                processReceivedData(barcode)
            } else {
                handleBarcodeDataReceivedOEM(barcode)
            }
        }
    }

//    private fun checkLinking() {
//        val linkResponse = when (connectionType) {
//            ConnectionType.USB_COM -> serviceSerial.sendReceive(DIOCmdValue.LINKING.comValue,700,700)
//            ConnectionType.USB_OEM -> hostOem.sendReceive(DIOCmdValue.LINKING.oemValue)
//            else -> null
//        }
//        val (res2, barcode2) = splitDockResponseAndBarcode(linkResponse, connectionType == ConnectionType.USB_OEM)
//        if (res2 != null && res2.isNotEmpty()) {
//            val linkResponseStr = res2.toString(Charsets.UTF_8)
//            val link = linkResponseStr.contains("Crad_IsInserted", true)
//            if (isLinked != link) {
//                isLinked = link
//                Log.d(TAG, "[checkLinking] $displayName isLinked: $isLinked")
//            }
//            onCradleListener?.onLinkListener(isLinked)
//        }
//        if (barcode2 != null && barcode2.isNotEmpty()) {
//            Log.d(TAG, "[checkLinking] processReceivedData barcode2 after send LINKING: ${byteArrayToHexString(barcode2)}")
//            processReceivedData(barcode2)
//        }
//    }

    fun isDeviceStillConnected(context: Context, device: UsbDevice): Boolean {
        val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val currentDevices = manager.deviceList.values
        return currentDevices.any { it.vendorId == device.vendorId && it.productId == device.productId }
    }

    private fun checkScale() {
        if (serviceSerial == null) {
            Log.d(TAG, "Cannot check scale status due to serial port is not available")
            return
        }

        try {
            // Send scale check command
            if (connectionType == ConnectionType.USB_COMSC) {
                // Send through the host port for COM devices
                val response = serviceSerial.sendReceiveHost(SCALE_STATUS_CMD, 700, 700)
                if (response != null && response.isNotEmpty()) {
                    val ENGLISH_UNIT: Char = '0'      // 0x30
                    val METRIC_UNIT: Char = '1'        // 0x31
                    val ENABLE_SCALE: Char = '0'      // 0x30
                    val DISABLE_SCALE: Char = '1'      // 0x31

                    val unitChar = response[3]
                    if (unitChar.toInt().toChar() == ENGLISH_UNIT) {
                        unitScale = ScaleUnit.LB
                    } else if (unitChar.toInt().toChar() == METRIC_UNIT) {
                        unitScale = ScaleUnit.KG
                    }

                    val enableChar = response[4]
                    if (enableChar.toInt().toChar() == ENABLE_SCALE) {
                        enableScale = true
                    } else if (enableChar.toInt().toChar() == DISABLE_SCALE) {
                        enableScale = false
                    }
                }
            } else {
                isEnglishWeighMode = checkIfEnglishWeightModeOEM()

                if (isEnglishWeighMode) {
                    unitScale = ScaleUnit.LB
                } else {
                    unitScale = ScaleUnit.KG
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting weight", e)
        }
    }

    /**
     * Process received data that may contain both scale and barcode data
     * @param data The raw data received from the device
     */
    private fun processReceivedData(data: ByteArray) {
        if (data.isEmpty()) return

        val fullString = String(data, StandardCharsets.UTF_8).trim()
        Log.i(TAG, "Processing received data: $fullString")

        // Look for S14 pattern anywhere in the string
        val s14Index = fullString.indexOf("S14")

        if (s14Index != -1) {
            // Find the end of scale data by looking for carriage return (\r) or newline (\n)
            var scaleEndIndex = fullString.length // Default to end of string if no terminator found

            // Look for carriage return starting from S14 position
            val crIndex = fullString.indexOf('\r', s14Index)
            val lfIndex = fullString.indexOf('\n', s14Index)

            // Use the first terminator found (CR or LF)
            when {
                crIndex != -1 && lfIndex != -1 -> {
                    scaleEndIndex = minOf(crIndex, lfIndex)
                }

                crIndex != -1 -> {
                    scaleEndIndex = crIndex
                }

                lfIndex != -1 -> {
                    scaleEndIndex = lfIndex
                }
                // If no terminator found, keep scaleEndIndex as fullString.length
            }

            // Extract scale data - making sure we don't exceed the string bounds
            scaleEndIndex = minOf(scaleEndIndex, fullString.length)
            val scaleData = fullString.substring(s14Index, scaleEndIndex)
            Log.d(TAG, "Scale data found at index $s14Index: $scaleData")

            val scaleResponse =
                parseScaleResponseCOMSC(scaleData.toByteArray(StandardCharsets.UTF_8))

            // Notify scale listener
            onUsbScaleListener?.onScale(scaleResponse)

            // Now handle any barcode data - could be before and/or after the scale data
            val beforeScaleData = if (s14Index > 0) fullString.substring(0, s14Index) else ""

            // For after scale data, skip the terminator character if present
            val afterScaleStartIndex = if (scaleEndIndex < fullString.length &&
                (fullString[scaleEndIndex] == '\r' || fullString[scaleEndIndex] == '\n')
            ) {
                scaleEndIndex + 1
            } else {
                scaleEndIndex
            }

            val afterScaleData = if (afterScaleStartIndex < fullString.length) {
                fullString.substring(afterScaleStartIndex)
            } else {
                ""
            }

            if (beforeScaleData.isNotEmpty()) {
                Log.i(TAG, "Barcode data before scale: $beforeScaleData")
                val barcodeType = extractLabelCodeType(beforeScaleData)
                if (barcodeType != null) {
                    onUsbScanListener?.onScan(
                        UsbScanData(
                            beforeScaleData.toByteArray(StandardCharsets.UTF_8),
                            beforeScaleData,
                            barcodeType
                        )
                    )
                } else {
                    onUsbScanListener?.onScan(
                        UsbScanData(
                            beforeScaleData.toByteArray(StandardCharsets.UTF_8),
                            beforeScaleData,
                            ""
                        )
                    )
                }
            } else if (afterScaleData.isNotEmpty()) {
                Log.i(TAG, "Barcode data after scale: $afterScaleData")
                val barcodeType = extractLabelCodeType(afterScaleData)
                if (barcodeType != null) {
                    onUsbScanListener?.onScan(
                        UsbScanData(
                            afterScaleData.toByteArray(StandardCharsets.UTF_8),
                            afterScaleData,
                            barcodeType
                        )
                    )
                } else {
                    onUsbScanListener?.onScan(
                        UsbScanData(
                            afterScaleData.toByteArray(StandardCharsets.UTF_8),
                            afterScaleData,
                            ""
                        )
                    )
                }
            }
        } else {
            // No scale data prefix, process entire string as barcode
            Log.i(TAG, "Processing as barcode: $fullString")
            val barcodeType = extractLabelCodeType(fullString)
            if (barcodeType != null) {
                onUsbScanListener?.onScan(
                    UsbScanData(
                        fullString.toByteArray(StandardCharsets.UTF_8),
                        fullString,
                        barcodeType
                    )
                )
            } else {
                onUsbScanListener?.onScan(
                    UsbScanData(
                        fullString.toByteArray(StandardCharsets.UTF_8),
                        fullString,
                        ""
                    )
                )
            }
        }
    }

    private fun handleBarcodeDataReceivedOEM(data: ByteArray) {
        Log.d(TAG, "Data size[${data.size}] --- OEM barcode data received: ${byteArrayToHexString(data)}")

        val chunks = data.toList().chunked(NUMERIC_DATA_LENGTH_64)
        var dataTmp = ByteArray(0)

        for ((i, chunk) in chunks.withIndex()) {
            val part = chunk.toByteArray()
            val length = part[0].toInt() and 0xFF
            if (length <= NUMERIC_4) {
                Log.d(TAG, "Response length <= 4")
                continue
            }
            val identifier = extractIdentifier(part, length)
            val labelTypeHex = convertByteToHexString(identifier)

            if (labelTypeHex == BarcodeType.EAN_JAN_13.hexValue || labelTypeHex == BarcodeType.EAN_JAN_8.hexValue ||
                labelTypeHex == BarcodeType.UPC_A.hexValue || labelTypeHex == BarcodeType.UPC_E.hexValue) {
                Log.d(TAG, "Label is EAN_JAN_13/EAN_JAN_8/UPC_A/UPC_E")
                processBarcodeDetails(part, length)
            } else if (isContinuation(part, length)) {
                val newArray = ByteArray(dataTmp.size + part.size)
                System.arraycopy(dataTmp, 0, newArray, 0, dataTmp.size)
                System.arraycopy(part, 0, newArray, dataTmp.size, part.size)
                dataTmp = newArray
                Log.d(TAG, "New dataTmp size: ${dataTmp.size}")
                continue
            } else if (dataTmp.isEmpty()) {
                val newArray = ByteArray(part.size)
                System.arraycopy(part, 0, newArray, 0, part.size)
                dataTmp = newArray
                Log.d(TAG, "Label 1 packet size: ${dataTmp.size}")
            } else {
                val newArray = ByteArray(dataTmp.size + part.size)
                System.arraycopy(dataTmp, 0, newArray, 0, dataTmp.size)
                System.arraycopy(part, 0, newArray, dataTmp.size, part.size)
                dataTmp = newArray
                Log.d(TAG, "Label multi packets size: ${dataTmp.size}")
            }
            when {
                dataTmp.size == NUMERIC_DATA_LENGTH_64 -> {
                    Log.d(TAG, "Single Data Label")
                    val length = dataTmp[0].toInt() and 0xFF
                    if (length > NUMERIC_4) {
                        processBarcodeDetails(dataTmp, length)
                    } else {
                        Log.d(TAG, "Response message : $dataTmp")
                    }
                }
                dataTmp.size > NUMERIC_DATA_LENGTH_64 -> {
                    Log.d(TAG, "Multiple Data Label")
                    processLargerBarcodeDetails(dataTmp)
                }
                else -> {
                    Log.d(TAG, "Less than 64 bytes")
                }
            }
            Log.d(TAG, "Reset dataTmp")
            dataTmp = ByteArray(0)
        }
    }

    /**
     * Enhanced barcode processing with device-specific and barcode type-specific handling.
     * Maintains compatibility with existing processBarcodeDetails functionality.
     *
     * @param data Raw barcode data array
     * @param length Length of barcode data
     */
    private fun processBarcodeDetails(data: ByteArray, length: Int) {
        Log.d(TAG, "processBarcodeDetails called with length: $length")

        val identifier = extractIdentifier(data, length)
        val labelTypeHex = convertByteToHexString(identifier)

        Log.d(TAG, "Label type identifier: $labelTypeHex")

        // Check if this is a Magellan-9800i device AND an EAN/UPC family barcode
        when {
            isMagellanDeviceAndOEMInterface() && isEanUpcFamilyBarcode(labelTypeHex) -> {
                Log.d(
                    TAG,
                    "Processing EAN/UPC family barcode for Magellan device with OEM interface"
                )
                processMagellanOEMEanUpcBarcode(data, length, identifier, labelTypeHex)
            }

            else -> {
                Log.d(TAG, "Processing standard barcode using existing logic")
                // Use existing logic for non-EAN/UPC barcodes
                processStandardEanUpcBarcode(data, length, identifier, labelTypeHex)
            }
        }
    }

    private fun processLargerBarcodeDetails(data: ByteArray) {
        Log.d(TAG, "Processing large barcode data of size ${data.size}")

        val identifier = extractIdentifier(data, NUMERIC_DATA_LENGTH_64)
        val labelTypeHex = convertByteToHexString(identifier)

        when {
            isMagellanDeviceAndOEMInterface() && isEanUpcFamilyBarcode(labelTypeHex) -> {
                Log.d(
                    TAG,
                    "Processing EAN/UPC family barcode for Magellan device with OEM interface"
                )
                processMagellanOEMEanUpcBarcode(data, null, identifier, labelTypeHex)
            }

            else -> {
                Log.d(TAG, "Processing standard barcode using existing logic")
                // Use existing logic for non-EAN/UPC barcodes
                processStandardEanUpcBarcode(data, null, identifier, labelTypeHex)
            }
        }
    }

    /**
     * Check if the barcode belongs to EAN/UPC family.
     * Uses existing BarcodeType enum for consistent detection.
     *
     * @param labelTypeHex Hex string representation of label type identifier
     * @return true if barcode is EAN/UPC family, false otherwise
     */
    private fun isEanUpcFamilyBarcode(labelTypeHex: String): Boolean {
        // First try the existing BarcodeType enum with proper hex formatting
        val hexWithPrefix = if (labelTypeHex.startsWith("0x")) {
            labelTypeHex.uppercase()
        } else {
            "0x${labelTypeHex.uppercase()}"
        }

        val barcodeType = BarcodeType.fromHexValue(hexWithPrefix)

        if (barcodeType != null) {
            val isEanUpcFromEnum = barcodeType.getKeyValueString().let { symbologyName ->
                symbologyName.contains("UPC", ignoreCase = true) ||
                        symbologyName.contains("EAN", ignoreCase = true) ||
                        symbologyName.contains("JAN", ignoreCase = true)
            }

            if (isEanUpcFromEnum) {
                Log.d(
                    TAG,
                    "EAN/UPC barcode detected via BarcodeType enum: ${barcodeType.getKeyValueString()}"
                )
                return true
            }
        }

        return false
    }

    /**
     * Special processing for EAN/UPC barcodes on Magellan-9800i devices.
     * For EAN/UPC family: display decimal values directly as string without conversion.
     *
     * @param data Raw barcode data array
     * @param length Length of barcode data
     * @param identifier Label type identifier bytes
     * @param labelTypeHex Hex string representation of label type
     */
    private fun processMagellanOEMEanUpcBarcode(
        data: ByteArray,
        length: Int?,
        identifier: ByteArray,
        labelTypeHex: String
    ) {
        Log.d(TAG, "Processing EAN/UPC barcode with identifier: $labelTypeHex")
        var barcodeContent = ByteArray(0)

        if (length != null) {
            // Extract barcode content (skip length byte at index 0 and identifier at the end)
            val dataEnd = length - identifier.size
            barcodeContent = data.copyOfRange(NUMERIC_4, dataEnd)
        } else {
            val barcodeStream = ByteArrayOutputStream()

            val chunkSize = NUMERIC_DATA_LENGTH_64
            val totalChunks = data.size / chunkSize

            repeat(totalChunks) { i ->
                val start = i * chunkSize
                val length = data[start].toInt()
                val chunk = data.copyOfRange(start + NUMERIC_4, start + length - identifier.size)
                barcodeStream.write(chunk)
            }

            barcodeContent = barcodeStream.toByteArray()
        }

        // Display barcode data - decimal values converted directly to string
        val barcodeString = barcodeContent.joinToString("") { (it.toInt() and 0xFF).toString() }

        Log.d(TAG, "EAN/UPC barcode content (decimal to string): $barcodeString")
        Log.d(
            TAG,
            "Raw decimal bytes: ${barcodeContent.joinToString(", ") { (it.toInt() and 0xFF).toString() }}"
        )

        // Use existing getLabelType function that leverages BarcodeType enum
        val baseSymbology = getLabelType(labelTypeHex) ?: "Unknown Barcode Type"

        var displayData = barcodeString.toByteArray(Charsets.UTF_8)
        if (barcodeContent.size != barcodeString.length) {
            val barcodeAscii = barcodeContent.toString(Charsets.UTF_8)
            displayData = barcodeAscii.toByteArray(Charsets.UTF_8)
            Log.d(TAG, "(USB OEM UPC EAN Data Format ASCII) barcode: $barcodeAscii")
        }

        var rawLabel = data
        if (length != null) {
            rawLabel = data.copyOfRange(0, length)
        }
        val decoded = displayData.toString(Charsets.UTF_8)

        try {
            Log.i(TAG, "Barcode type: $baseSymbology")
            Log.i(TAG, "rawLabel: ${byteArrayToHexStringForLog(rawLabel)}")
            Log.i(TAG, "Decoded data: $decoded")
        } catch (e: Exception) {}

        onUsbScanListener?.onScan(UsbScanData(rawLabel, decoded, baseSymbology))
    }

    /**
     * Standard processing for EAN/UPC barcodes on non-Magellan-9800i devices.
     * Uses existing logic for other devices.
     *
     * @param data Raw barcode data array
     * @param length Length of barcode data
     * @param identifier Label type identifier bytes
     * @param labelTypeHex Hex string representation of label type
     */
    private fun processStandardEanUpcBarcode(
        data: ByteArray,
        length: Int?,
        identifier: ByteArray,
        labelTypeHex: String
    ) {
        Log.d(TAG, "Processing EAN/UPC barcode for standard device with identifier: $labelTypeHex")
        var barcodeContent: ByteArray


        if (length != null) {
            val dataEnd = length - identifier.size
            barcodeContent = data.copyOfRange(NUMERIC_4, dataEnd)
        } else {
            // For larger data, concatenate all chunks
            val barcodeStream = ByteArrayOutputStream()

            val chunkSize = NUMERIC_DATA_LENGTH_64
            val totalChunks = data.size / chunkSize

            repeat(totalChunks) { i ->
                val start = i * chunkSize
                val length = data[start].toInt()
                val chunk = data.copyOfRange(start + NUMERIC_4, start + length - identifier.size)
                barcodeStream.write(chunk)
            }

            barcodeContent = barcodeStream.toByteArray()
        }

        // Use existing concatBarcodeData logic for standard devices
        val message = concatBarcodeData(barcodeContent)
        val symbology = getLabelType(labelTypeHex) ?: labelTypeHex

        Log.d(TAG, "Standard Symbology: $symbology")

        // Display using existing standard processing
        displayBarcodeData(message, symbology, identifier)
    }

    private fun isMagellanDeviceAndOEMInterface(): Boolean {
        return deviceType == DeviceType.FRS && connectionType == ConnectionType.USB_OEM
    }

    private fun extractIdentifier(data: ByteArray, length: Int): ByteArray {
        return when (data[length - 1].toInt()) {
            BYTE_DATA_00 -> data.copyOfRange(length - NUMERIC_4, length)
            BYTE_DATA_0B -> byteArrayOf(0x00, data[length - 2], data[length - 1])
            else -> byteArrayOf(data[length - 1])
        }
    }

    private fun isContinuation(data: ByteArray, length: Int): Boolean {
        val identifier = when (data[length - 1].toInt()) {
            BYTE_DATA_00-> data.copyOfRange(length - NUMERIC_4, length)
            BYTE_DATA_0B -> byteArrayOf(data[length - 2], data[length - 1])
            else -> byteArrayOf(data[length - 1])
        }
        if (length < identifier.size + 1) {
            return false
        }
        return data[length - identifier.size - 1].toInt() == BYTE_DATA_10
    }

    private fun displayBarcodeData(message: ByteArray?, symbology: String?, identifier: ByteArray) {
        message?.let {
            val rawLabel = it + identifier
            val decoded = it.toString(Charsets.UTF_8)

            Log.i(TAG, "usbMessage size: ${it.size}")
            Log.i(TAG, "rawLabel: ${rawLabel.toString(Charsets.UTF_8)}")
            Log.i(TAG, "decodedData: $decoded")

            onUsbScanListener?.onScan(UsbScanData(rawLabel, decoded, symbology.orEmpty()))
        }
    }

    private fun concatBarcodeData(input: ByteArray): ByteArray = input

    private fun checkIfEnglishWeightModeOEM(): Boolean {
        hostOem.sendScaleCommand(REPORT_SCALE_CONFIG)
        val data = hostOem.receiveOnScaleInterfaceWithTimeout(100, 100)
        if (data != null) {
            val statusByte1 = data.get(1).toInt() and 0xFF  // Second byte (Status Byte 1)
            return (statusByte1 and 0x01) == 0
        }
        return false
    }

    private fun handleScaleDataReceivedOEM(data: ByteArray) {
        // Check if response is valid
        if (data.isEmpty()) {
            Log.e(TAG, "Empty scale data received")
            onUsbScaleListener?.onScale(
                ScaleData("ERROR", "No scale data received", ScaleUnit.NONE)
            )
            return
        }

        Log.d(TAG, "Processing OEM scale data: ${byteArrayToHexString(data)}")

        val statusByte0 = data[0].toInt() and 0xFF  // First byte (Status Byte 0)
        val statusByte1 = data[1].toInt() and 0xFF  // Second byte (Status Byte 1)
        var statusByte2 = 0 // Default to 0 if not available

        // Parse Status Byte 0 - bit positions according to the spec
        val isFlashUpdateInProgress = (statusByte0 and 0x01) != 0
        val isConfigDataResponseFrame = (statusByte0 and 0x02) != 0
        val isExtendedStatusResponse = (statusByte0 and 0x04) != 0
        val isScaleNotReady = (statusByte0 and 0x20) != 0
        val isUnacceptableCommand = (statusByte0 and 0x40) != 0
        val isDeviceNotReady = (statusByte0 and 0x80) != 0

        // Parse Status Byte 1 - bit positions according to the spec
        val isMetricMode = (statusByte1 and 0x01) != 0
        val isFiveDigitWeight = (statusByte1 and 0x02) != 0
        val isWeightDataNotIncluded = (statusByte1 and 0x04) != 0
        val isDataValueError = (statusByte1 and 0x08) != 0
        val isReadError = (statusByte1 and 0x10) != 0
        val isRemoteDisplayRequired = (statusByte1 and 0x20) != 0
        val isScaleHardwareError = (statusByte1 and 0x40) != 0
        val isUndefinedCommand = (statusByte1 and 0x80) != 0

        // Status Byte 2 if available (for extended status)
        if (data.size > 2) {
            statusByte2 = data[2].toInt() and 0xFF

//            // Parse Status Byte 2
//            val isConfigurationSuccessful = (statusByte2 and 0x01) != 0
//            val isScaleUnderZero = (statusByte2 and 0x02) != 0
//            val isScaleOverCapacity = (statusByte2 and 0x04) != 0
//            val isScaleCenterOfZero = (statusByte2 and 0x08) != 0
//            val isScaleRequiresZeroing = (statusByte2 and 0x10) != 0
//            val isScaleWarmupInProgress = (statusByte2 and 0x20) != 0
//            val isDuplicateWeight = (statusByte2 and 0x40) != 0
//            val isConfigurationCoerced = (statusByte2 and 0x80) != 0
        }

        // Determine appropriate scale unit
        val scaleUnit = if (isMetricMode) ScaleUnit.KG else ScaleUnit.LB
        unitScale = scaleUnit // Update the class variable

        // Determine scale status and format weight data
        if (isScaleNotReady || isDeviceNotReady) {
            onUsbScaleListener?.onScale(
                ScaleData("NOT_READY", "NONE", scaleUnit)
            )
        } else if (isUnacceptableCommand) {
            onUsbScaleListener?.onScale(
                ScaleData("UNACCEPTABLE_COMMAND", "NONE", scaleUnit)
            )
        } else if (isUndefinedCommand) {
            onUsbScaleListener?.onScale(
                ScaleData("UNDEFINED_COMMAND", "NONE", scaleUnit)
            )
        } else if (isFlashUpdateInProgress) {
            onUsbScaleListener?.onScale(
                ScaleData("FLASH_UPDATE_IN_PROGRESS", "NONE", scaleUnit)
            )
        } else if (isRemoteDisplayRequired) {
            onUsbScaleListener?.onScale(
                ScaleData("REMOTE_DISPLAY_REQUIRED", "NONE", scaleUnit)
            )
        } else if (isScaleHardwareError) {
            onUsbScaleListener?.onScale(
                ScaleData("HARDWARE_ERROR", "NONE", scaleUnit)
            )
        } else if (isWeightDataNotIncluded) {
            // Process Status Byte 2 conditions
            if ((statusByte2 and 0x02) != 0) { // Scale under zero
                onUsbScaleListener?.onScale(
                    ScaleData("UNDER_ZERO", "NONE", scaleUnit)
                )
            } else if ((statusByte2 and 0x04) != 0) { // Scale over capacity
                onUsbScaleListener?.onScale(
                    ScaleData("OVER_CAPACITY", "NONE", scaleUnit)
                )
            } else if ((statusByte2 and 0x10) != 0) { // Scale requires zeroing
                onUsbScaleListener?.onScale(
                    ScaleData("REQUIRES_ZEROING", "NONE", scaleUnit)
                )
            } else if(isExtendedStatusResponse && statusByte2 == 0){
                onUsbScaleListener?.onScale(
                    ScaleData("UNSTABLE", "NONE", scaleUnit)
                )
            }
        } else if (isDataValueError || isReadError) {
            onUsbScaleListener?.onScale(
                ScaleData("UNSTABLE", "NONE", scaleUnit)
            )
        } else if (statusByte2 != 0) {
            if ((statusByte2 and 0x08) != 0) { // Center of zero (stable zero)
                onUsbScaleListener?.onScale(
                    ScaleData("STABLE_ZERO", "0.00", scaleUnit)
                )
            } else {
                // Process weight data if present
                processWeightData(data, scaleUnit, isFiveDigitWeight)
            }
        } else {
            // Process weight data if present (no status byte 2 issues)
            processWeightData(data, scaleUnit, isFiveDigitWeight)
        }
    }

    /**
     * Process weight data portion of scale response
     * Weight data is in BCD format (Binary-Coded Decimal)
     */
    private fun processWeightData(data: ByteArray, scaleUnit: ScaleUnit, isFiveDigit: Boolean) {
        // Check if response is valid and has enough data for weight
        if (data.size < 8) {  // Scale response should be 8 bytes
            onUsbScaleListener?.onScale(
                ScaleData("ERROR", "Incomplete weight data", scaleUnit)
            )
            return
        }

        // Check if weight data is included (if bit 2 in Status Byte 1 is 0)
        if ((data[1].toInt() and 0x04) != 0) {
            // Weight data not included
            onUsbScaleListener?.onScale(
                ScaleData("STABLE_ZERO", "0.00", scaleUnit)
            )
            return
        }

        try {
            Log.i(TAG, "Raw weight data: ${byteArrayToHexString(data)}")

            // For English weight data, the format is different based on 4-digit vs 5-digit mode
            val digitCount = if (isFiveDigit || scaleUnit == ScaleUnit.KG) 5 else 4

            val weightStr = StringBuilder()

            // Extract digits based on the weight format
            // First digit (tens)
            weightStr.append(data[3].toInt() and 0x0F)
            // Second digit (ones)
            weightStr.append(data[4].toInt() and 0x0F)
            // Third digit (tenths)
            weightStr.append(data[5].toInt() and 0x0F)
            // Fourth digit (hundredths)
            weightStr.append(data[6].toInt() and 0x0F)

            weightStr.append(data[7].toInt() and 0x0F)

            Log.i(TAG, "Extracted weight digits: $weightStr")

            // Format with decimal points
            val formattedWeight = if (scaleUnit == ScaleUnit.KG) {
                // For kg: 5 digits total, 3 decimal places (XX.XXX)
                val intPart = weightStr.take(2).toString()
                val decPart = weightStr.takeLast(3).toString()
                "$intPart.$decPart"
            } else {
                // For lb: Either 4 digits (XX.XX) or 5 digits (XX.XXX)
                if (digitCount == 5) {
                    val intPart = weightStr.take(2).toString()
                    val decPart = weightStr.takeLast(3).toString()
                    "$intPart.$decPart"
                } else {
                    val intPart = weightStr.take(2).toString()
                    val decPart = weightStr.drop(2).take(2).toString()
                    "$intPart.$decPart"
                }
            }

            Log.i(TAG, "Formatted weight: $formattedWeight ${scaleUnit.name}")

            // Notify scale listener with formatted weight
            onUsbScaleListener?.onScale(
                ScaleData("STABLE", formattedWeight, scaleUnit)
            )

        } catch (e: Exception) {
            Log.e(TAG, "Error parsing weight data", e)
            onUsbScaleListener?.onScale(
                ScaleData("ERROR", "Failed to parse weight: ${e.message}", scaleUnit)
            )
        }
    }

    private fun checkDeviceInterface(): ByteArray {
        val command = byteArrayOf(0x00, 0x11, 0x00, 0x01)
        val fullCmd = frsDevice.createFullFRSCommand(command)
        val byteArrayResponse = serviceSerial.sendReceive(
            command = fullCmd,
            startTimeout = 1000,
            endTimeout = 700
        )
        val response = frsDevice.extractMagellanResponseData(byteArrayResponse)

        val interfaceResponse = byteArrayOf(response[0], response[1])

        return interfaceResponse
    }

    /*private val listIfType = arrayOf(
        "05", // RS232 STD
        "47", // USB COM STD
        "12", // RS232 WN
        "40", // USB MAG
        "23", // IBM P9B
        "29", // KBD AT
        "26", // KBD AT ALT
        "11", // KBD AT NK
        "10", // KBD AT ALT NK
        "44", // USB POS
        "41", // USB TEC
        "13", // RS232 OPOS
        "45", // USB OEM
        "35", // USB KBD
        "2B", // USB KBD ALT
        "4D", // USB COMPOSITE
        "43", // RS232 AUX
        "4E", // WIFI STD
        "24"  // x
    )*/

    @Throws(Exception::class)
    private fun setHeader(sb: StringBuffer, customer: String, configNameInput: String) {
        val now = Date()
        val date = SimpleDateFormat("M d yyyy H:m").format(now)
        val year = SimpleDateFormat("yyyy").format(now)

        sb.append(";START OF HEADER\n")
        sb.append(";").append(customer)
        sb.append(" Scanner Configuration File\n")
        sb.append(";Config File Format: 0001\n")
        sb.append(";Master Config File: \n")
        sb.append(";Copyright ").append(year).append(" by ").append(COMPANY_NAME)
            .append("\n")
        sb.append(";Creation Date: ").append(date).append("\n")
        sb.append(";File created by ").append(System.getProperty("user.name")).append("\n")
        sb.append(";").append(VERSION_SDK).append("\n")
        sb.append(";\n")
        sb.append(";START OF COMMANDS\n")
        sb.append(";-------< Initialize >-----------------------------\n")
        sb.append("$$codeIdentifier ; Erase Config Flash\n")
        sb.append(";\n")
        sb.append(";-------< System Configuration >-------------------------------\n")

        var configName = configNameInput
        var configNameHexStr: String?
        if (configNameInput.isBlank()) {
            val response = serviceSerial.sendReceiveString("\$yF\r".toByteArray())
            configNameHexStr = response.cleanUsbOutput()
            configName = hexStringToByteArray(configNameHexStr).toString(Charsets.UTF_8)
        } else {
            configNameHexStr = CharsUtil.asciiStringToHexString(configName)
        }

        sb.append("\$YF").append(configNameHexStr.toUpperCase(Locale.ROOT))
            .append("; CONFIGURATION ID : ").append(configName.trim())
            .append("\n")
        sb.append(";\n")
    }

    private fun setIfType(sb: StringBuffer, ifType: IFType) {
        sb.append(";------<").append(ifType.iF_Type).append(">------")
        sb.append("\n")
        // Write the $M<IF_Type> command to the CCF (load master defaults)
        sb.append("\$M").append(ifType.iF_Value)
        sb.append("               ; Load Master defaults and set to ").append(ifType.iF_Type)
        sb.append("\n")
    }

    private fun setCommitUserAs(sb: StringBuffer) {
        sb.append("\$As                 ; Commit Interface Class to user\n")
    }

    private fun setCommitFactorAS(sb: StringBuffer) {
        sb.append("\$AS                 ; Commit Interface Class to factory\n")
    }

    @Throws(Exception::class)
    private fun defaultInterface(iFType: String, sb: StringBuffer): String {
        // Load the user configuration values using the command $HA<IF_Type>
        serviceSerial.sendReceiveString("\$HA$iFType\r".toByteArray())
        val ifTypeObj = IFType.ifTypeMap[iFType]

        // Read and save all the configuration items
        val confInterfaceType = serviceSerial.sendReceiveString("\$a\r".toByteArray())

        // Write a comment in the CCF to identify the interface class
        ifTypeObj?.let {
            setIfType(sb, ifTypeObj)
        }

        // Compare each configuration item with the master default value
        //if (returnDeviceWithM00(device)) {
        var ifType = ifTypeObj?.iF_Value
        serviceSerial.sendReceiveString("\$M00\r".toByteArray())
        //} else {
        //serviceSerial.sendReceiveString("\$M$ifType".toByteArray())
        //}

        val confMasterDefault = serviceSerial.sendReceiveString("\$a\r".toByteArray())
        val params = compareConf(confInterfaceType, confMasterDefault)
        //Not display default not active
        for (parameter in params) {
            sb.append("\$C").append(parameter).append("\n")
        }

        return confInterfaceType
    }

    @Throws(Exception::class)
    private fun getDefaultNotActiveIF(iFType: String): String {
        // Load the user configuration values using the command $HA<IF_Type>
        serviceSerial.sendReceiveString("\$HA$iFType\r".toByteArray())

        val confInterfaceType = serviceSerial.sendReceiveString("\$a\r".toByteArray())

        serviceSerial.sendReceiveString("\$M00\r".toByteArray())

        return confInterfaceType
    }

    @Throws(Exception::class)
    private fun otherInterface(iFType: String, sb: StringBuffer): Boolean {
        val response = serviceSerial.sendReceiveString("\$HA$iFType\r".toByteArray())
        if (!response.toString().startsWith("\$>")) {
            return false
        }

        val ifTypeObj = IFType.ifTypeMap[iFType]
        val confInterfaceType = serviceSerial.sendReceiveString("\$a\r".toByteArray())

        ifTypeObj?.let {
            setIfType(sb, ifTypeObj)
        }

        //if (returnDeviceWithM00(device)) {
        serviceSerial.sendReceiveString("\$M00\r".toByteArray())
        //} else {
        //device.sendReceiveString("\$M$iFType")
        //}

        val confMasterDefault = serviceSerial.sendReceiveString("\$a\r".toByteArray())
        val params = compareConf(confInterfaceType.toString(), confMasterDefault.toString())

        for (parameter in params) {
            val paramResponse = serviceSerial.sendReceiveString("\$C$parameter\r".toByteArray())
            if (paramResponse.contains(">")) {
                sb.append("\$C").append(parameter)
                sb.append("\n")
            }
        }

        return true
    }

    private fun String.cleanUsbOutput(): String {
        return this.replace("$>", "").replace("\r", "")
    }

    @Throws(Exception::class)
    fun getCCFHHS(customer: String, configName: String): String {
        val sb = StringBuffer()

        // Enter service mode before getting CCF
        Log.d(TAG, "Entering service mode for getCCFHHS")
        enterServiceMode()

        try {
            val response = serviceSerial.sendReceiveString("\$S\r".toByteArray()) // openConfig
            // read all paramters
            val currentConf = serviceSerial.sendReceiveString("\$a\r".toByteArray())
            // read USB interface
            val usbIFTYPE =
                serviceSerial.sendReceiveString("\$hU\r".toByteArray()).cleanUsbOutput().uppercase()

            // read Non USB interface
            val nonUsbIFTYPE =
                serviceSerial.sendReceiveString("\$hN\r".toByteArray()).cleanUsbOutput().uppercase()
            // read currrent interface
            val currentIFTYPE =
                serviceSerial.sendReceiveString("\$hA\r".toByteArray()).cleanUsbOutput().uppercase()

            var defaultIfTypeNotActive = ""
            if (!nonUsbIFTYPE.contains("%") && !usbIFTYPE.contains("%")) {
                defaultIfTypeNotActive = if (currentIFTYPE != nonUsbIFTYPE) {
                    nonUsbIFTYPE
                } else {
                    usbIFTYPE
                }
            } else if ((nonUsbIFTYPE.contains("%") && !usbIFTYPE.contains("%")) ||
                (!nonUsbIFTYPE.contains("%") && usbIFTYPE.contains("%"))
            ) {
                defaultIfTypeNotActive = ""
            }

            setHeader(sb, customer, configName)

            // Default Active Interface
            defaultInterface(currentIFTYPE, sb)
            setCommitUserAs(sb)
            setCommitFactorAS(sb)
            sb.append(";\n")

            // Default Not Active Interface
            var confDefaultIfTypeNotActive = ""
            if (defaultIfTypeNotActive.isNotEmpty()) {
                // Default Not Active Interface
                confDefaultIfTypeNotActive = getDefaultNotActiveIF(defaultIfTypeNotActive)
                // Write the $As command to the CCF (saving to user)
                //setCommitUserAs(sb)
            }

            //Only support current interface
            /*var usbIFTYPEClass = ""
            if (!usbIFTYPE.contains("%")) {
                usbIFTYPEClass = IFType.ifTypeMap[usbIFTYPE]?.iF_Class.orEmpty()
            }

            var nonUsbIFTYPEClass = ""
            if (!nonUsbIFTYPE.contains("%")) {
                nonUsbIFTYPEClass = IFType.ifTypeMap[nonUsbIFTYPE]?.iF_Class.orEmpty()
                if (usbIFTYPEClass != nonUsbIFTYPEClass) {
                    setCommitFactorAS(sb)
                }
            }
            sb.append(";\n")

            for (ift in listIfType) {
                if (ift == nonUsbIFTYPE || ift == usbIFTYPE) continue

                val iftClass = IFType.ifTypeMap[ift]?.iF_Class
                if (iftClass == nonUsbIFTYPEClass || iftClass == usbIFTYPEClass) continue

                if (otherInterface(ift, sb)) {
                    setCommitFactorAS(sb)
                    sb.append(";\n")
                }
            }*/

            sb.append(";-------< Set Default Host Interface >----\n")
            sb.append("\$HA$defaultIfTypeNotActive               ; Set not active default interface to ")
                .append(IFType.ifTypeMap[defaultIfTypeNotActive]?.iF_Type).append("\n")

            sb.append("\$HA$currentIFTYPE               ; Set active default interface to ")
                .append(IFType.ifTypeMap[currentIFTYPE]?.iF_Type).append("\n")

            // ULE
            sb.append(";-------< User Label Edit Script >----\n")
            val responseUle =
                serviceSerial.sendReceiveString("\$u\r".toByteArray()).cleanUsbOutput()
            val ule = CharsUtil.makeScriptFromCmds(responseUle)
            val cmdUleList = DataUtils.getUleCmdList(ule)
            if (cmdUleList.size > 1) {
                for (elem in cmdUleList) {
                    sb.append(elem).append("\n")
                }
            }

            sb.append(";------< End >-----------------------")

            // Restore old defaultIfTypeNotActive
            serviceSerial.sendReceiveString("\$HA$defaultIfTypeNotActive\r".toByteArray())
            Log.d(TAG, "current NOT ACTIVE INTERFACE : $defaultIfTypeNotActive")
            val actualCurrentConfNotActive =
                serviceSerial.sendReceiveString("\$a\r".toByteArray(Charsets.UTF_8))
            val restoreCmdsNotActive =
                compareConf(confDefaultIfTypeNotActive, actualCurrentConfNotActive)
            Log.d(TAG, "restoreCmdsNotActive")
            restoreConfig(restoreCmdsNotActive)
            serviceSerial.sendReceiveString("\$As\r".toByteArray(Charsets.UTF_8))

            // Restore old current configuration
            serviceSerial.sendReceiveString("\$HA$currentIFTYPE\r".toByteArray(Charsets.UTF_8))
            Log.i(TAG, "currentConf : $currentConf")
            val actualCurrentConf =
                serviceSerial.sendReceiveString("\$a\r".toByteArray(Charsets.UTF_8))
            val restoreCmds = compareConf(currentConf, actualCurrentConf)
            Log.d(TAG, "restoreCmds")
            restoreConfig(restoreCmds)
            serviceSerial.sendReceiveString("\$As\r".toByteArray(Charsets.UTF_8))

            return sb.toString()
        } finally {
            // Exit service mode after getting CCF
            Log.d(TAG, "Exiting service mode for getCCFHHS")
            exitServiceMode()
        }
    }
    private fun restoreConfig(restoreCmds: List<String>) {
        val sbCmdRestore = StringBuilder()
        for ((index, cmd) in restoreCmds.withIndex()) {
            sbCmdRestore.append(cmd)
            if (index < restoreCmds.lastIndex) {
                sbCmdRestore.append(",")
            }

            if (sbCmdRestore.toString().length >= 256) {
                val cmdRestore = sbCmdRestore.toString()
                Log.d(TAG, "cmdRestore: $cmdRestore")
                serviceSerial.sendReceiveString("\$C$cmdRestore\r".toByteArray(Charsets.UTF_8))
                sbCmdRestore.clear()
            }
        }
        if (sbCmdRestore.toString().isNotEmpty()) {
            val cmdRestore = sbCmdRestore.toString()
            Log.d(TAG, "cmdRestore: $cmdRestore")
            serviceSerial.sendReceiveString("\$C$cmdRestore\r".toByteArray(Charsets.UTF_8))
        }
    }

    private fun compareConf(conf1: String, conf2: String): List<String> {
        val diffList = mutableListOf<String>()
        val conf2WithComma = ",$conf2"
        val confList1 = conf1.split(",")

        for (item1 in confList1) {
            if (!conf2WithComma.contains(",$item1")) {
                diffList.add(item1)
            }
        }

        return diffList
    }

    private fun writeCustomConfigurationHHS(configStr: String?): ConfigurationResult {
        // Enter service mode before writing configuration
        Log.d(TAG, "Entering service mode for writeCustomConfigurationHHS")
        enterServiceMode()

        try {
            val cmdList = CharsUtil.getCmdList(configStr)
            val cmdErrorList = mutableListOf<CommandError>()
            for (row in cmdList) {
                val response = serviceSerial.sendReceiveString((row.rowData + "\r").toByteArray())
                if (row.rowData.contains("HA00") || row.rowData.contains("AE")) {
                    Thread.sleep(3000)
                    continue
                }
                // Check error response
                if (!response.startsWith("\$>")) {
                    cmdErrorList.add(
                        CommandError(
                            row.rowNumber,
                            row.rowData,
                            "Invalid response: $response"
                        )
                    )
                }
                Log.d(TAG, "writeCustomConfigurationHHS ${row.rowData} response: $response")
            }
            serviceSerial.sendReceiveString("\$r02\r".toByteArray())

            return ConfigurationResult(
                isSuccess = cmdErrorList.isEmpty(),
                errorCommands = cmdErrorList
            )
        } finally {
            // Exit service mode after writing configuration
            Log.d(TAG, "Exiting service mode for writeCustomConfigurationHHS")
            exitServiceMode()
        }
    }

    private fun writeCustomConfigurationFRS(configStr: String?): ConfigurationResult {
        var cmdList = CharsUtil.getCmdList(configStr)
        val cmdErrorList = mutableListOf<CommandError>()
        cmdList = CharsUtil.frsCCFExtractCmds(cmdList)!!
        for (row in cmdList) {
            val cmd = row.rowData.substring(0, row.rowData.length - 2)
            val byteCmd = hexStringToByteArray(cmd)
            val response = serviceSerial.sendReceive(
                frsDevice.createFullFRSCommand(
                    FRSScannerTypes.WRITE_CONFIGURATION_ITEM + byteCmd
                ), 500, 200
            )
            // retry if response is SYN (0x16) happens when device got reset error (product issue)
            if (response != null && response.contentEquals(FRSContants.SYN)) {
                Log.w(TAG, "Retrying command at Line ${row.rowNumber} : ${row.rowData}")
                serviceSerial.sendReceive(
                    frsDevice.createFullFRSCommand(
                        FRSScannerTypes.WRITE_CONFIGURATION_ITEM + byteCmd
                    ), 500, 200
                )
            }

            // Check error response
            if (response != null && !response.contentEquals(FRSContants.ACK)) {
                Log.e(TAG, "Error writing command at Line ${row.rowNumber} : ${row.rowData}")
                cmdErrorList.add(
                    CommandError(
                        row.rowNumber,
                        row.rowData,
                        "Response: ${response.contentToString()}"
                    )
                )
            }

            Log.d(TAG, "writeCustomConfigurationFRS ${row.rowData} response: ${response?.get(0)}")
        }
        serviceSerial.sendReceiveString("\$r02\r".toByteArray())

        return ConfigurationResult(
            isSuccess = cmdErrorList.isEmpty(),
            errorCommands = cmdErrorList
        )
    }

    fun writeCustomConfiguration(configStr: String?): ConfigurationResult {
        return if (deviceType == DeviceType.HHS) {
            writeCustomConfigurationHHS(configStr)
        } else {
            writeCustomConfigurationFRS(configStr)
        }
    }

    private fun readAllConfigFromDevice(): ByteBuffer {
        val startTimeout: Long = 5000
        val endTimeout: Long = 500

        var response = serviceSerial.sendReceive(
            frsDevice.createFullFRSCommand(FRSScannerTypes.CONFIGURATION_READ),
            startTimeout, endTimeout
        )
        if (response == null) throw IllegalStateException("response from CONFIGURATION_READ == null")
        if (response[0] == 0x2B.toByte()) {
            Log.d(TAG, "[readAllConfigFromDevice] retry CONFIGURATION_READ")
            response = serviceSerial.sendReceive(
                frsDevice.createFullFRSCommand(FRSScannerTypes.CONFIGURATION_READ),
                startTimeout, endTimeout
            )
        }
        response = parseScannerResponse(response!!, "CONFIGURATION_READ")["data"] as? ByteArray
        val fullResponse = ByteArrayOutputStream(300)

        Log.d(TAG, "[readAllConfigFromDevice] response CONFIGURATION_READ != null")
        while (response!!.size > 3) {
            fullResponse.write(response, 2, response.size - 2)

            response = serviceSerial.sendReceive(
                frsDevice.createFullFRSCommand(FRSScannerTypes.READ_SUCCESSIVE_CONFIGURATION_GROUPS),
                startTimeout, endTimeout
            )

            if (response == null) throw IllegalStateException("response from READ_SUCCESSIVE_CONFIGURATION_GROUPS == null")
            if (response[0] == 0x2B.toByte()) {
                Log.d(TAG, "[readAllConfigFromDevice] retry READ_SUCCESSIVE_CONFIGURATION_GROUPS")
                response = serviceSerial.sendReceive(
                    frsDevice.createFullFRSCommand(FRSScannerTypes.READ_SUCCESSIVE_CONFIGURATION_GROUPS),
                    startTimeout, endTimeout
                )
            }
            response = parseScannerResponse(response!!, "READ_SUCCESSIVE_CONFIGURATION_GROUPS")["data"] as? ByteArray
        }

        return ByteBuffer.wrap(fullResponse.toByteArray())
    }

    private fun ByteBuffer.toConfigurationList(): List<Configuration> {
        val configs = mutableListOf<Configuration>()

        if (remaining() > 2) {
            while (remaining() > 0) {
                val tagPair = frsDevice.getNextTagFromBuffer(this)
                configs.add(
                    Configuration(
                        tagName = tagPair.first,
                        value = tagPair.second!!
                    )
                )
            }
        }

        return configs
    }

    @Throws(Exception::class)
    private fun setSystemInterface(
        sb: StringBuffer,
        configNameInput: String // Renamed to avoid conflict with reassigned variable
    ) {
        // Sending command
        serviceSerial.sendReceive(
            frsDevice.createFullFRSCommand(
                FRSScannerTypes.WRITE_CONFIGURATION_ITEM
            ), 500, 200
        )

        sb.append("#-------< System Interface >-------------------------------\r\n")
        sb.append(addChecksum("00010046")?.let { formatLine(it, "INTERFACE TYPE: System") })

        val configIDHex = CharsUtil.asciiStringToHexString(configNameInput) //ConfigName???
        val configIDCmd = addChecksum("0060$configIDHex") // String template for concatenation
        val configIDLine = configIDCmd?.let { formatLine(it, "Configuration File ID", configNameInput) }
        sb.append(configIDLine)
        sb.append(addChecksum("7FFD01")?.let { formatLine(it, "Save interface to user area") })
    }

    @Throws(Exception::class) // Keep if underlying calls can throw checked exceptions
    private fun setHeaderFRS(
        sb: StringBuffer,
        configNameInput: String,
        customer: String
    ) {
        val now = Date()
        // It's good practice to specify Locale for date formatting to avoid regional differences
        val dateFormatter =
            SimpleDateFormat("MMM d, yyyy", Locale.US) // Or Locale.getDefault() if appropriate
        val yearFormatter = SimpleDateFormat("yyyy", Locale.US) // Or Locale.getDefault()

        val date = dateFormatter.format(now)
        val year = yearFormatter.format(now)

        val deviceName = readMagellanVersion()

        sb.append("CF0X 0070\r\n")
        sb.append("Copyright ").append(COMPANY_NAME).append(" ").append(year).append("\r\n")
        sb.append("ID CONFIG,").append(configNameInput.trim()).append(",").append(customer)
            .append(",").append(deviceName).append(",\r\n") // Keep comma at the end if intended
        sb.append("FC ").append(date).append("\r\n")
        sb.append("# File created by ").append(System.getProperty("user.name")).append("\r\n")
        sb.append("# ").append(VERSION_SDK).append("\r\n")

        sb.append("&\r\n")
        sb.append("# Master file: ").append("\r\n")
        sb.append("#\r\n")

        setSystemInterface(sb, configNameInput)
    }

    @Throws(Exception::class)
    private fun setInterfaceFRS(sb: StringBuffer, currentInterface: FRSInterface) {
        sb.append("# Interface Block The Following Interfaces:\r\n")
        sb.append("#-----<${currentInterface.name}>-----\r\n")
        sb.append(frsDevice.generateInterfaceHeader(currentInterface))
        Log.d(TAG, "[setInterfaceFRS] readAllConfigFromDevice currentConfigList")
        val currentConfigList = readAllConfigFromDevice().toConfigurationList()
        Log.d(TAG, "[setInterfaceFRS] RESTORE_CONFIGURATION")
        serviceSerial.sendReceiveString(frsDevice.createFullFRSCommand(FRSScannerTypes.RESTORE_CONFIGURATION))
        Log.d(TAG, "[setInterfaceFRS] readAllConfigFromDevice")
        val defaultConfigList = readAllConfigFromDevice().toConfigurationList()
        Log.d(TAG, "[setInterfaceFRS] getDifferencesFRSConfig defaultConfigList")
        val configList = SmartUtil.getDifferencesFRSConfig(currentConfigList, defaultConfigList)
        Log.d(TAG, "[setInterfaceFRS] compare")

        var cmdHex = ""
        try {
            for (item in configList) {
                if (isSealedTag(item.tagName)) continue
                sb.append(CharsUtil.generateConfigFile(item))
                sb.append("\r\n")
                cmdHex = "${item.tagName}${item.value}"
                val cmd = hexStringToByteArray(cmdHex)
                val writeResponse = serviceSerial.sendReceive(
                    frsDevice.createFullFRSCommand(FRSScannerTypes.WRITE_CONFIGURATION_ITEM + cmd),
                    500, 200
                )
                Log.d(TAG, "writeResponse: ${writeResponse?.get(0)}")
            }
        } catch (e: Exception) {
            throw Exception("${e.message} -- command: $cmdHex", e)
        }

        sb.append(frsDevice.commit(copyToLevel))
        sb.append("#\r\n")
        Log.d(TAG, "[setInterfaceFRS] done")
    }

    private fun isSealedTag(tagName: String): Boolean {
        val clean = tagName.trim().removePrefix("0x").removePrefix("0X")
        val norm  = clean.uppercase().padStart(4, '0')
        return norm in FRSScannerTypes.SEALED_TAGS
    }

    private fun setTrailer(sb: StringBuffer, ule: String, activeInterface: FRSInterface?) {
        sb.append("#-------< Set active interface to " + activeInterface?.name + " and copy to user area >----\r\n")
        sb.append(addChecksum(FRSDevice.CI_INTERFACE_TYPE + activeInterface?.value) + "\r\n")
        sb.append(addChecksum("7FFD01")?.let { formatLine(it, "Save interface to user area") })
        frsDevice.setULE(sb, ule)
        sb.append("$\r\n")
    }

    private fun getCCFFRS(customer: String, configName: String): String {
        val sb = StringBuffer()
        try {
            val productName = usbDevice.productName ?: ""
            setHeaderFRS(sb, configName, customer)
            getCurrentFRSInterface()?.let { setInterfaceFRS(sb, it) }
            setTrailer(
                sb, frsDevice.readUle(serviceSerial),
                getCurrentFRSInterface()
            )
        } catch (ex: Exception) {
            val msgError = ex.message.toString()
            Log.e(TAG, "Failed to get config: $msgError")
            onUsbDioListener?.fireDioErrorEvent(CONFIG_ERR_FAILURE, "$msgError - code: ")
            return sb.toString()
        }
        return sb.toString()
    }

    private fun getCurrentFRSInterface(): FRSInterface? {
        var currentInterface: FRSInterface? = null

        try {
            val response = serviceSerial.sendReceive(
                frsDevice.createFullFRSCommand(
                    FRSScannerTypes.READ_CURRENT_INTERFACE
                ), 500, 200
            )
            try {
                val result = response?.let { parseScannerResponse(it) }
                val data = result?.get("data") as ByteArray
                currentInterface = FRSDevice.frsInterfaceList.find {
                    it.value == byteArrayToHexString(data)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to parse: ${e.message}")
            }
        } catch (ex: Exception) {
            ex.stackTrace.forEach { println(it) }
        }
        return currentInterface
    }

    fun getCustomConfiguration(customer: String = COMPANY_NAME, configNameInput: String = "0000000001"): String {
        var configName = configNameInput
        configName = if (configName.length > 10) {
            configName.substring(0, 10)
        } else {
            configName.padEnd(10, ' ')
        }
        return if (deviceType == DeviceType.HHS) {
            getCCFHHS(customer, configName)
        } else {
            getCCFFRS(customer, configName)
        }
    }

    private fun getFirmwareUpdater(firmwareFile: File, fileType: String = "", context: Context, isUpgradeBoot: Boolean): FirmwareUpdater? {
//        firmwareUpdater?.let { return it }
        Log.d(TAG, "getFirmwareUpdater")
        when (fileType) {
            S37 -> {
                firmwareUpdater = if (deviceType == DeviceType.HHS) {
                    FirmwareS37HHSUpdater(
                        firmwareFile,
                        usbDevice.productName.toString(),
                        serviceSerial, false
                    )
                } else {
                    FirmwareS37FRSUpdater(serviceSerial, firmwareFile, frsDevice, false)
                }
            }

            SWU -> firmwareUpdater = FirmwareSWUUpdater(firmwareFile, serviceSerial, frsDevice, false)
            DFW -> firmwareUpdater = UpgradeDFW(firmwareFile, this, context, isUpgradeBoot)
        }
        return firmwareUpdater
    }

    fun upgradeFirmware(
        file: File,
        fileType: String,
        context: Context,
        resetCallback: () -> Unit,
        progressCallback: (Int) -> Unit,
        isBulkTransfer: Boolean,
        onFailure: (String) -> Unit,
        onComplete: () -> Unit,
        isUpgradeBoot: Boolean = false
    ): Boolean {
        try {
            loadFirmwareFile(file, fileType, context, {  }, { }, isUpgradeBoot)
            upgradeLoadedFirmware(resetCallback, progressCallback, isBulkTransfer, onFailure, onComplete, isUpgradeBoot)
        } catch (ex: Exception){
            onFailure(ex.message.toString())
            return false
        }
        return true
    }

    fun upgradeLoadedFirmware(
        resetCallback: () -> Unit,
        progressCallback: (Int) -> Unit,
        isBulkTransfer: Boolean,
        onFailure: (String) -> Unit,
        onComplete: () -> Unit,
        isUpgradeBoot: Boolean = false
    ): Boolean {
        try {
            firmwareUpdater?.isUpgradeBoot = isUpgradeBoot
            if (deviceType == DeviceType.HHS) {
                firmwareUpdater?.upgrade(progressCallback, resetCallback, onComplete, isUpgradeBoot)
            } else {
                if (isBulkTransfer && isBulkTransferSupported() == true) {
                    firmwareUpdater?.upgradeByBulkTransfer(progressCallback)
                } else
                    firmwareUpdater?.upgrade(progressCallback, resetCallback, onComplete, isUpgradeBoot)
            }
            resetDevice()
        } catch (ex: Exception) {
            onFailure(ex.message.toString())
            return false
        }
        return true
    }

    fun loadFirmwareFile(
        file: File,
        fileType: String,
        context: Context,
        onCompleteLoadFirmware: () -> Unit,
        progressCallback: (Int) -> Unit,
        isUpgradeBoot: Boolean = false
    ) {
        firmwareUpdater = getFirmwareUpdater(file, fileType, context, isUpgradeBoot)
        firmwareUpdater?.loadFirmwareFile(
            onCompleteLoading = onCompleteLoadFirmware,
            progressCallback = progressCallback
        )
    }

    fun resetDevice(): Int {
        if (status.value != DeviceStatus.OPENED) {
            Log.e(TAG, "Device not opened, cannot reset")
            return FAILURE
        }

        try {

            if (deviceType == DeviceType.HHS) {
                serviceSerial.send(HandHeldResetDevice)
                Log.d(TAG, "Handheld Scanner device reset command sent successfully")
                return SUCCESS
            }
            // Create the reset command
            val resetCommand = frsDevice.createFullFRSCommand(RESET_DEVICE_CMD)

            // Send the reset command
            serviceSerial.send(resetCommand)

            Log.d(TAG, "Device reset command sent successfully")

            return SUCCESS
        } catch (e: Exception) {
            Log.e(TAG, "Error sending device reset command", e)
        }

        return FAILURE
    }


    fun getPid(file: File?, fileType: String, context: Context, isUpgradeBoot: Boolean = false): String? {
        val firmwareUpdater = file?.let { getFirmwareUpdater(it, fileType, context, isUpgradeBoot) }
        return firmwareUpdater?.getPid(file)
    }

    fun getPidDFW(file: File?, fileType: String, context: Context): String? {
        return firmwareUpdater?.getPid(file)
    }

    fun isBulkTransferSupported(): Boolean? {
        return if (deviceType == DeviceType.HHS) {
            false
        } else {
            firmwareUpdater?.isSupportedBulkTransfer()
        }
    }

    fun isCheckPid(file: File?, fileType: String, context: Context): Boolean? {
        firmwareUpdater = file?.let { getFirmwareUpdater(it, fileType, context, false) }
        return firmwareUpdater?.isCheckPid(serviceSerial)
    }

    fun isCheckPidDFW(file: File, fileType: String, context: Context, isUpgradeBoot: Boolean): Boolean? {
        if(firmwareUpdater == null){
            firmwareUpdater = getFirmwareUpdater(file, fileType, context, isUpgradeBoot)
        }
        return firmwareUpdater?.isCheckPid(serviceSerial)
    }

    fun isSWUFirmwareValid(file: File?, context: Context): Boolean? {
        val firmwareUpdater = file?.let { getFirmwareUpdater(it, SWU, context, false) }
        return firmwareUpdater?.isValidSWU()
    }

    fun resetDeviceHID(context: Context): Int {
        Log.e(TAG, "resetDeviceHID")
        if (status.value != DeviceStatus.OPENED) {
            Log.e(TAG, "Device not opened, cannot reset")
            return FAILURE
        }
        try {
            if (deviceType == DeviceType.HHS) {
                serviceSerial.send(S_MODE)
                serviceSerial.send(RESET_HID)
                val tempResult = DeviceHidForFWU.detectHIDDeviceWithTimeout(context, 20, 1000)
                if (tempResult) {
                    Log.d(TAG, "Handheld Scanner device reset HID command sent successfully")
                    return SUCCESS
                }
            } else {
                Log.d(TAG, "Can not reset HID for FRS")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error sending device reset command", e)
        }
        return FAILURE
    }

    /**
     * Enter service mode by sending the $S command
     * This is idempotent - calling multiple times is safe
     * Only works for ConnectionType.USB_COM and DeviceType.HHS
     */
    fun enterServiceMode(): Int {
        if (status.value != DeviceStatus.OPENED) {
            Log.e(TAG, "Device not opened, cannot enter service mode")
            return FAILURE
        }

        try {
            Log.d(TAG, "Entering service mode for HHS device with USB_COM connection")
            serviceSerial.sendReceive(
                command = S_MODE,
                startTimeout = 700,
                endTimeout = 700
            )
            Log.d(TAG, "Service mode enter command sent successfully")
            return SUCCESS
        } catch (e: Exception) {
            Log.e(TAG, "Error entering service mode", e)
        }
        return FAILURE
    }

    /**
     * Exit service mode by sending the $R command
     * This is idempotent - calling multiple times is safe
     * Only works for ConnectionType.USB_COM and DeviceType.HHS
     */
    fun exitServiceMode(): Int {
        if (status.value != DeviceStatus.OPENED) {
            Log.e(TAG, "Device not opened, cannot exit service mode")
            return FAILURE
        }

        try {
            Log.d(TAG, "Exiting service mode for HHS device with USB_COM connection")
            serviceSerial.sendReceive(
                command = EXIT_S_MODE,
                startTimeout = 700,
                endTimeout = 700
            )
            Log.d(TAG, "Service mode exit command sent successfully")
            return SUCCESS
        } catch (e: Exception) {
            Log.e(TAG, "Error exiting service mode", e)
        }
        return FAILURE
    }


    /**
     * Extract and process label code type from barcode data based on current settings.
     * labelIDControl determines the position where to look for label identification data.
     * labelCodeType determines which type of code to extract and identify the barcode type.
     *
     * @param barcodeData The raw barcode data string to process
     * @return Processed barcode data with appropriate label code identification
     */
    private fun extractLabelCodeType(barcodeData: String): String? {
        if (labelCodeType == LabelCodeType.NONE || labelIDControl == LabelIDControl.DISABLE) {
            Log.d(TAG, "Label processing disabled, returning original data")
            return ""
        }

        try {
            // Extract label identification data from the specified position
            val labelIdentificationData = when (labelIDControl) {
                LabelIDControl.PREFIX -> {
                    // Look for identification data at the beginning of barcode data
                    extractIdentification(barcodeData, LabelIDControl.PREFIX)
                }

                LabelIDControl.SUFFIX -> {
                    // Look for identification data at the end of barcode data
                    extractIdentification(barcodeData, LabelIDControl.SUFFIX)
                }

                LabelIDControl.DISABLE -> {
                    // Already handled above, but included for completeness
                    null
                }
            }

            if (labelIdentificationData == null) {
                Log.d(TAG, "No label identification data found at ${labelIDControl.code} position")
                return ""
            }

            Log.d(
                TAG,
                "Found label identification data: $labelIdentificationData at ${labelIDControl.code} position"
            )

            // Use the extracted identification data to find the label type based on labelCodeType
            val labelFormatEntry = when (labelCodeType) {
                LabelCodeType.USA -> {
                    LabelParsing.getLabelFormatByUSACode(labelIdentificationData)?.also {
                        Log.d(
                            TAG,
                            "Identified label type by USA code '$labelIdentificationData': ${it.tagName}"
                        )
                    }
                }

                LabelCodeType.EU -> {
                    LabelParsing.getLabelFormatByEUCode(labelIdentificationData)?.also {
                        Log.d(
                            TAG,
                            "Identified label type by EU code '$labelIdentificationData': ${it.tagName}"
                        )
                    }
                }

                LabelCodeType.COMSC -> {
                    LabelParsing.getLabelFormatBySCRS232Code(labelIdentificationData)?.also {
                        Log.d(
                            TAG,
                            "Identified label type by COMSC/SCRS232 code '$labelIdentificationData': ${it.tagName}"
                        )
                    }
                }

                LabelCodeType.NONE -> null
            }

            if (labelFormatEntry == null) {
                Log.d(
                    TAG,
                    "Could not identify label type for ${labelCodeType.code} code: $labelIdentificationData"
                )
                return ""
            }

            Log.d(TAG, "Successfully identified barcode type: ${labelFormatEntry.tagName}")

            // Return the original barcode data since the identification was successful
            // The identification data was used for type detection, not for modifying the output
            return labelFormatEntry.tagName
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting label code type from data: $barcodeData", e)
            return ""
        }
    }

    /**
     * Extract identification data from the prefix (beginning) of barcode data
     * This looks for common label identification patterns at the start
     */
    private fun extractIdentification(
        barcodeData: String,
        labelIDControl: LabelIDControl
    ): String? {
        if (barcodeData.isEmpty()) return null

        var extractedLabelID: String = ""
        var barcodeDataToExtract = barcodeData

        if (connectionType == ConnectionType.USB_COMSC) {
            val indexOfS08: Int = barcodeData.indexOf("S08")
            if (indexOfS08 != -1) {
                barcodeDataToExtract = barcodeData.substring(indexOfS08 + 3) // +3 to skip "S08"
            }
        }

        if (labelIDControl == LabelIDControl.PREFIX) {
            if (barcodeDataToExtract.length >= 4) {
                extractedLabelID = barcodeDataToExtract.substring(0, 4)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
            // Check for 2-character codes (like "46", "41", etc.)
            if (barcodeDataToExtract.length >= 2) {
                extractedLabelID = barcodeDataToExtract.substring(0, 2)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
            // Check for single character codes
            if (barcodeDataToExtract.isNotEmpty()) {
                extractedLabelID = barcodeDataToExtract.substring(0, 1)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
        } else if (labelIDControl == LabelIDControl.SUFFIX) {
            // Try different suffix lengths commonly used for label identification
            // Check for 4-character codes first (like "4646", "5152", etc.)
            if (barcodeDataToExtract.length >= 4) {
                extractedLabelID = barcodeDataToExtract.substring(barcodeData.length - 4)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
            // Check for 2-character codes (like "46", "41", etc.)
            if (barcodeDataToExtract.length >= 2) {
                val extractedLabelID = barcodeDataToExtract.substring(barcodeData.length - 2)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
            // Check for single character codes
            if (barcodeDataToExtract.isNotEmpty()) {
                val extractedLabelID = barcodeDataToExtract.substring(barcodeData.length - 1)
                if (isValidIdentificationCode(extractedLabelID)) {
                    return CharsUtil.asciiStringToHexString(extractedLabelID)
                }
            }
        }

        return null
    }

    /**
     * Check if the given code is a valid identification code based on current labelCodeType
     */
    private fun isValidIdentificationCode(code: String): Boolean {
        val codeAsciiToHex = CharsUtil.asciiStringToHexString(code)

        return when (labelCodeType) {
            LabelCodeType.USA -> LabelParsing.isValidUSACode(codeAsciiToHex)
            LabelCodeType.EU -> LabelParsing.isValidEUCode(codeAsciiToHex)
            LabelCodeType.COMSC -> LabelParsing.getLabelFormatBySCRS232Code(codeAsciiToHex) != null
            LabelCodeType.NONE -> false
        }
    }
}

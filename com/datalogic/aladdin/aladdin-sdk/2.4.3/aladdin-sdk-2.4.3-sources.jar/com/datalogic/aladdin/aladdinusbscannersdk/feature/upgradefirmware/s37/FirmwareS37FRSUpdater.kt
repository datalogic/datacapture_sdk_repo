package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.s37

import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.FirmwareUpdater
import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSDevice
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSScannerTypes
import java.io.File
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import java.nio.file.Files

class FirmwareS37FRSUpdater(
    private val serial: ServiceSerial,
    private val firmwareFile: File,
    private val frsDevice: FRSDevice,
): FirmwareUpdater() {
    private var hwid: Byte = 0
    private val TAG = this.javaClass.simpleName
    private var firmwareData : S37FirmwareData? = null
    
    // Use smaller buffer size to prevent USB write errors
    private val FIRMWARE_BUFFER_SIZE = 100000 // Reduced to 2KB for more reliable USB transfers
    val parser = S37FirmwareParser(firmwareFile)

    init {
        handleTimeout()
        firmwareData = parser.parse(firmwareFile)
    }

    private fun handleTimeout() {
        val maxRetries = 3
        var retryCount = 0
        var success = false

        while (retryCount < maxRetries && !success) {
            try {
                val response = serial.sendReceive(
                    frsDevice.createFullFRSCommand(FRSScannerTypes.READ_VERSION),
                    1000, 500
                )
                val result = response?.let { CharsUtil.parseScannerResponse(it) }
                val data = result?.get("data") as ByteArray?
                if (data != null && data.size == 56) {
                    hwid = data[1] // hwid = 71 hwid = response[1];
                    success = true
                } else {
                    retryCount++
                    if (retryCount < maxRetries) {
                        Thread.sleep(200L * retryCount)
                    }
                }
            } catch (ex: Exception) {
                retryCount++
                Log.d(TAG, "handleTimeout attempt $retryCount failed: ${ex.message}")
                if (retryCount < maxRetries) {
                    Thread.sleep(200L * retryCount)
                }
            }
        }
        if (!success) {
            Log.d(TAG, "handleTimeout failed after $maxRetries attempts")
        }
    }

    @Throws(Exception::class)
    override fun isCheckPid(serial: ServiceSerial): Boolean {
        val expectedPid = FRSScannerTypes.scannerTypeToPid[hwid]//1605
        if(expectedPid?.contains(firmwareData?.pid) == true)
            return true
        if (expectedPid == null || !expectedPid.contains(firmwareData?.pid)) {
            Log.d(TAG, "Compare PID => Expected PID: ${expectedPid?.contentToString()}, Received PID: ${firmwareData?.pid}")
        }
        firmwareData?.hhsPassthroughPid?.let {
            if (it[1] != '2') {
                Log.d(TAG, "Compare PID => Expected PID: ${firmwareData?.hhsPassthroughPid}, Received PID: ${firmwareData?.pid}")
            }
        }
        return false
    }

    override fun isValidSWU(): Boolean {
        return false
    }

    override fun loadFirmwareFile(
        onCompleteLoading: (() -> Unit)?, progressCallback: ((Int) -> Unit)?
    ): Boolean {
        onCompleteLoading?.invoke()
        return true
    }

    @Throws(Exception::class)
    protected fun resetScanner() {
        try {
            val response = serial.sendReceive(
                frsDevice.createFullFRSCommand(FRSScannerTypes.RESET_SCANNER),
                2000, 1000, true)
            Log.d(TAG, "resetScanner: ${response?.get(0)}")
        } catch (ex: Exception) {
            println(ex)
        }
    }

    @Throws(Exception::class)
    protected fun setup() {
        val response = serial.sendReceive(frsDevice.createFullFRSCommand(
            FRSScannerTypes.RECLAIM_INTERNAL_DRIVE), 1000, 500, true)
        if (response?.contentEquals(FRSScannerTypes.ACK_BYTEARRAY) == true) {
            Log.d(TAG, "setup: FIRMWARE_UPDATE_S37_SECTOR_RECLAIM_SUCCESS")
        } else {
            Log.d(TAG, "setup: FIRMWARE_UPDATE_S37_SECTOR_RECLAIM_SKIP")
        }
    }

    @Throws(Exception::class)
    private fun checkUsbConnectionHealth(): Boolean {
        try {
            // Try a simple command to check if USB connection is healthy
            val response = serial.sendReceive(frsDevice.createFullFRSCommand(
                FRSScannerTypes.READ_VERSION), 1000, 1000)
            return response != null
        } catch (e: Exception) {
            Log.w(TAG, "USB connection health check failed: ${e.message}")
            return false
        }
    }

    @Throws(Exception::class)
    protected fun writeRecord(line: ByteArray, isBulkTransfer: Boolean, endTimeout: Long): ByteArray? {
        // If data is too large, use chunked writing
        if (line.size > FIRMWARE_BUFFER_SIZE) {
            try {
                return writeRecordChunked(line, isBulkTransfer, endTimeout)
            } catch (e: Exception) {
                Log.w(TAG, "Regular chunked writing failed, trying ultra-chunked: ${e.message}")
                return writeRecordUltraChunked(line, isBulkTransfer, endTimeout)
            }
        }
        
        val cmdArray = if (isBulkTransfer) {
            FRSScannerTypes.WRITE_RECORD_BUFFERED + line
        } else {
            FRSScannerTypes.WRITE_SINGLE_RECORD + line
        }

        // Add retry logic for USB write failures and non-ACK responses
        var retryCount = 0
        val maxRetries = 5 // Increased retry count
        var response: ByteArray? = null
        
        while (retryCount < maxRetries) {
            try {
                // Add small delay before each attempt to let USB recover
                if (retryCount > 0) {
                    Thread.sleep(200)
                }
                
                // Check USB connection health before writing
                if (retryCount > 0 && !checkUsbConnectionHealth()) {
                    Log.w(TAG, "USB connection unhealthy, attempting recovery...")
                    Thread.sleep(1000) // Longer pause for USB recovery
                    
                    // Try to reset scanner connection
                    try {
                        resetScanner()
                        Thread.sleep(500)
                    } catch (resetEx: Exception) {
                        Log.w(TAG, "Reset scanner failed during recovery: ${resetEx.message}")
                    }
                }
                
                response = serial.sendReceive(frsDevice.createFullFRSCommand(cmdArray),
                    120000, endTimeout, true)
                Log.d(TAG, "writeRecord: ${response?.get(0)}")
                
                // Check if response is ACK (6) - if not, retry
                if (response != null && response.isNotEmpty() && response[0].toInt() == 6) {
                    // Success - got ACK
                    return response
                } else {
                    // Not ACK - retry
                    retryCount++
                    val responseValue = response?.getOrNull(0) ?: "null"
                    Log.w(TAG, "writeRecord attempt $retryCount failed - expected ACK(6), got: $responseValue")
                    
                    if (retryCount < maxRetries) {
                        // Wait before retry, with exponential backoff
                        Thread.sleep((1000 * retryCount).toLong())
                        
                        // Additional delay for non-ACK responses
                        Thread.sleep(500)
                    } else {
                        Log.e(TAG, "writeRecord failed after $maxRetries attempts - last response: ${response?.getOrNull(0)}")
                        return response // Return the last response even if not ACK
                    }
                }
                
            } catch (e: Exception) {
                retryCount++
                Log.w(TAG, "writeRecord attempt $retryCount failed: ${e.message}")
                
                if (retryCount < maxRetries) {
                    // Wait before retry, with exponential backoff
                    Thread.sleep((1000 * retryCount).toLong())
                    
                    // Try to reset the connection if it's a USB error
                    if (e.message?.contains("IOException") == true || e.message?.contains("Error writing") == true) {
                        try {
                            // More aggressive USB recovery
                            Log.d(TAG, "Attempting USB recovery for write error...")
                            Thread.sleep(1000) // Longer pause for USB recovery
                            
                            // Try to reset scanner connection
                            try {
                                resetScanner()
                                Thread.sleep(500)
                            } catch (resetEx: Exception) {
                                Log.w(TAG, "Reset scanner failed during recovery: ${resetEx.message}")
                            }
                        } catch (sleepEx: Exception) {
                            // Ignore sleep exceptions
                        }
                    }
                } else {
                    Log.e(TAG, "writeRecord failed after $maxRetries attempts")
                    throw e
                }
            }
        }
        
        return response
    }

    @Throws(Exception::class)
    private fun writeRecordChunked(data: ByteArray, isBulkTransfer: Boolean, endTimeout: Long): ByteArray? {
        Log.d(TAG, "Using chunked writing for data size: ${data.size}")
        
        val chunkSize = 1024 // Use 1KB chunks for maximum reliability
        var offset = 0
        var lastResponse: ByteArray? = null
        
        while (offset < data.size) {
            val remainingBytes = data.size - offset
            val currentChunkSize = minOf(chunkSize, remainingBytes)
            val chunk = data.copyOfRange(offset, offset + currentChunkSize)
            
            Log.d(TAG, "Writing chunk ${offset / chunkSize + 1}/${(data.size + chunkSize - 1) / chunkSize}, size: $currentChunkSize")
            
            val response = writeRecord(chunk, isBulkTransfer, endTimeout)
            if (response == null || !response.contentEquals(FRSScannerTypes.ACK_BYTEARRAY)) {
                Log.e(TAG, "Chunked write failed at offset $offset")
                return response
            }
            
            lastResponse = response
            offset += currentChunkSize
            
            // Longer delay between chunks to prevent overwhelming the USB connection
            Thread.sleep(100)
        }
        
        return lastResponse
    }

    @Throws(Exception::class)
    private fun writeRecordUltraChunked(data: ByteArray, isBulkTransfer: Boolean, endTimeout: Long): ByteArray? {
        Log.d(TAG, "Using ultra-chunked writing for data size: ${data.size}")
        
        val chunkSize = 512 // Use 512-byte chunks for maximum reliability
        var offset = 0
        var lastResponse: ByteArray? = null
        
        while (offset < data.size) {
            val remainingBytes = data.size - offset
            val currentChunkSize = minOf(chunkSize, remainingBytes)
            val chunk = data.copyOfRange(offset, offset + currentChunkSize)
            
            Log.d(TAG, "Writing ultra-chunk ${offset / chunkSize + 1}/${(data.size + chunkSize - 1) / chunkSize}, size: $currentChunkSize")
            
            // Use direct write without retry logic for ultra-small chunks
            val cmdArray = if (isBulkTransfer) {
                FRSScannerTypes.WRITE_RECORD_BUFFERED + chunk
            } else {
                FRSScannerTypes.WRITE_SINGLE_RECORD + chunk
            }
            
            try {
                val response = serial.sendReceive(frsDevice.createFullFRSCommand(cmdArray), 120000, endTimeout, true)
                if (response == null || !response.contentEquals(FRSScannerTypes.ACK_BYTEARRAY)) {
                    Log.e(TAG, "Ultra-chunked write failed at offset $offset")
                    return response
                }
                
                lastResponse = response
                offset += currentChunkSize
                
                // Longer delay between ultra-small chunks
                Thread.sleep(200)
            } catch (e: Exception) {
                Log.e(TAG, "Ultra-chunked write exception at offset $offset: ${e.message}")
                throw e
            }
        }
        
        return lastResponse
    }

    override fun isSupportedBulkTransfer(): Boolean {
        var isSupported = false
        try {
            firmwareFile.bufferedReader().use { file ->
                val line = file.readLine()
                val lineInBytes = line?.toByteArray(Charsets.US_ASCII)//size = 72
                val cmd = lineInBytes?.plus(FRSScannerTypes.NEXT_LINE)
                val cmdArray = FRSScannerTypes.WRITE_RECORD_BUFFERED + cmd!!//size = 75

                val response = serial.sendReceive(
                    frsDevice.createFullFRSCommand(cmdArray), 3000, 500)
                val errorType = frsDevice.getResponseTypeName(response)

                if (errorType == FRSScannerTypes.ACK) {
                    isSupported = true
                    Log.d(TAG, "Bulk Transfer checked --> response: $errorType --> use Bulk transfer")
                } else {
                    Log.d(TAG, "Bulk Transfer checked --> response: $errorType")
                }
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
            Log.e(TAG, "checkIsSupportedBulkTransfer: ${ex.message}")
        }
        return isSupported
    }

    override fun getPid(file: File?): String? {
        return parser.parse(file).pid
    }

    private fun submitTransfer(): Boolean {
        val sendCmd = FRSScannerTypes.SUBMIT_TRANSFER_UPDATER

        try {
            // Wait after last data block
            Thread.sleep(2000)

            var response: ByteArray? = null
            var res: String? = null
            var attempts = 0
            val maxAttempts = 5

            while (attempts < maxAttempts) {
                response = serial.sendReceive(
                    frsDevice.createFullFRSCommand(sendCmd),
                    300000, 3000) // 10s, 5s
                Log.d(TAG, "submitTransfer: ${response?.getOrNull(0)}")
                res = frsDevice.getResponseTypeName(response)
                if (res.equals("ACK", ignoreCase = true)) {
                    return true
                }
                attempts++
                Thread.sleep(2000) // Wait before retry
            }
            Log.d(TAG, "submitTransfer: $res")
            return false
        } catch (ex: Exception) {
            println(ex)
        }
        return false
    }

    @Throws(Exception::class)
    override fun upgradeByBulkTransfer(progressCallback: (Int) -> Unit): Boolean {
        if (firmwareData?.checkPid!!) {
            isCheckPid(serial)
        }
        setup()
        val useBulkTransfer = true
        val numOfLines = Files.lines(firmwareFile.toPath(), Charset.defaultCharset()).count()
        var previousPercent: Long = -1
        var failed = false
        try {
            firmwareFile.bufferedReader().use { br ->
                var block = byteArrayOf()
                var blockSize = 0
                var i: Long = 0
                var line: String?

                while (br.readLine().also { line = it } != null && !failed) {
                    if (i == 0L) {
                        i++
                        continue
                    }
                    val lineToBytes = line!!.toByteArray(StandardCharsets.US_ASCII)
                    val fullLine = addBytes(lineToBytes, FRSScannerTypes.NEXT_LINE)
                    blockSize += fullLine.size

                    val response: ByteArray?
                    // Use smaller buffer size to prevent USB write errors
                    if (blockSize < FIRMWARE_BUFFER_SIZE && i != (numOfLines - 1)) {
                        block = addBytes(block, fullLine)
                    } else if (blockSize >= FIRMWARE_BUFFER_SIZE && i != (numOfLines - 1)) {
                        // Write the current block
                        response = writeRecord(block, useBulkTransfer, 500)
                        when {
                            response.contentEquals(FRSScannerTypes.ACK_BYTEARRAY) -> {
                                // no action necessary
                            }
                            response.contentEquals(FRSScannerTypes.NAK_BYTEARRAY) -> {
                                failed = true
                            }
                            response.contentEquals(FRSScannerTypes.BEL_BYTEARRAY) -> {
                                failed = true
                            }
                            response.contentEquals(FRSScannerTypes.BEL_BYTEARRAY) -> {
                                failed = true
                            }
                            response.contentEquals(FRSScannerTypes.SYN_BYTEARRAY) -> {
                                if (i != (numOfLines - 1)) {
                                    failed = true
                                }
                            }
                            response == null -> {
                                if (i != (numOfLines - 1)) {
                                    failed = true
                                }
                            }
                            else -> {
                                failed = true
                            }
                        }
                        block = fullLine
                        blockSize = block.size
                    } else {
                        block = addBytes(block, fullLine)
                        response = writeRecord(block, useBulkTransfer, 500)
                        when {
                            response.contentEquals(FRSScannerTypes.ACK_BYTEARRAY) -> {
                                // no action necessary
                            }
                            response.contentEquals(FRSScannerTypes.NAK_BYTEARRAY) -> {
                                failed = true
                            }
                            response.contentEquals(FRSScannerTypes.BEL_BYTEARRAY) -> {
                                failed = true
                            }
                            response.contentEquals(FRSScannerTypes.CAN_BYTEARRAY) -> {
                                failed = true
                            }
                            response.contentEquals(FRSScannerTypes.SYN_BYTEARRAY) -> {
                                if (i != (numOfLines - 1)) {
                                    failed = true
                                }
                            }
                            response == null -> {
                                if (i != (numOfLines - 1)) {
                                    failed = true
                                }
                            }
                            else -> {
                                failed = true
                            }
                        }
                    }

                    val percent = (i * 100) / numOfLines
                    if (percent > previousPercent) {
                        previousPercent = percent
                        progressCallback(percent.toInt())
                    }
                    i++
                }

                if (!failed) {
                    val complete = submitTransfer()
                    failed = !complete
                    if (failed) {
                        Log.d(TAG, "submitTransfer failed")
                    }
                }
            }
        } catch (e: Throwable) {
            println(e)
            failed = true
        } finally {
            try {
                resetScanner()
            } catch (e: Exception) {
                Log.d(TAG, "upgradeByBulkTransfer: Exception ${e.message}")
                Thread.sleep(120000)
                try {
                    resetScanner()
                } catch (ex: Exception) {
                    Log.d(TAG, "upgradeByBulkTransfer: Exception ${ex.message}")
                }
            }
            if (failed) {
                Log.d(TAG, "upgradeByBulkTransfer: failed")
            }
            return !failed
        }
    }

    private fun addBytes(arrOne: ByteArray, arrTwo: ByteArray): ByteArray {
        val combined = ByteArray(arrOne.size + arrTwo.size)
        for (idx in combined.indices) {
            combined[idx] = if (idx < arrOne.size) arrOne[idx] else arrTwo[idx - arrOne.size]
        }
        return combined
    }

    override fun upgrade(progressCallback: (Int) -> Unit, resetCallback: () -> Unit): Boolean {
        if (firmwareData?.checkPid == true) {
            isCheckPid(serial)
        }
        setup()

        val numOfLines = firmwareFile.useLines { it.count().toLong() }
        var previousPercent = -1L
        var failed = false

        try {
            firmwareFile.bufferedReader().useLines { lines ->
                var i = 0L
                var endTimeout = 100L
                for (line in lines) {
                    if (failed) break
                    val response = writeRecord(line.toByteArray(Charsets.US_ASCII), false, endTimeout)
                    Log.d(TAG, "Write Line: $line")
                    when {
                        response == null && i != (numOfLines - 1) -> {
                            failed = true;
                        }
                        response contentEquals FRSScannerTypes.ACK_BYTEARRAY -> {
                        }
                        response contentEquals FRSScannerTypes.NAK_BYTEARRAY -> {
                            failed = true;
                        }
                        response contentEquals FRSScannerTypes.BEL_BYTEARRAY -> {
                            failed = true;
                        }
                        response contentEquals FRSScannerTypes.CAN_BYTEARRAY -> {
                            failed = true;
                        }
                        response contentEquals FRSScannerTypes.SYN_BYTEARRAY && i != (numOfLines - 1) -> {
                            failed = true;
                        }
                        else -> {
                            failed = true;
                        }
                    }

                    val percent = (i * 100) / numOfLines
                    if (percent > previousPercent) {
                        previousPercent = percent
                        progressCallback(percent.toInt())
                    }
                    i++
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            failed = true
        } finally {
            try {
                Thread.sleep(2000)
                resetCallback()
            } catch (e: Exception) {
                Thread.sleep(120000)
                try {
                    resetCallback()
                } catch (ex: Exception) {
                    Log.d(TAG, "upgrade: Exception ${ex.message}")
                }
            }

            if (failed) {
                Log.d(TAG, "upgrade: failed")
            }
        }
        return !failed
    }

}

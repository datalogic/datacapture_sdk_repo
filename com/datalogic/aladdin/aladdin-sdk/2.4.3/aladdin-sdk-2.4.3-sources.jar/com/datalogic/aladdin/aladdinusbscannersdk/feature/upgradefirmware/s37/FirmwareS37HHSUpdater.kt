package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.s37

import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.FirmwareUpdater
import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import java.io.File
import java.nio.charset.StandardCharsets

/**
 * Handles the firmware update process for S37 files
 */
class FirmwareS37HHSUpdater(
    private val firmwareFile: File,
    private val deviceModel: String,
    private val serial: ServiceSerial
): FirmwareUpdater() {
    companion object {
        const val ACK: Byte = 0x06
        private const val NAK: Byte = 0x15
        private const val BEL: Byte = 0x07
        private const val CAN: Byte = 0x18

        // List of devices that require longer response time
        private val LONG_RESPONSE_DEVICES = listOf(
            "Magellan-1500i",
            "Magellan-3410VSI",
            "Magellan-3510HSI"
        )
    }

    private var useBulkTransfer = false
    private var isLongResponseDevice = false
    private var lastCommand: ByteArray? = null
    val TAG = this.javaClass.simpleName
    private var firmwareData : S37FirmwareData? = null
    private var parser = S37FirmwareParser(firmwareFile)

    init {
        firmwareData = parser.parse(firmwareFile)
    }

    /**
     * Start the firmware update process
     */
    override fun upgrade(progressCallback: (Int) -> Unit, resetCallback: () -> Unit): Boolean {
        try {
            // Parse firmware file


            // Validate firmware data
            firmwareData?.let {
                if (!validateFirmwareData(it)) {
                    return false
                }
            }
            // Setup device
            setupDevice()

            isCheckPid(serial)

            // Check if bulk transfer is supported
            //useBulkTransfer = checkBulkTransferSupport()

            // Get total number of lines for progress tracking
            val totalLines = firmwareFile.readLines().size
            var currentLine = 0
            var previousPercent = -1

            // Process each record
            firmwareFile.bufferedReader().use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    currentLine++
                    val percent = if (totalLines > 0) (currentLine * 100) / totalLines else 0
                    if (percent > previousPercent) {
                        progressCallback(percent)
                        previousPercent = percent
                    }
                    Log.d(TAG, "sendRecord $line")
                    var endTimeout = 30L
                    if((currentLine == totalLines - 1) || (currentLine == totalLines - 2) || (currentLine == totalLines - 3)
                        || (currentLine == totalLines - 4))
                        endTimeout = 5000L
                    // Send record to device
                    val response = sendRecord(line!!.toByteArray(StandardCharsets.US_ASCII), serial, endTimeout)

                    // Check response
                    if (!isValidResponse(response)) {
                        Log.e(TAG, "Invalid response from device")
                    }

                    // Special handling for last record
                    if (currentLine == totalLines) {
                    }
                }
            }

            // Finalize update
            return true

        } catch (e: Exception) {
            return false
        }
    }

    override fun upgradeByBulkTransfer(progressCallback: (Int) -> Unit): Boolean {
        return false
    }

    override fun isSupportedBulkTransfer(): Boolean {
        return false
    }

    override fun getPid(file: File?): String? {
        return parser.parse(file).pid
    }

    private fun validateFirmwareData(data: S37FirmwareData): Boolean {
        // Check required fields
        if (data.pid == null) {
            return false
        }

        if (data.release == null) {
            return false
        }

        // Validate against device model
        if (!isValidForDevice()) {
            return false
        }

        return true
    }

    private fun setupDevice() {
        // Check if device is a long response device
        isLongResponseDevice = LONG_RESPONSE_DEVICES.contains(deviceModel)

        // Perform device-specific setup
        when {
            deviceModel.startsWith("Magellan") -> setupMagellanDevice()
            deviceModel.startsWith("HHS") -> setupHHSDevice()
            else -> setupGenericDevice()
        }
    }

    @Throws(Exception::class)
    override fun isCheckPid(serial: ServiceSerial):Boolean {
        try {
            serial.sendReceive("\$S\r".toByteArray(), 500, 200, true)
            val response = serial.sendReceiveString("\$yD\r".toByteArray())
            println("Compare PID => Expected PID: ${firmwareData?.hhsSwid}, Received PID: ${response.substring(2)}")
            if (response.length > 2) {
                val pid = response.substring(2)
                if (firmwareData?.hhsSwid == null || !pid.contentEquals(firmwareData?.hhsSwid)) {
                    Log.d(TAG, "Compare PID => Expected PID: ${firmwareData?.hhsSwid}, Received PID: $pid")
                }
            }
            if(response.substring(2).contains(firmwareData?.hhsSwid.toString()))
                return true
        } catch (e: Exception) {
            Log.d(TAG, "checkPid Exception: ${e.message}")
        }
        return false
    }

    override fun isValidSWU(): Boolean {
        return false
    }

    override fun loadFirmwareFile(
        onCompleteLoading: (() -> Unit)?, progressCallback: ((Int) -> Unit)?
    ): Boolean {
        onCompleteLoading?.invoke()
        return true
    }

    private fun sendRecord(
        data: ByteArray,
        serial: ServiceSerial,
        endTimeout: Long,
        maxRetries: Int = 3,
        retryDelayMs: Long = 500
    ): ByteArray? {
        val fullCommand = data + byteArrayOf(0x0D)
        lastCommand = fullCommand

        repeat(maxRetries) { attempt ->
            try {
                val response = serial.sendReceive(fullCommand, 120000, endTimeout, true)
                Log.d(TAG, "sendRecord attempt ${attempt + 1}," +
                        " response = ${response?.getOrNull(0)}, end timeout = $endTimeout")

                if (response != null) {
                    return response
                }
            } catch (e: Exception) {
                Log.e(TAG, "sendRecord error on attempt ${attempt + 1}: ${e.message}")
            }

            // Optional delay before retrying (except after last attempt)
            if (attempt < maxRetries - 1) {
                Thread.sleep(retryDelayMs)
            }
        }

        return null // All retries failed
    }

    private fun isValidResponse(response: ByteArray?): Boolean {
        if (response == null) return false

        return when {
            response.contentEquals(byteArrayOf(ACK)) -> true
            response.contentEquals(byteArrayOf(NAK)) -> {
                false
            }
            response.contentEquals(byteArrayOf(BEL)) -> {
                false
            }
            response.contentEquals(byteArrayOf(CAN)) -> {
                false
            }
            else -> {
                false
            }
        }
    }

    private fun isValidForDevice(): Boolean {
        return true
    }

    private fun setupMagellanDevice() {
    }

    private fun setupHHSDevice() {
    }

    private fun setupGenericDevice() {
    }

} 
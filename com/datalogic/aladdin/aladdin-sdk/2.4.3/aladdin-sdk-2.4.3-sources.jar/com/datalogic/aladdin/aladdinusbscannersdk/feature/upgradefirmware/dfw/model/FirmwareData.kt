package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.model

import android.R.attr.text
import android.content.Context
import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FileUtils
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets


class FirmwareData(
    private val fileDFW: File,
    private val context: Context
) {

    companion object {
        const val RS232OEM = "RS232OEM"
        const val USBOEM = "USBOEM"
        const val addrBootFirm = "23C00F00"
        const val dataBootFirm = "5269736372697665726520696C20426F6F7400"
    }
    val TAG = this::class.java.simpleName
    var reset_label: String = ""
    var usb_kbd: Boolean = false
    val filePath = fileDFW.absolutePath
    var deviceName: String? = null
    var release: String? = null
    var releaseBoot: String? = null
    var pid: String? = null
    var protocol: String? = null
    var platformName: String = ""
    var isMuseo = true
    var maxSpeed = "115200"
    var linear = true
    var resetLabel = ""
    var usbKbd = true
    var byCradle = false
    var validPidCradle: Array<String>? = null
    var pktSize = 2048
    var pktMinSize = 256
    var sendApplication = true
    var sendBoot = false
    var checkPid = true
    var sendImageBin = false
    var sendBackupImageBin = false
    var sendSignature = true
    var sendJingle = true
    var hex: File = FileUtils.tmpFile(context, "hex.txt")
    var tempFile: File = FileUtils.tmpFile(context, "temp.txt")
    var blockUpgradeFinalStatus: MutableList<Any> = mutableListOf()
    var mApplicationPages: MutableList<FirmwarePage> = mutableListOf()
    val mBootPages: MutableList<FirmwarePage> = mutableListOf()
    val mHexData: MutableList<HexData> = mutableListOf()
    val dataPaths: MutableList<String> = mutableListOf(hex.absolutePath)
    var versionControl = false
    private var model: String? = null
    private var fmwrUptdLabel = false
    var isDFX = false
    var upgradeFwViaRadio = false

    // Timeout fields
    var rs232EchoTimeout = 500
    var rs232EchoAttempt = 50
    var rs232JoinTimeout = 5000
    var rs232JoinAttempt = 5
    var rs232DataTimeout = 5000
    var rs232DataAttempt = 5
    var rs232EndTimeout = 5000
    var rs232EndAttempt = 5
    var rs232JoinBlockTimeout = 5000
    var rs232JoinBlockAttempt = 5
    var rs232VersionTimeout = 5000
    var rs232VersionAttempt = 5
    var rs232FlashUpdateTimeout = 60000
    var usbhidEchoTimeout = 500
    var usbhidEchoAttempt = 50
    var usbhidJoinTimeout = 5000
    var usbhidJoinAttempt = 5
    var usbhidDataTimeout = 5000
    var usbhidDataAttempt = 5
    var usbhidEndTimeout = 5000
    var usbhidEndTimeoutLinux = 7000
    var usbhidEndAttempt = 5
    var usbhidFlashUpdateTimeout = 60000
    var usbhidJoinBlockTimeout = 5000
    var usbhidJoinBlockAttempt = 5
    var usbhidVersionTimeout = 5000
    var usbhidVersionAttempt = 5
    var ethernetEchoTimeout = 500
    var ethernetEchoAttempt = 50
    var ethernetJoinTimeout = 5000
    var ethernetJoinAttempt = 5
    var ethernetDataTimeout = 5000
    var ethernetDataAttempt = 5
    var ethernetEndTimeout = 5000
    var ethernetEndAttempt = 5
    var ethernetJoinBlockTimeout = 5000
    var ethernetJoinBlockAttempt = 5
    var ethernetVersionTimeout = 5000
    var ethernetVersionAttempt = 5
    var ethernetFlashUpdateTimeout = 60000
    var resetCommandRetries = 2

    inner class HexData {
        var hex: String = ""
        var hexFile: File? = null
        var pids: ArrayList<String> = arrayListOf()
        var ids: ArrayList<String> = arrayListOf()

        init {
            hexFile = FileUtils.tmpFile(context, "hex.txt")
            hexFile?.let {
                dataPaths.add(it.absolutePath)
            }
        }

        override fun toString(): String {
            //val data = getData()?.replace(Regex("[\n\t ]"), "|")
            return buildString {
                appendLine("[HexData]:")
                append(".pids = ").append(pids.joinToString(" ")).appendLine()
                append(".ids = ").append(ids.joinToString(" ")).appendLine()
            }
        }
    }

    fun getApplicationPages(): List<FirmwarePage> = mApplicationPages
    fun getBootPages(): List<FirmwarePage> = mBootPages
    fun getModel(): String? = model
    fun setModel(model: String) { this.model = model }
    fun isUSBOEM(): Boolean = model == USBOEM
    fun isRS232OEM(): Boolean = model == RS232OEM
    fun isFmwrUptdLabel(): Boolean = fmwrUptdLabel
    var hexText: String? = null
    private var currentBlockParsingIndex = 0
    /*fun getApplicationNumBlock(): Int = mApplicationPages.sumOf { fp ->
        fp.hPages.sumOf { it.numBlock }
    }

    fun getBootNumBlock(): Int = mBootPages.sumOf { fp ->
        fp.hPages.sumOf { it.numBlock }
    }*/

    fun detectProtocol(file: File): String? {
        try {
            val parser = XmlPullParserFactory.newInstance().newPullParser()
            parser.setInput(FileInputStream(file), "UTF-8")
            var eventType = parser.eventType

            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG && parser.name == "platform") {
                    val protocol = parser.getAttributeValue(null, "protocol")
                    this.protocol = protocol
                    return protocol
                }
                eventType = parser.next()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error detecting protocol: ${e.message}")
        }
        return null
    }

    @Throws(Exception::class)
    fun elabXML11() {
        try {
            currentBlockParsingIndex = 0
            val parser = XmlPullParserFactory.newInstance().newPullParser()
            parser.setInput(FileInputStream(fileDFW), "UTF-8")

            var eventType = parser.eventType
            val platformAttributes = mutableMapOf<String, String>()
            val hexAttributes = mutableMapOf<String, String>()

            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        when (parser.name) {
                            "platform" -> {
                                for (i in 0 until parser.attributeCount) {
                                    platformAttributes[parser.getAttributeName(i)] =
                                        parser.getAttributeValue(i)
                                }
                            }

                            "hex" -> {
                                // Read all attributes for this hex
                                var pidSet: String? = null
                                var idSet: String? = null
                                for (i in 0 until parser.attributeCount) {
                                    when (parser.getAttributeName(i)) {
                                        "pidSet" -> pidSet = parser.getAttributeValue(i)
                                        "idSet" -> idSet = parser.getAttributeValue(i)
                                    }
                                }
                                val hexTextForBlock = parser.nextText().trim()
                                val hexData = HexData().apply {
                                    hex = hexTextForBlock
                                    pids = splitAndTrim(pidSet)
                                    ids = splitAndTrim(idSet)
                                }
                                mHexData.add(hexData)
                                Log.d(TAG, "Adding HexData: pid=${hexData.pids} id=${hexData.ids} hex='${hexData.hex.take(40)}'")
                            }

                            "block" -> {
                                val swVersion = parser.getAttributeValue(null, "version")
                                val offset = parser.getAttributeValue(null, "offset")
                                val size = parser.getAttributeValue(null, "size")
                                val id = parser.getAttributeValue(null, "id")
                                val pid = parser.getAttributeValue(null, "pid")
                                val developerOnly = parser.getAttributeValue(null, "developer_only")
                                val blockType = parser.nextText().trim()

                                val fp = FirmwarePage().apply {
                                    this.offset = offset
                                    this.size = size
                                    this.id = id
                                    this.pid = pid
                                    this.developerOnly = developerOnly
                                    this.sapNumber = swVersion
                                    this.blockVersion12 = swVersion
                                }
                                currentBlockParsingIndex++
                                when (blockType.lowercase()) {
                                    "application" -> {
                                        if (!swVersion.isNullOrBlank()) this.release = swVersion
                                        mApplicationPages.add(fp)
                                    }
                                    "boot" -> {
                                        if (!swVersion.isNullOrBlank()) this.releaseBoot = swVersion
                                        mBootPages.add(fp)
                                    }
                                }
                            }

                            "product" -> {
                                // Optional: parse product attributes if needed
                                val pidNumber = parser.getAttributeValue(null, "PID_NUMBER")
                                if (!pidNumber.isNullOrBlank()) this.pid = pidNumber
                                val validPids = parser.getAttributeValue(null, "ValidPIDSet")
                                this.validPidCradle = SmartUtil.splitAndTrim(validPids, ",").toList()
                                    .takeIf { it.isNotEmpty() }
                                    ?.toTypedArray()
                            }
                        }
                    }
                }
                eventType = parser.next()
            }

            // Set fields from parsed attributes
            this.deviceName = hexAttributes["prod_name"] ?: ""
            this.pid = hexAttributes["PID"] ?: this.pid
            this.protocol = platformAttributes["protocol"] ?: ""
            this.model = platformAttributes["model"] ?: this.model
            this.sendSignature = !platformAttributes["signature"].equals("false", ignoreCase = true)
            this.isMuseo = platformAttributes["type"].equals("MUSEO", ignoreCase = true)
            this.usb_kbd = !platformAttributes["USB_KBD"].equals("false", ignoreCase = true)
            this.reset_label = platformAttributes["RESET_LABEL"] ?: ""
            this.pktSize = platformAttributes["PKT_SIZE"]?.toIntOrNull() ?: this.pktSize
            this.pktMinSize = platformAttributes["PKT_SIZE_MIN"]?.toIntOrNull() ?: this.pktMinSize
            this.linear = this.protocol.equals("1D-2.1", ignoreCase = true)
            this.byCradle = hexAttributes["By_Cradle"].equals("TRUE", ignoreCase = true)

            if (this.byCradle) {
                val pids = hexAttributes["Valid_PIDS_CRADLE"] ?: ""
            }

            this.maxSpeed = hexAttributes["maxSpeed"] ?: this.maxSpeed
        } catch (ex: Exception) {
            Log.e(TAG, "Error parsing XML: ${ex.message}")
        }
    }

    fun elabXML10() {
        // Clear existing state if this can be called multiple times
        mApplicationPages.clear()
        mBootPages.clear()
        mHexData.clear()

        var hexText: String? = null
        var platformUSBkbd: String? = null
        var platformResetLabel: String? = null
        var platformPktSize: String? = null
        var platformPktMinSize: String? = null
        var platformProtocol: String? = null
        var platformModel: String? = null
        var platformSignature: String? = null
        var platformType: String? = null

        var deviceNameAttr: String? = null
        var pidAttr: String? = null
        var fmwrUpdLabelAttr: String? = null
        var thruCradle: String? = null
        var validPidSet: String? = null
        var maxSpeedAttr: String? = null

        // Track first <block> application offset/size (fallback if HEX has no ELA)
        var firstAppOffset: String? = null
        var firstAppSize: String? = null

        val xpf = XmlPullParserFactory.newInstance()
        val parser = xpf.newPullParser()
        parser.setInput(FileInputStream(fileDFW), "UTF-8")

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "platform" -> {
                        platformUSBkbd     = parser.getAttributeValue(null, "USB_KBD")
                        platformResetLabel = parser.getAttributeValue(null, "RESET_LABEL")
                        platformPktSize    = parser.getAttributeValue(null, "PKT_SIZE")
                        platformPktMinSize = parser.getAttributeValue(null, "PKT_SIZE_MIN")
                        platformProtocol   = parser.getAttributeValue(null, "protocol")
                        platformModel      = parser.getAttributeValue(null, "model")
                        platformSignature  = parser.getAttributeValue(null, "signature")
                        platformType       = parser.getAttributeValue(null, "type")
                    }
                    "block" -> {
                        val offset = parser.getAttributeValue(null, "offset")
                        val size   = parser.getAttributeValue(null, "size")
                        val tagText = parser.nextText()?.trim()
                        if (tagText.equals("application", true)) {
                            if (firstAppOffset == null) { // only keep first application block as in Java
                                firstAppOffset = offset
                                firstAppSize   = size
                            }
                            // Keep Java behavior: add one FirmwarePage from <block>
                            val fp = FirmwarePage().apply {
                                this.offset = offset ?: ""
                                this.size   = size ?: ""
                                this.isSelected = true
                            }
                            mApplicationPages.add(fp) // Java does this directly
                        } else if (tagText.equals("boot", true)) {
                            val fp = FirmwarePage().apply {
                                this.offset = offset ?: ""
                                this.size   = size ?: ""
                            }
                            mBootPages.add(fp)
                        }
                    }
                    "hex" -> {
                        deviceNameAttr   = parser.getAttributeValue(null, "PROD_NAME")
                        pidAttr          = parser.getAttributeValue(null, "PID_NUMBER")
                        fmwrUpdLabelAttr = parser.getAttributeValue(null, "FMWR_UPDT_LABEL")
                        thruCradle       = parser.getAttributeValue(null, "THRUCRADLE")
                        validPidSet      = parser.getAttributeValue(null, "ValidPIDSet")
                        maxSpeedAttr     = parser.getAttributeValue(null, "MAXSPEED")

                        // Pull CDATA/TEXT content (HEX lines)
                        val next = parser.next()
                        if (next == XmlPullParser.CDSECT || next == XmlPullParser.TEXT) {
                            hexText = parser.text?.trim()
                        }
                    }
                }
            }
            event = parser.next()
        }

        // ---- Map parsed attributes to your fields (mirror Java) ----
        this.deviceName = deviceNameAttr ?: this.deviceName
        this.pid        = pidAttr        ?: this.pid
        this.validPidCradle = SmartUtil.splitAndTrim(validPidSet, ",")
            .filterNotNull()
            .takeIf { it.isNotEmpty() }
            ?.toTypedArray()
        // Write HEX to temp file path (like Java) and keep in-memory too
        val hexPayload = hexText?.trim().orEmpty()
        FileUtils.writeEntireFile(hex, hexPayload)

        this.hexText = hexPayload

        // Platform-level fields
        this.usb_kbd     = !platformUSBkbd.equals("false", true)
        platformResetLabel?.let {
            this.reset_label = it
        }
        platformPktSize?.toIntOrNull()?.let { this.pktSize = it }   // defaults kept if parse fails
        platformPktMinSize?.toIntOrNull()?.let { this.pktMinSize = it }
        this.protocol    = platformProtocol ?: this.protocol
        platformModel?.takeIf { it.isNotBlank() }?.let { this.model = it }
        this.linear       = this.protocol?.startsWith("1D") == true
        this.sendSignature = !platformSignature.equals("false", true)
        this.isMuseo       = platformType.equals("MUSEO", true)

        // Cradle / speed
        this.byCradle = thruCradle.equals("TRUE", true)

        mHexData.add(HexData().apply {
            hex  = hexPayload
            pids = arrayListOf(pidAttr.toString())
            ids  = arrayListOf(mApplicationPages.firstOrNull()?.id ?: "0x01")
        })
    }

    fun splitAndTrim(input: String?, delimiter: String = ","): ArrayList<String> {
        return input?.split(delimiter)
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.let { ArrayList(it) }
            ?: arrayListOf()
    }

    override fun toString(): String {
        return "FirmwarePage(offset=$this.offset, size=$this.size)"
    }

    @Throws(Exception::class)
    fun setPages() {
        Log.d(TAG, "searchPagesExtended() isMuseo: $isMuseo")
        if (protocol == "1D-1.1" || protocol == "1D-1.2") {
            Log.d(TAG, "SDS: setPages called.")
            Log.d(TAG, "- Nr. Application pages: ${mApplicationPages.size}")
            Log.d(TAG, "- Nr. Fw Boot pages: ${mBootPages.size}")

            for (fp in mApplicationPages) {
                val hexData = findHexFor(fp)
                val hIntel = hexData.hexFile?.let { it -> HexIntel(it, dataPaths, context) }
                if (hIntel != null) {
                    searchPagesExtended(fp, hIntel)
                }
                Log.d(TAG, String.format("fp.totPages = %d", fp.getHPages().size))
            }

            for (fp in mBootPages) {
                val hexData = findHexFor(fp)
                val hIntel = hexData.hexFile?.let { HexIntel(it, dataPaths, context) }
                if (hIntel != null) {
                    searchPagesExtended(fp, hIntel)
                }
                Log.d(TAG, String.format("fp.totPages = %d", fp.getHPages().size))
            }

        } else {
            val hIntel = HexIntel(hex, dataPaths,context)
            for (fp in mApplicationPages) {
                searchPages(fp, hIntel)
            }

            for (fp in mBootPages) {
                searchPages(fp, hIntel)
            }
        }
    }

    fun findHexFor(fp: FirmwarePage): HexData {
        var res = HexData() // NOT FOUND

        Log.d(TAG, "findHexFor :: fp.pid = ${fp.pid}, fp.id = ${fp.id}")
        var id = 0
        while (id < mHexData.size) {
            val hd = mHexData[id] as HexData

            for (pid in hd.pids) {
                Log.d(TAG, "findHexFor :: hd.pid = $pid")
                if (fp.pid == pid) {
                    Log.d(TAG, "findHexFor :: match pid.")
                    for (hexId in hd.ids) {
                        Log.d(TAG, "findHexFor :: hd.id = $hexId")
                        if (fp.id == hexId) { // id match
                            mHexData.removeAt(id)
                            res = hd // filled element
                            Log.d(TAG, "findHexFor :: match id")
                            Log.d(TAG, "findHexFor :: hd found!")
                            break
                        }
                    }
                }
            }
            id++
        }

        Log.d(TAG, "findHexFor :: result")
        Log.d(TAG, res.toString())
        Log.d(TAG, "findHexFor :: end")

        return res
    }

    private fun searchPagesExtended(fp: FirmwarePage, hIntel: HexIntel) {
        Log.d(TAG, "searchPagesExtended() isMuseo: $isMuseo")
        if (isMuseo) {
            println(":: fp.offset=${fp.offset}, .MaxAddress=0x${fp.getMaxAddress().toString(16)}")
            Log.d(TAG, "::searchPages() MUSEO")
            println(":: fp.offset=${fp.offset}, .MaxAddress=0x${fp.getMaxAddress().toString(16)}")
            Log.d(TAG, ":: fp.offset=${fp.offset}, .MaxAddress=0x${fp.getMaxAddress().toString(16)}")

            val list = hIntel.getAllPageMuseo(fp.offset, fp.getMaxAddress())
            for (hp in list) {
                hp.checkMaxSize(fp.getMaxAddress())
                hp.calcNumBlock(pktSize, pktMinSize)
                fp.addHPage(hp)
            }
        } else {
            Log.d(TAG, "::searchPages() old")
            val hPageFull = hIntel.getFullPage(fp.offset, fp.getMaxAddress())
            if (hPageFull != null) {
                hPageFull.checkMaxSize(fp.getMaxAddress())
                hPageFull.calcNumBlock(pktSize, pktMinSize)
                fp.addHPage(hPageFull)
            }
        }
    }

    private fun searchPages(fp: FirmwarePage, hIntel: HexIntel) {
        Log.d(TAG, "::searchPages() isMuseo: $isMuseo")
        val maxAddress = fp.getMaxAddress()
        val hPageFull: HexPage?
        if (isMuseo) {
            val list = hIntel.getAllPageMuseo(fp.offset, maxAddress)
            for (hp in list) {
                hp.checkMaxSize(maxAddress)
                hp.calcNumBlock(pktSize, pktMinSize)
                fp.addHPage(hp)
            }
        } else {
            hPageFull = hIntel.getFullPage(fp.offset, maxAddress)
            if (hPageFull != null) {
                hPageFull.checkMaxSize(maxAddress)
                hPageFull.calcNumBlock(pktSize, pktMinSize)
                fp.addHPage(hPageFull)
            }
        }
    }

}

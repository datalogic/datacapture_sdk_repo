package com.datalogic.aladdin.aladdinusbscannersdk.utils.enums

enum class DIOCmdValue(
    val oemValue: ByteArray,
    val comValue: ByteArray,
    val comSCValue: ByteArray,
    val value: String,
    val stringRepresentation: String = "" // Human-readable string representation
) {
    IDENTIFICATION(
        byteArrayOf(0x30, 0, 0x01, 0, 0, 0, 0, 0, 0, 0, 0), 
        byteArrayOf(0x69),
        byteArrayOf(0x53, 0x33, 0x70, 0x3C, 0x0D),
        "Identification",
        "i" // Single character representing the command
    ),
    HEALTH(
        byteArrayOf(0x30, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(0x68),
        byteArrayOf(0x53, 0x33, 0x70, 0x3D, 0x0D),
        "Health",
        "h"
    ),
    STATISTICS(
        byteArrayOf(0x30, 0, 0x03, 0, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(0x73),
        byteArrayOf(0x53, 0x33, 0x70, 0x3E, 0x0D),
        "Statistics",
        "s"
    ),
    GOOD_BEEP(
        byteArrayOf(0x30, 0, 0x04, 0, 0, 0, 0x00, 0x00, 0x00, 0x00, 0x00),
        byteArrayOf(0x01),
        byteArrayOf(0x53, 0x33, 0x33, 0x34, 0x0D),
        "Good Beep",
        "b"
    ),
    ENABLE_SCANNER(
        byteArrayOf(0x11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(69, 13),
        byteArrayOf(0x53, 0x30, 0x31, 0x0D),
        "Enable Scanner",
        "E"
    ),
    DISABLE_SCANNER(
        byteArrayOf(0x12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(68, 13),
        byteArrayOf(0x53, 0x30, 0x36, 0x0D),
        "Disable Scanner",
        "D"
    ),
    RESET_SCANNER(
        byteArrayOf(0x00, 0x40, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(0x52),
        byteArrayOf(0x53, 0x30, 0x30, 0x0D),
        "Reset Scanner",
        "R"
    ),
    OTHER(
        byteArrayOf(),
        byteArrayOf(),
        byteArrayOf(),
        "Service Command",
        ""
    ),
    ERROR_BEEP(
        byteArrayOf(0x30, 0, 0x04, 0, 0, 0, 0x00, 0x00, 0x00, 0x00, 0x00),
        byteArrayOf(0x01),
        byteArrayOf(0x53, 0x33, 0x33, 0x34, 0x0D),
        "Error Beep",
        "b"
    ),
    DOCKING(
        byteArrayOf(0x30, 0, 0x07, 0, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(0x64),
        byteArrayOf(),
        "Docking",
        "d"
    ),
    TRIGGER_PRESS(
        byteArrayOf(0x30, 0, 0x08, 0, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(),
        byteArrayOf(),
        "Trigger Press",
        "t"
    ),
    TRIGGER_RELEASE(
        byteArrayOf(0x30, 0, 0x08, 0x01, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(),
        byteArrayOf(),
        "Trigger Release",
        "tr"
    ),
    LOG_RETRIEVAL(
        byteArrayOf(0x30, 0, 0x08, 0x02, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(),
        byteArrayOf(),
        "Log Retrieval",
        "lr"
    ),
    LOG_CLEARING(
        byteArrayOf(0x30, 0, 0x08, 0x03, 0, 0, 0, 0, 0, 0, 0),
        byteArrayOf(),
        byteArrayOf(),
        "Log Clearing",
        "lc"
    )
//    LINKING(
//        byteArrayOf(0x30, 0, 0x03, 0, 0, 0, 0, 0, 0, 0, 0),
//        byteArrayOf(0x73),
//        byteArrayOf(0x53, 0x33, 0x70, 0x3E, 0x0D),
//        "Linking",
//        "s"
//    )
    ;

    // Return a string representation of the command for display
    fun getDisplayString(isOem: Boolean): String {
        // For special commands, return the string representation
        if (this != OTHER && stringRepresentation.isNotEmpty()) {
            return stringRepresentation
        }

        // For OTHER or if no string representation, return the hex format
        return getValueString(isOem)
    }

    // Return hex string representation (used for backward compatibility)
    fun getValueString(isOem: Boolean): String {
        val cmdBytes = if (isOem) oemValue else comValue
        return cmdBytes.joinToString(",") {
            "0x" + (it.toInt() and 0xFF).toString(16).uppercase().padStart(2, '0')
        }
    }
}
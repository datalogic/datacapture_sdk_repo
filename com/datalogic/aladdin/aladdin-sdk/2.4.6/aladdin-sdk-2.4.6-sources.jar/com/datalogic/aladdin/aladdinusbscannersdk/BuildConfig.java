/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.datalogic.aladdin.aladdinusbscannersdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.datalogic.aladdin.aladdinusbscannersdk";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String LIBRARY_VERSION_NAME = "AladdinUsbSdk_2.4.6";
}

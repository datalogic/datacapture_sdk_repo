package com.datalogic.aladdin.aladdinusbscannersdk.model

import DatalogicBluetoothDevice
import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.RequiresPermission
import androidx.core.app.ActivityCompat
import androidx.core.graphics.createBitmap
import com.caverock.androidsvg.SVG
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.dfw.UpgradeDFW
import com.datalogic.aladdin.aladdinusbscannersdk.utils.bluetoothutils.PairBluetoothDevice
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.LocalJSONParser.inputStreamToString
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.AladdinConstants.SUCCESS
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.BluetoothConstants
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.ACTION_USB_PERMISSION
import com.datalogic.aladdin.aladdinusbscannersdk.utils.constants.USBConstants.VENDOR_ID
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.BluetoothPairingStatus
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.BluetoothProfile
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.ConnectionType
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.DeviceType
import com.datalogic.aladdin.aladdinusbscannersdk.utils.enums.convertInterfaceFromJsonToEnum
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.BluetoothListener
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.StatusListener
import com.datalogic.aladdin.aladdinusbscannersdk.utils.listeners.UsbListener
import com.datalogic.quickpairingapp.utils.SharedPreferenceUtil
import uk.org.okapibarcode.backend.DataMatrix
import uk.org.okapibarcode.graphics.Color
import uk.org.okapibarcode.output.SvgRenderer
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import kotlin.random.Random
import kotlin.random.nextULong


object DatalogicDeviceManager {
    var onUsbListener: UsbListener? = null
    var onBluetoothDeviceListener: BluetoothListener? = null
    private var isUsbReceiverRegistered: Boolean = false
    var onStatusListener: StatusListener? = null
    var openUsbDevice: DatalogicDevice? = null
    private const val ACK = 0x06
    private const val NACK = 0x15
    private const val RESTART_RESPONSE = 0x31

    private val bluetoothPairHelper = PairBluetoothDevice()
    private var bluetoothReceiver: BroadcastReceiver? = null

    var deviceAttachLatch: CountDownLatch? = null

    // The DeviceManager is the single source of truth for device status
    private var TAG: String = DatalogicDeviceManager::class.java.simpleName

    // Thread-safe device registry
    private val devices = ConcurrentHashMap<String, DatalogicDevice>()

    private val bluetoothDevices = ConcurrentHashMap<String, DatalogicBluetoothDevice>()

    // Device operations
    private fun getDevice(key: String): DatalogicDevice? = devices[key]

    private fun updateDevice(device: DatalogicDevice) {
        val deviceId = device.usbDevice.deviceName
        devices[deviceId] = device
    }

    fun updateDeviceFromApp(device: DatalogicDevice) {
        updateDevice(device)
    }

    private fun getBTDevice(key: String): DatalogicBluetoothDevice? = bluetoothDevices[key]

    private fun updateBTDevice(device: DatalogicBluetoothDevice) {
        val deviceId = device.id
        bluetoothDevices[deviceId] = device
    }

    private fun removeDevice(key: String) {
        devices.remove(key)
    }

    private fun removeBluetoothDevice(key: String) {
        bluetoothDevices.remove(key)
    }

    /**
     * USB broadcast receiver for handling USB events
     */
    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            when (intent.action) {
                ACTION_USB_PERMISSION -> {
                    synchronized(this) {
                        /*
                        val device: UsbDevice?
                        if (SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                        } else {
                            device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                        }
                        if (intent.getBooleanExtra(
                                UsbManager.EXTRA_PERMISSION_GRANTED,
                                false
                            )
                        ) {
                            Log.d(TAG, "Permission granted: $openUsbDevice")

                            if (openUsbDevice != null && openUsbDevice!!.checkUsbConnectionPermission()) {
                                openUsbDevice!!.deviceReConnect(context)
                            }
                        } else {
                            openUsbDevice?.let {
                                Log.e(TAG, "Permission denied: $openUsbDevice")
                            }
                        }
                        // To sync only one time with current openUsbConnection
                        openUsbDevice = null
                         */

                        //Temporary work around when intent.getParcelableExtra and intent.getBooleanExtra do not work
                        if (openUsbDevice != null && openUsbDevice!!.checkUsbConnectionPermission()) {
                            Log.d(TAG, "Permission granted: $openUsbDevice")
                            openUsbDevice?.openDevice(context)
                        } else if (openUsbDevice != null) {
                            openUsbDevice?.let {
                                Log.e(TAG, "Permission denied: $openUsbDevice")
                            }
                        } else {
                            Log.e(TAG, "USB device cannot be found for permission granted")
                        }
                    }
                }

                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    device?.let {
                        Log.d(TAG, "ACTION_USB_DEVICE_ATTACHED: $it")
                        onUsbListener?.onDeviceAttachedListener(it)
                        deviceAttachLatch?.countDown()
                    }
                }

                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    device?.let {
                        Log.d(TAG, "ACTION_USB_DEVICE_DETACHED: $it")
                        if (!UpgradeDFW.isUpgradeDFW) {
                            onUsbListener?.onDeviceDetachedListener(it)

                            // Check if the device is open before handling disconnection
                            //val deviceDescriptor = getDevice(it.productId.toString())
                            //deviceDescriptor?.handleDeviceDisconnection(it)
//                        openUsbDevice?.handleDeviceDisconnection(it)
                        }
                    }
                }
            }
        }
    }

    /**
     * Register the USB broadcast receiver
     */
    fun registerReceiver(context: Context) {
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(ACTION_USB_PERMISSION)
        }

        val appCtx = context.applicationContext
        if (!isUsbReceiverRegistered) {
            appCtx.registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            isUsbReceiverRegistered = true
        }

        registerBluetoothReceiver(context)
    }

    fun registerBluetoothReceiver(context: Context) {
        if (bluetoothReceiver != null) return

        bluetoothReceiver = object : BroadcastReceiver() {
            @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
            override fun onReceive(
                context: Context?,
                intent: Intent?
            ) {
                if (intent == null) return
                val action = intent.action
                val device: BluetoothDevice? =
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

                if (device == null || !bluetoothPairHelper.checkDataLogicDevice(device.address)) return

                when (action) {
                    BluetoothDevice.ACTION_ACL_CONNECTED -> {
                        Log.d(TAG, "Device ACTION_ACL_CONNECTED: ${device.name}")
                        if (device.bondState == BluetoothDevice.BOND_BONDED) {
                            Log.d(TAG, "[bluetoothReceiver] Device available: ${device.name}")
                            onBluetoothDeviceListener?.onDeviceAttachedListener(device)
                        }
                    }
                    BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                        onBluetoothDeviceListener?.onDeviceDetachedListener(device)
                    }
                }
            }
        }

        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }

        context.registerReceiver(bluetoothReceiver, filter)
        Log.d(TAG, "[registerBluetoothReceiver] registered")
    }

    fun unregisterBluetoothReceiver(context: Context) {
        try {
            bluetoothReceiver?.let {
                context.unregisterReceiver(it)
                Log.d(TAG, "[unregisterBluetoothReceiver] unregistered")
            }
        } catch (e: Exception) {
            Log.e(TAG, "[unregisterBluetoothReceiver] error", e)
        } finally {
            bluetoothReceiver = null
        }
    }


    /**
     * Unregister the USB broadcast receiver
     */
    fun unregisterReceiver(context: Context) {
        if (isUsbReceiverRegistered) {
            try {
                context.unregisterReceiver(usbReceiver)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to unregister receiver", e)
            }
            isUsbReceiverRegistered = false
        }
        unregisterBluetoothReceiver(context)
    }

    fun getAllUsbDevice(
        context: Context, onComplete: (ArrayList<UsbDevice>) -> Unit
    ) {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        var usbDeviceList = ArrayList<UsbDevice>()
        if (usbManager.deviceList.isNotEmpty()) {
            usbDeviceList = ArrayList(usbManager.deviceList.values)
        }
        // Return results on UI thread
        Handler(Looper.getMainLooper()).post {
            onComplete(usbDeviceList)
        }
    }

    /**
     * Asynchronously check for connected USB devices
     */
    fun detectDevice(
        context: Context, onComplete: (ArrayList<DatalogicDevice>) -> Unit
    ) {
        // Use a dedicated thread pool for device detection
        val executor = Executors.newSingleThreadExecutor()

        executor.execute {
            try {
                // Set timeout for the entire detection process
                //val deviceTimeout = 30000L // 30 seconds max
                val startTime = System.currentTimeMillis()
                val devices = ArrayList<DatalogicDevice>()

                try {
                    // Get devices with timeout
                    //val detectedDevices = checkConnectedDeviceWithTimeout(context, deviceTimeout)
                    val detectedDevices: ArrayList<DatalogicDevice> =
                        detectDeviceWithTimeout(context)
                    devices.addAll(detectedDevices)
                } catch (e: Exception) {
                    Log.e(TAG, "Error detecting devices", e)
                }

                Log.i(
                    TAG,
                    "Device detection completed in ${System.currentTimeMillis() - startTime}ms, found ${devices.size} devices"
                )

                // Return results on UI thread
                Handler(Looper.getMainLooper()).post {
                    onComplete(devices)
                }
            } finally {
                // Always shut down the executor
                executor.shutdown()
            }
        }
    }

    /**
     * Check for connected devices with a timeout
     */
    private fun detectDeviceWithTimeout(
        context: Context
        //timeout: Long
    ): ArrayList<DatalogicDevice> {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val datalogicDevices = ArrayList<DatalogicDevice>()
        val productList = inputStreamToString(context)
        //val startTime = System.currentTimeMillis()

        if (usbManager.deviceList.isNotEmpty()) {
            for (device in usbManager.deviceList.values) {
                if (!devices.containsKey(device.deviceName)) {
                    val products = findProductsById(device.productId.toString(), productList)
                    if (products?.size != 0) {
                        var product: Product? = null
                        products?.size?.let {
                            if (it >= 2) {
                                Log.w(
                                    TAG,
                                    "Multiple products found for device ${device.deviceName} with productId ${device.productId}. Using the first match."
                                )
                                product = findCorrectProductWithInterface(
                                    products, device.productName.toString()
                                )
                            } else {
                                product = products.first()
                            }
                        }

                        // Get basic device info first
                        val deviceTypeTemp = product?.deviceType
                        val deviceType: DeviceType
                        if (deviceTypeTemp == "FRS") {
                            deviceType = DeviceType.FRS
                        } else {
                            deviceType = DeviceType.HHS
                        }

                        val possibleInterfaces =
                            product?.deviceInterface?.filter { it.productId == device.productId.toString() }

                        val connectionType =
                            if (possibleInterfaces != null && possibleInterfaces.isNotEmpty()) {
                                convertInterfaceFromJsonToEnum(possibleInterfaces[0].type)
                            } else {
                                ConnectionType.USB_COM
                            }


                        val tempDesc =
                            DatalogicDevice(
                                usbManager = usbManager,
                                usbDevice = device,
                                deviceType = deviceType,
                                connectionType = connectionType,
                            )
                        datalogicDevices.add(tempDesc)

                        // Register in device manager
                        updateDevice(tempDesc)

                    }
                } else {
                    getDevice(device.deviceName)?.let { datalogicDevices.add(it) }
                }
            }

            for (device in devices) {
                if (!datalogicDevices.contains(device.value)) {
                    removeDevice(device.key)
                }
            }

        } else {
            devices.clear()
        }

        return datalogicDevices
    }

    private fun normalizeName(input: String): String =
        input.replace(Regex("[^A-Za-z0-9]"), "").lowercase()

    private fun findCorrectProductWithInterface(
        products: List<Product>,
        productName: String
    ): Product? {
        val normalizedInput = normalizeName(productName)
        val matched = products.firstOrNull { product ->
            product.model.any { model ->
                normalizedInput.contains(normalizeName(model))
            }
        }
        if (matched != null) {
            Log.d(TAG, "Found matching product: ${matched.model}")
            return matched
        } else {
            Log.w(TAG, "No matching product found for the given interfaces")
        }
        return products.firstOrNull()
    }

    /**
     * Find a product by ID in the product list
     */
    private fun findProductsById(productId: String, productList: ProductResponse): List<Product>? {
        return productList.productEntries.flatMap { it.product }.filter { product ->
            product.vendorId == VENDOR_ID && product.deviceInterface.any { it.productId == productId }
        }
    }

    /**
     * Create a fresh connection for device detection
     *//*private fun freshDetectionConnection(
        device: DatalogicDevice,
        context: Context,
        timeout: Long
    ): Boolean {
        val startTime = System.currentTimeMillis()

        try {
            // Open with timeout check
            if (device.openUsbConnection(context) != SUCCESS) {
                return false
            }
            if (System.currentTimeMillis() - startTime > timeout / 2) {
                return false
            }

            // Claim interface with timeout check
            if (device.claimUsbInterface(context) != SUCCESS) {
                return false
            }

            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error in freshDetectionConnection: ${e.message}", e)
            return false
        }
    }*/

    /**
     * Setup USB listener for connection/disconnection events
     */
    fun registerUsbListener(listener: UsbListener): Int {
        return if (onUsbListener == null) {
            onUsbListener = listener
            SUCCESS
        } else {
            AladdinConstants.LISTENER_ALREADY_REGISTERED_ERROR
        }
    }

    /**
     * Clear USB listener
     */
    fun unregisterUsbListener(listener: UsbListener): Int {
        return if (listener == onUsbListener) {
            onUsbListener = null
            SUCCESS
        } else {
            AladdinConstants.LISTENER_NOT_REGISTERED_ERROR
        }
    }

    fun registerStatusListener(listener: StatusListener): Int {
        return if (onStatusListener == null) {
            onStatusListener = listener
            SUCCESS
        } else {
            AladdinConstants.LISTENER_ALREADY_REGISTERED_ERROR
        }
    }

    fun unregisterStatusListener(listener: StatusListener): Int {
        return if (listener == onStatusListener) {
            onStatusListener = null
            SUCCESS
        } else {
            AladdinConstants.LISTENER_NOT_REGISTERED_ERROR
        }
    }

    fun registerBluetoothListener(listener: BluetoothListener): Int {
        return if (onBluetoothDeviceListener == null) {
            onBluetoothDeviceListener = listener
            SUCCESS
        } else {
            AladdinConstants.LISTENER_ALREADY_REGISTERED_ERROR
        }
    }

    fun unregisterBluetoothListener(listener: BluetoothListener): Int {
        return if (listener == onBluetoothDeviceListener) {
            onBluetoothDeviceListener = null
            SUCCESS
        } else {
            AladdinConstants.LISTENER_NOT_REGISTERED_ERROR
        }
    }

    ///// Pair device
    fun qrCodeGenerator(context: Context, bluetoothProfile: BluetoothProfile): Bitmap {
        val dataMatrix = DataMatrix()
        dataMatrix.readerInit = true
        dataMatrix.forceMode = DataMatrix.ForceMode.SQUARE
        SharedPreferenceUtil.initSharedPreference(context)
        val randomNumber = Random.nextULong(0u, 0xFFFFFFFFFFFFu)
        val accessToken = randomNumber.toString(16).uppercase()
        var paddedAccessToken = accessToken
        if (accessToken.length < 12) {
            paddedAccessToken = accessToken.padEnd(12, '0')
        }
        Log.d(
            TAG,
            "[qrCodeGenerator] creating new access token: $paddedAccessToken"
        )
        val dynamicPairingStr = bluetoothPairHelper.getDynamicPairingString(paddedAccessToken)
        SharedPreferenceUtil.saveDynamicPairingStr(paddedAccessToken)

        val content = if (bluetoothProfile == BluetoothProfile.SPP) {
            SharedPreferenceUtil.saveBTProfile(BluetoothConstants.SPP_BT_PROFILE)
            "LnkB${dynamicPairingStr}\u000D"
        } else {
            SharedPreferenceUtil.saveBTProfile(BluetoothConstants.HID_BT_PROFILE)
            "LnkHid${dynamicPairingStr}\u000D"
        }

        dataMatrix.content = content
        Log.d(TAG, "dynamic barcode content : $content")

        val byteOutputStream = ByteArrayOutputStream()
        val renderer = SvgRenderer(byteOutputStream, 10.0, Color.WHITE, Color.BLACK, true)
        renderer.render(dataMatrix)

        val svgData = byteOutputStream.toString("UTF-8")
        val svg = SVG.getFromString(svgData)
        val bitmap = createBitmap(svg.documentWidth.toInt(), svg.documentHeight.toInt())
        val canvas = Canvas(bitmap)
        svg.renderToCanvas(canvas)

        return bitmap
    }

    fun scanBluetoothDevices(
        context: Activity,
        onComplete: (BluetoothPairingData) -> Unit
    ) {
        val executor = Executors.newSingleThreadExecutor()
        executor.execute {
            try {
                var deviceName = ""
                var status = BluetoothPairingStatus.Unsuccessful

                val startTime = System.currentTimeMillis()
                try {
                    bluetoothPairHelper.scanBluetoothDevices(context)
                    while (!bluetoothPairHelper.isFinished) {
                        if (status != bluetoothPairHelper.statusPairing) {
                            status = bluetoothPairHelper.statusPairing
                            Log.d(TAG, "[scanBluetoothDevices] current statusPairing: $status")
                        }
                        Thread.sleep(100)
                    }
                    status = bluetoothPairHelper.statusPairing
                    Log.d(
                        TAG,
                        "[scanBluetoothDevices] bluetoothPairHelper.isFinished --- statusPairing: $status"
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Error detecting devices", e)
                }

                if (status == BluetoothPairingStatus.Successful) {
                    deviceName = bluetoothPairHelper.deviceName
                    val timeDetect = System.currentTimeMillis() - startTime
                    Log.i(TAG, "Device pairing completed in $timeDetect ms, found $deviceName")
                }

                val msg = bluetoothPairHelper.getMessage()
                Log.i(TAG, "[scanBluetoothDevices] message: $msg")
                val pairingData = BluetoothPairingData(deviceName, status, msg)

                Handler(Looper.getMainLooper()).post {
                    onComplete(pairingData)
                }
            } finally {
                executor.shutdown()
            }
        }
    }

    fun stopScanBluetoothDevices(context: Context) {
        Log.d(TAG, "[stopScanBluetoothDevices] unregister Receiver")
        bluetoothPairHelper.unregisterDiscoveryReceiver(context)
        bluetoothPairHelper.unregisterBtHidReceiver(context)
        bluetoothPairHelper.removePairingBroadcastReceiver(context)
        bluetoothPairHelper.isFinished = true
        bluetoothPairHelper.mCurrentBluetoothDevice = null
    }

     fun getAllBluetoothDevice(
         context: Activity, onComplete: (ArrayList<DatalogicBluetoothDevice>) -> Unit
     ) : Boolean {
         Log.d(TAG, "[getAllBluetoothDevice] Begin")
         if (!bluetoothPairHelper.ensureBluetoothPermissions(context)) {
             Log.d(TAG, "[getAllBluetoothDevice] Permission denied")
             return false
         }
         val executor = Executors.newSingleThreadExecutor()
         executor.execute {
             try {
                 val listBluetoothDevice: ArrayList<BluetoothDevice> = ArrayList()
                 val datalogicBluetoothDevices: ArrayList<DatalogicBluetoothDevice> = ArrayList()
                 bluetoothPairHelper.initBlueToothAdapter(context)
                 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && ActivityCompat.checkSelfPermission(
                         context,
                         Manifest.permission.BLUETOOTH_CONNECT
                     ) != PackageManager.PERMISSION_GRANTED
                 ) {
                     Log.d(TAG, "BT connect not permitted")
                     return@execute
                 }

                 Log.d(TAG, "[getAllBluetoothDevice] getBondedDevices")
                 val listDevices = bluetoothPairHelper.bluetoothAdapter.getBondedDevices()
                 if(listDevices.isNotEmpty()) {
                     for (device: BluetoothDevice in listDevices) {
                         if (!bluetoothDevices.containsKey(device.address)) {
                             if (device.getType() != BluetoothDevice.DEVICE_TYPE_LE && bluetoothPairHelper.checkDataLogicDevice(
                                     device.address
                                 )
                             ) {
                                 Log.d(
                                     TAG,
                                     "[getAllBluetoothDevice] listBluetoothDevice add: ${device.name}"
                                 )
                                 listBluetoothDevice.add(device)
                                 val dlBluetoothDevice = DatalogicBluetoothDevice(
                                     device
                                 )
                                 dlBluetoothDevice.name = device.name
                                 datalogicBluetoothDevices.add(dlBluetoothDevice)
                                 updateBTDevice(dlBluetoothDevice)
                             }
                         } else {
                             getBTDevice(device.address)?.let { datalogicBluetoothDevices.add(it) }
                         }
                     }
                     for (device in bluetoothDevices) {
                         if (!datalogicBluetoothDevices.contains(device.value)) {
                             removeBluetoothDevice(device.key)
                         }
                     }
                 } else {
                     bluetoothDevices.clear()
                 }
                 Handler(Looper.getMainLooper()).post {
                     Log.d(
                         TAG,
                         "[getAllBluetoothDevice] Datalogic device: ${listBluetoothDevice.size}/${listDevices.size} Bluetooth devices"
                     )
                     onComplete(datalogicBluetoothDevices)
                 }
             } finally {
                 executor.shutdown()
             }
         }
         return true
     }
}
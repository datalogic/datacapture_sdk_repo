package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware

import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import java.io.File

abstract class FirmwareUpdater{
    abstract fun upgrade(progressCallback: (Int) -> Unit, resetCallback: () -> Unit, onComplete: () -> Unit): Boolean
    abstract fun upgradeByBulkTransfer(progressCallback: (Int) -> Unit): Boolean
    abstract fun isSupportedBulkTransfer(): Boolean
    abstract fun getPid(file: File?): String?
    abstract fun isCheckPid(serial: ServiceSerial): Boolean
    abstract fun isValidSWU(): Boolean

    abstract fun loadFirmwareFile(onCompleteLoading: (() -> Unit)?, progressCallback: ((Int) -> Unit)?): Boolean
}

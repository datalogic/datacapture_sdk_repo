package com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.swu

import android.util.Log
import com.datalogic.aladdin.aladdinusbscannersdk.feature.upgradefirmware.FirmwareUpdater
import com.datalogic.aladdin.aladdinusbscannersdk.usbaccess.ServiceSerial
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.CharsUtil.Companion.containsSequence
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSDevice
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.FRS.FRSScannerTypes
import com.datalogic.aladdin.aladdinusbscannersdk.utils.commonutils.SmartUtil.byteArrayToHexString
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.nio.charset.StandardCharsets

class FirmwareSWUUpdater(
    private val firmwareData: File,
    private val serial: ServiceSerial,
    private val frsDevice: FRSDevice
): FirmwareUpdater() {

    companion object {
        private val SUCCESS_RESPONSE = byteArrayOf(0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x00)
        private val FAILED_RESPONSE = byteArrayOf(0x46, 0x41, 0x49, 0x4C, 0x45, 0x44, 0x00)
    }

    private var hwid: Byte = 0
    private val TAG = this.javaClass.simpleName

    init {
        getPid(firmwareData)
    }



    @Throws(Exception::class)
    override fun upgrade(progressCallback: (Int) -> Unit, resetCallback: () -> Unit, onComplete: () -> Unit): Boolean {
        val beginCmd = FRSScannerTypes.SOFTWARE_UPDATE_START + byteArrayOf(0x00)
        val response = serial.sendReceive(frsDevice.createFullFRSCommand(beginCmd),
            30000, 200, true)
        if (!response.contentEquals(FRSScannerTypes.ACK_BYTEARRAY)) {
            Log.e(TAG, "Failed to start SWU update")
            return false
        }

        val dataSizeInit = 100000
        var previousPercent = -1L
        var failed = false
        var coreUpdateComplete = false
        var errorType = ""
        var dataSize = dataSizeInit
        var dataWritten: Long = 0
        var sendCmd: ByteArray? = null
        val totalLength = firmwareData.length()

        try {
            FileInputStream(firmwareData).use { br ->
                var data = ByteArray(dataSize)
                var amountRead: Int
                while (br.read(data).also { amountRead = it } != -1 && !failed) {
                    if (amountRead < dataSize) {
                        data = data.copyOfRange(0, amountRead)
                        dataSize = amountRead
                    }

                    // Direct send, no retry
                    val command = FRSScannerTypes.SOFTWARE_UPDATE_SEND_DATA + data
                    val sendResponse = serial.sendReceive(frsDevice.createFullFRSCommand(command), 30000, 200, true)
                    val sendSuccess = sendResponse?.contentEquals(FRSScannerTypes.ACK_BYTEARRAY) == true
                    
                    if (!sendSuccess) {
                        failed = true
                        errorType = "data send failed (no retry)"
                        Log.e(TAG, "Failed to send data block (no retry)")
                    } else {
                        dataWritten += amountRead
                    }

                    val percent = dataWritten * 100 / totalLength
                    if (percent > previousPercent) {
                        previousPercent = percent
                        progressCallback(percent.toInt())
                    }
                }

                if (!failed) {
                    coreUpdateComplete = true
                    sendCmd = FRSScannerTypes.SOFTWARE_UPDATE_SEND_DATA
                    val response = serial.sendReceive(frsDevice.createFullFRSCommand(sendCmd!!),
                        120000, 500, true)
                    Log.d(TAG, "SOFTWARE_UPDATE_SEND_DATA response: ${response?.get(0)}")
                    
                    val startTime = System.currentTimeMillis()
                    val verifyStatusTime = 8 * 60 * 1000
                    var complete = false
                    
                    while ((System.currentTimeMillis() - startTime) <= verifyStatusTime) {
                        val timeLeft = (verifyStatusTime - (System.currentTimeMillis() - startTime)) / 1000
                        Log.d(TAG, "Waiting for update completion, time left: ${timeLeft}s")
                        
                        try {
                            // Direct status command, no retry
                            val status = serial.sendReceive(frsDevice.createFullFRSCommand(FRSScannerTypes.SOFTWARE_UPDATE_STATUS),
                                300000, 200, true)

                            complete = when {
                                status?.contentEquals("SUCCESS".toByteArray(StandardCharsets.US_ASCII)) == true ||
                                        status?.contentEquals("IDLE".toByteArray(StandardCharsets.US_ASCII)) == true ||
                                        status?.containsSequence(SUCCESS_RESPONSE) == true -> {
                                    Log.d(TAG, "SWU update completed successfully")
                                    true
                                }
                                status?.contentEquals("FAILURE".toByteArray(StandardCharsets.US_ASCII)) == true ||
                                        status?.contentEquals("FAILED".toByteArray(StandardCharsets.US_ASCII)) == true ||
                                        status?.containsSequence(FAILED_RESPONSE) == true -> {
                                    Log.e(TAG, "SWU update failed")
                                    false
                                }
                                else -> {
                                    if (status != null) {
                                        Log.d(TAG, "Status response: ${status.contentToString()}")
                                    } else {
                                        break
                                    }
                                    false
                                }
                            }

                            if (complete){
                                onComplete()
                                break
                            }
                        } catch (ex: IOException) {
                            Log.d(TAG, "Failed to send status command, assuming device is resetting: ${ex.message}")
                            break
                        }

                        Thread.sleep(5000)
                    }
                    failed = !complete
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            Log.e(TAG, "Exception during SWU update: ${e.message}")
            failed = true
        } finally {
            if (failed) {
                val errorMessage = if (coreUpdateComplete) {
                    "SWU update failed during status verification"
                } else {
                    "SWU update failed during data transfer: $errorType"
                }
                Log.e(TAG, errorMessage)
                sendCmd?.let {
                    Log.d(TAG, "Last message sent: ${byteArrayToHexString(it)}")
                }
            } else {
                Log.d(TAG, "SWU update completed successfully")
            }
            return !failed
        }
    }

    override fun upgradeByBulkTransfer(progressCallback: (Int) -> Unit): Boolean {
        return false
    }

    override fun isSupportedBulkTransfer(): Boolean {
        return false
    }

    override fun getPid(file: File?): String? {
        val response = serial.sendReceive(frsDevice.createFullFRSCommand(
            FRSScannerTypes.READ_VERSION), 1000, 100)
        val result = response?.let { CharsUtil.parseScannerResponse(it) }
        val data = result?.get("data") as ByteArray?
        if (data != null && data.size == 56) {
            hwid = data[1]//hwid = 71 hwid = response[1];
        } else {
            Log.d(TAG, "FIRMWARE_UPDATE_SWU_PID_NOT_FOUND")
        }
        if (!FRSScannerTypes.swuUpdate.contains(hwid)) {
            Log.d(TAG, "FIRMWARE_UPDATE_SWU_NOT_SUPPORTED")
        }
        return hwid.toString()
    }

    override fun isCheckPid(serial: ServiceSerial): Boolean {
        return FRSScannerTypes.swuUpdate.contains(hwid)
    }

    @Throws(Exception::class)
    override fun isValidSWU(): Boolean {
        return try {
            val isValid = firmwareData.inputStream().use { input ->
                parseCpioAndValidateSwu(input) { msg -> Log.d("SWU_CHECK", msg) }
            }
            return isValid
        } catch (e: Throwable) {
            Log.d(TAG, "SWU validation failed: ${e.message}")
            false
        }
    }

    override fun loadFirmwareFile(
        onCompleteLoading: (() -> Unit)?, progressCallback: ((Int) -> Unit)?
    ): Boolean {
        onCompleteLoading?.invoke()
        return true
    }

    private fun parseCpioAndValidateSwu(
        input: InputStream,
        onLog: (String) -> Unit = { Log.d("SWU", it) }
    ): Boolean {
        var isValid = false

        while (true) {
            val header = input.readExactNBytesCompat(110)
            if (header.size < 110) break

            val namesize = String(header.copyOfRange(94, 102)).toInt(16)
            val filesize = String(header.copyOfRange(54, 62)).toInt(16)

            val nameBytes = input.readExactNBytesCompat(namesize)
            val name = String(nameBytes).trim('\u0000')

            val namePad = (4 - (110 + namesize) % 4) % 4
            if (namePad > 0) input.skip(namePad.toLong())

            if (name == "TRAILER!!!") break

            val fileData = input.readExactNBytesCompat(filesize)

            val filePad = (4 - filesize % 4) % 4
            if (filePad > 0) input.skip(filePad.toLong())

            // ✅ Your check goes here
            if (name == "sw-description") {
                val swDescription = fileData.toString(Charsets.UTF_8).replace("\\s+".toRegex(), "")
                if (!(swDescription.contains("fresco={") || swDescription.contains("apollo={")
                            || (swDescription.contains("gemini={")))) {
                    onLog("\"fresco={\" or \"apollo={\" not present in sw-description.")
                    onLog("FIRMWARE_UPDATE_SWU_VALIDATION_FAIL")
                    return false
                } else {
                    isValid = true
                    return isValid
                }
            }
        }
        return isValid
    }


    fun InputStream.readExactNBytesCompat(n: Int): ByteArray {
        val buffer = ByteArray(n)
        var bytesRead = 0
        while (bytesRead < n) {
            val read = this.read(buffer, bytesRead, n - bytesRead)
            if (read == -1) break
            bytesRead += read
        }
        return if (bytesRead == n) buffer else buffer.copyOf(bytesRead)
    }
}
